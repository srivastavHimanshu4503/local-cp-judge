def solve(root, q, a, b):
    # disagreement j is between a[j] and b[j]
    # return a list of q answers
    return [0] * q
