    // disagreement j is between a[j] and b[j]
    // return an array of q answers
    static int[] solve(TreeNode root, int q, int[] a, int[] b) {
        return new int[q];
    }
