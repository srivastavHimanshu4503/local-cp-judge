# Problem D — Settle It Close: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | 11 level-order entries | Statement example 1 | `5
2
1
5` |
| sample/02 | 3 level-order entries | Statement example 2: siblings, and the founder with one of their mentees | `1
1` |
| sample/03 | 5 level-order entries | Statement example 3: chain, IDs not in order | `1` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | 2 level-order entries | two people: answer is always the mentor | `1
1` |
| secret/02 | 11 level-order entries | small random #1 (n = 6) | `5
6
6
6
6
6` |
| secret/03 | 16 level-order entries | small random #2 (n = 9) | `3
8
3
5
5
5` |
| secret/04 | 5 level-order entries | small random #3 (n = 4) | `3
3
1
3
3
1` |
| secret/05 | 21 level-order entries | small random #4 (n = 11) | `2
2
5
2
2
2` |
| secret/06 | 10 level-order entries | small random #5 (n = 7) | `6
6
1
6
4
1` |
| secret/07 | 199998 level-order entries | chain of 100000 going left: one person is always above the other | `70680
33156
11577
5858
8262
65970
558…` |
| secret/08 | 199999 level-order entries | chain of 100000 going right, includes the two deepest people | `134
9815
16632
17565
43082
9815
25554…` |
| secret/09 | 199999 level-order entries | zig-zag chain of 100000 | `80016
1551
7403
89232
75931
96371
352…` |
| secret/10 | 100000 level-order entries | complete binary tree, 100000 people | `37154
10821
85222
91669
74724
2985
74…` |
| secret/11 | 100000 level-order entries | complete tree, pairs among the deepest people | `35846
24231
35846
35846
35846
35846
7…` |
| secret/12 | 199979 level-order entries | random tree, 100000 people | `32247
31233
72353
26367
93828
6250
33…` |
| secret/13 | 199998 level-order entries | random deep tree, 100000 people | `82365
21801
82287
7966
2158
13134
526…` |
| secret/14 | 199998 level-order entries | random deep tree, pairs among the deepest people | `12994
12994
9669
57255
52255
12186
32…` |
| secret/15 | 199999 level-order entries | two long arms from the founder, many pairs on opposite arms | `75880
75880
75880
75880
75880
75880
7…` |
| secret/16 | 199994 level-order entries | random tree with IDs in level order (1 is the founder) | `5
1
75891
1
5
3739
9025
1
1
4
5911
1
…` |
