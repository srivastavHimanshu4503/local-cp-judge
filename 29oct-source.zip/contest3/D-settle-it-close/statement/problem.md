---
title: "Problem D — Settle It Close"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

Every startup has disagreements: about the product, about deadlines, about who forgot to reply to the customer. The good ones don't make a scene about it. They settle it **quietly, as close to the problem as possible**.

A startup has **n** people with IDs 1 to n. The founder is at the top, and every person mentors **at most two** others, so the team forms a binary tree. Person X is **above** person Y if X is Y's mentor, or their mentor's mentor, and so on up the tree. Everyone also counts as being above themselves.

When two people disagree, they follow one rule: they go to the **lowest person who is above both of them**, meaning the one closest to them in the tree. No higher than that, and never to the whole company. If one of them is above the other, they settle it between themselves.

You are given **q** disagreements. For each one, print the ID of the person who settles it.

## Your task

Implement the function below. The tree is already built for you, and the input reading and output printing are done for you.

```java
// Java
// class TreeNode { int val; TreeNode left, right; }
// (already defined; val is the person's ID)
// disagreement j is between a[j] and b[j]
// return an array of q answers
static int[] solve(TreeNode root, int q, int[] a, int[] b)
```

```python
# Python
# class TreeNode: val, left, right
# (already defined; val is the person's ID)
# disagreement j is between a[j] and b[j]
# return a list of q answers
def solve(root, q, a, b):
```

## Input

- The first line has one integer **m**: the number of entries in the second line.
- The second line describes the tree in **level order**, the order you get by reading each level from left to right, top to bottom. Each entry is a person's ID or `null` for a missing child, as on LeetCode. The first entry is the founder.
- The third line has one integer **q**.
- Each of the next **q** lines has two IDs **a** and **b**, separated by a space.

## Output

Print **q** lines. Line *j* holds the ID of the person who settles disagreement *j*.

## Constraints

- 1 ≤ n ≤ 100 000, and the IDs are exactly 1 to n, each appearing once.
- 1 ≤ q ≤ 20
- a ≠ b
- The tree can be very unbalanced, for example a single long chain. The harness gives your code enough stack space for recursion.

## Example 1

Input:

```
11
1 2 3 4 5 null 6 null null 7 8
4
7 8
4 7
7 6
5 8
```

Output:

```
5
2
1
5
```

**Explanation:** The team looks like this:

```text
            1          (founder)
          /   \
         2     3
        / \     \
       4   5     6
          / \
         7   8
```

- **7 and 8:** Person 5 mentors both of them, so 5 settles it. Nobody higher needs to hear about it.
- **4 and 7:** 4 is under 2, and 7 is under 5, which is under 2. The lowest person above both is **2**.
- **7 and 6:** These two are on opposite sides of the company. Only the founder, **1**, is above both.
- **5 and 8:** 5 is above 8 (5 is 8's mentor), so they settle it between themselves. The answer is **5**.

## Example 2

Input:

```
3
1 2 3
2
2 3
1 3
```

Output:

```
1
1
```

**Explanation:** The founder 1 mentors both 2 and 3.

- **2 and 3:** The lowest person above both of them is **1**.
- **1 and 3:** The founder is above 3, so 1 and 3 settle it between themselves. The answer is **1**.

## Example 3

Input:

```
5
3 null 1 null 2
1
2 1
```

Output:

```
1
```

**Explanation:** The team is a chain, 3 → 1 → 2, with each person the right child of the one before:

```text
3
 \
  1
   \
    2
```

1 is directly above 2, so they settle it themselves, and the answer is **1**. The IDs don't have to follow any order in the tree.
