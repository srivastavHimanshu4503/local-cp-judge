"""Deterministic test generator for Problem D (Settle It Close). Usage: python3 gen.py <problem_dir>

Trees are built as child arrays over positions 0..n-1 (position 0 is the root), then every position
gets an ID from a shuffled permutation of 1..n, and the tree is written in LeetCode level order.
"""
import os
import random
import sys
from collections import deque

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXN = 100_000
MAXQ = 20

SAMPLES = [
    ("11\n1 2 3 4 5 null 6 null null 7 8\n4\n7 8\n4 7\n7 6\n5 8\n", "Statement example 1"),
    ("3\n1 2 3\n2\n2 3\n1 3\n", "Statement example 2: siblings, and the founder with one of their mentees"),
    ("5\n3 null 1 null 2\n1\n2 1\n", "Statement example 3: chain, IDs not in order"),
]


class Tree:
    def __init__(self, n):
        self.n = n
        self.L = [-1] * n
        self.R = [-1] * n
        self.par = [-1] * n


def attach(t, p, c, side):
    if side == 0:
        t.L[p] = c
    else:
        t.R[p] = c
    t.par[c] = p


def chain(n, pattern):
    t = Tree(n)
    for i in range(1, n):
        attach(t, i - 1, i, pattern(i))
    return t


def complete(n):
    t = Tree(n)
    for i in range(1, n):
        attach(t, (i - 1) // 2, i, (i - 1) % 2)
    return t


def random_tree(rng, n, bias_deep=False):
    t = Tree(n)
    free = [(0, 0), (0, 1)]
    for c in range(1, n):
        k = len(free) - 1 - min(len(free) - 1, int(rng.expovariate(0.5))) if bias_deep else rng.randrange(len(free))
        p, side = free[k]
        free[k] = free[-1]
        free.pop()
        attach(t, p, c, side)
        free.append((c, 0))
        free.append((c, 1))
    return t


def serialize(t, ids):
    out = [str(ids[0])]
    q = deque([0])
    while q:
        u = q.popleft()
        for c in (t.L[u], t.R[u]):
            if c == -1:
                out.append("null")
            else:
                out.append(str(ids[c]))
                q.append(c)
    while out[-1] == "null":
        out.pop()
    return out


def ancestors(t, u):
    res = []
    while u != -1:
        res.append(u)
        u = t.par[u]
    return res


def make(rng, t, pairs_pos, shuffle_ids=True):
    ids = list(range(1, t.n + 1))
    if shuffle_ids:
        rng.shuffle(ids)
    tok = serialize(t, ids)
    lines = [str(len(tok)), " ".join(tok), str(len(pairs_pos))]
    lines += [f"{ids[a]} {ids[b]}" for a, b in pairs_pos]
    return "\n".join(lines) + "\n"


def mixed_pairs(rng, t, k=MAXQ):
    """Random pairs plus ancestor/descendant pairs, siblings and pairs involving the root."""
    n = t.n
    pairs = []
    while len(pairs) < k:
        kind = len(pairs) % 4
        if kind == 0:
            a, b = rng.sample(range(n), 2)
        elif kind == 1:  # one above the other
            b = rng.randrange(1, n)
            anc = ancestors(t, b)[1:]
            a = rng.choice(anc)
            if rng.random() < 0.5:
                a, b = b, a
        elif kind == 2:  # siblings if possible
            cands = [u for u in range(n) if t.L[u] != -1 and t.R[u] != -1]
            if cands:
                u = rng.choice(cands)
                a, b = t.L[u], t.R[u]
            else:
                a, b = rng.sample(range(n), 2)
        else:  # root with someone
            a, b = 0, rng.randrange(1, n)
        pairs.append((a, b))
    return pairs


def deepest_pairs(rng, t, k=MAXQ):
    depth = [0] * t.n
    order = [0]
    for u in order:
        for c in (t.L[u], t.R[u]):
            if c != -1:
                depth[c] = depth[u] + 1
                order.append(c)
    deep = sorted(range(t.n), key=lambda u: -depth[u])[:200]
    return [tuple(rng.sample(deep, 2)) for _ in range(k)]


def secret_tests():
    rng = random.Random(20261031)
    tests = []
    t = Tree(2)
    attach(t, 0, 1, 0)
    tests.append((make(rng, t, [(0, 1), (1, 0)]), "two people: answer is always the mentor"))
    for i in range(5):
        n = rng.randint(3, 12)
        t = random_tree(rng, n)
        tests.append((make(rng, t, mixed_pairs(rng, t, 6)), f"small random #{i + 1} (n = {n})"))
    t = chain(MAXN, lambda i: 0)
    tests.append((make(rng, t, mixed_pairs(rng, t)), "chain of 100000 going left: one person is always above the other"))
    t = chain(MAXN, lambda i: 1)
    pairs = [(MAXN - 1, MAXN - 2), (MAXN - 1, 0)] + mixed_pairs(rng, t, MAXQ - 2)
    tests.append((make(rng, t, pairs), "chain of 100000 going right, includes the two deepest people"))
    t = chain(MAXN, lambda i: i % 2)
    tests.append((make(rng, t, mixed_pairs(rng, t)), "zig-zag chain of 100000"))
    t = complete(MAXN)
    tests.append((make(rng, t, mixed_pairs(rng, t)), "complete binary tree, 100000 people"))
    tests.append((make(rng, t, deepest_pairs(rng, t)), "complete tree, pairs among the deepest people"))
    t = random_tree(rng, MAXN)
    tests.append((make(rng, t, mixed_pairs(rng, t)), "random tree, 100000 people"))
    t = random_tree(rng, MAXN, bias_deep=True)
    tests.append((make(rng, t, mixed_pairs(rng, t)), "random deep tree, 100000 people"))
    tests.append((make(rng, t, deepest_pairs(rng, t)), "random deep tree, pairs among the deepest people"))
    # two long arms from the founder: pairs on opposite arms go to the founder
    n = MAXN
    t = Tree(n)
    half = n // 2
    attach(t, 0, 1, 0)
    attach(t, 0, half, 1)
    for i in range(2, half):
        attach(t, i - 1, i, 0)
    for i in range(half + 1, n):
        attach(t, i - 1, i, 1)
    pairs = [(rng.randrange(1, half), rng.randrange(half, n)) for _ in range(10)] + mixed_pairs(rng, t, 10)
    tests.append((make(rng, t, pairs), "two long arms from the founder, many pairs on opposite arms"))
    t = random_tree(rng, MAXN)
    tests.append((make(rng, t, mixed_pairs(rng, t), shuffle_ids=False), "random tree with IDs in level order (1 is the founder)"))
    return tests


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
