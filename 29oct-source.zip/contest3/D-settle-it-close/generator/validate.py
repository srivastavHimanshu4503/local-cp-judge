"""Strict input validator for Problem D. Checks the level-order tree, IDs 1..n, and the queries.
Usage: python3 validate.py < test.in"""
import re
import sys
from collections import deque

data = sys.stdin.read()
assert re.fullmatch(r"\d+\n(\d+|null)( (\d+|null))*\n\d+\n(\d+ \d+\n)+", data), "bad format"
lines = data.split("\n")[:-1]
m = int(lines[0])
tok = lines[1].split()
assert len(tok) == m and tok[0] != "null" and tok[-1] != "null", "bad token count or trailing null"
# rebuild exactly as the harness does and make sure every token is consumed
ids = [int(tok[0])]
q = deque([0])
i = 1
while q and i < m:
    q.popleft()
    for _ in range(2):
        if i < m and tok[i] != "null":
            ids.append(int(tok[i]))
            q.append(len(ids) - 1)
        i += 1
assert i >= m, "tokens left over after the tree is complete"
n = len(ids)
assert 1 <= n <= 100_000, "n out of range"
assert sorted(ids) == list(range(1, n + 1)), "IDs must be exactly 1..n"
qq = int(lines[2])
assert 1 <= qq <= 20 and len(lines) == qq + 3, "bad q"
for ln in lines[3:]:
    a, b = map(int, ln.split())
    assert 1 <= a <= n and 1 <= b <= n and a != b, f"bad query {a} {b}"
print("OK")
