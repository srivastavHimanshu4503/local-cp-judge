"""Independent checker for small trees: builds parent links, collects every ancestor of a as a set,
then climbs from b until it hits that set. Usage: python3 brute.py < test.in"""
import sys
from collections import deque

data = sys.stdin.read().split()
m = int(data[0])
tok = data[1:1 + m]
assert m <= 6000, "too big for brute"
parent = {int(tok[0]): None}
q = deque([int(tok[0])])
i = 1
while q and i < m:
    u = q.popleft()
    for _ in range(2):
        if i < m and tok[i] != "null":
            parent[int(tok[i])] = u
            q.append(int(tok[i]))
        i += 1
pos = 1 + m
qq = int(data[pos])
out = []
for j in range(qq):
    a, b = int(data[pos + 1 + 2 * j]), int(data[pos + 2 + 2 * j])
    anc = set()
    x = a
    while x is not None:
        anc.add(x)
        x = parent[x]
    y = b
    while y not in anc:
        y = parent[y]
    out.append(y)
print("\n".join(map(str, out)))
