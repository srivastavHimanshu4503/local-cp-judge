import sys
import threading
from collections import deque


class TreeNode:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


# ---------------- your code starts here ----------------
# Correct but O(n^2) per query: for every person, search their whole subtree for a and b.
def contains(node, x):
    stack = [node]
    while stack:
        u = stack.pop()
        if u.val == x:
            return True
        if u.left:
            stack.append(u.left)
        if u.right:
            stack.append(u.right)
    return False


def solve(root, q, a, b):
    res = []
    for x, y in zip(a, b):
        best, best_d = root.val, 0
        stack = [(root, 0)]
        while stack:
            u, d = stack.pop()
            if d >= best_d and contains(u, x) and contains(u, y):
                best, best_d = u.val, d
            if u.left:
                stack.append((u.left, d + 1))
            if u.right:
                stack.append((u.right, d + 1))
        res.append(best)
    return res
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    m = int(data[0])
    tok = data[1:1 + m]
    root = TreeNode(int(tok[0]))
    queue = deque([root])
    i = 1
    while queue and i < m:
        node = queue.popleft()
        if i < m and tok[i] != b"null":
            node.left = TreeNode(int(tok[i]))
            queue.append(node.left)
        i += 1
        if i < m and tok[i] != b"null":
            node.right = TreeNode(int(tok[i]))
            queue.append(node.right)
        i += 1
    pos = 1 + m
    q = int(data[pos])
    a = [int(x) for x in data[pos + 1:pos + 1 + 2 * q:2]]
    b = [int(x) for x in data[pos + 2:pos + 2 + 2 * q:2]]
    res = solve(root, q, a, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


# allow recursive solutions on very deep trees
sys.setrecursionlimit(1 << 25)
threading.stack_size(512 * 1024 * 1024)


def runner():
    try:
        main()
        sys.stdout.flush()
    except BaseException:
        import os
        import traceback
        traceback.print_exc()
        sys.stderr.flush()
        os._exit(1)  # report a crash as a run error, not a wrong answer


t = threading.Thread(target=runner)
t.start()
t.join()
