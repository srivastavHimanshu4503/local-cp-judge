import java.io.*;
import java.util.*;

class Main {
    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
    }

    // ---------------- your code starts here ----------------
    // Bug: walks up from each person's MENTOR, so it misses the case where one is above the other.
    static HashMap<Integer, Integer> parent = new HashMap<>(), depth = new HashMap<>();

    static int[] solve(TreeNode root, int q, int[] a, int[] b) {
        ArrayDeque<TreeNode> st = new ArrayDeque<>();
        st.push(root);
        parent.put(root.val, root.val);
        depth.put(root.val, 0);
        while (!st.isEmpty()) {
            TreeNode u = st.pop();
            for (TreeNode c : new TreeNode[]{u.left, u.right})
                if (c != null) { parent.put(c.val, u.val); depth.put(c.val, depth.get(u.val) + 1); st.push(c); }
        }
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int x = parent.get(a[j]), y = parent.get(b[j]);
            while (depth.get(x) > depth.get(y)) x = parent.get(x);
            while (depth.get(y) > depth.get(x)) y = parent.get(y);
            while (x != y) { x = parent.get(x); y = parent.get(y); }
            res[j] = x;
        }
        return res;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) {
        // run on a 512 MB stack so recursive solutions work on very deep trees
        Thread t = new Thread(null, () -> {
            try { run(); } catch (IOException e) { throw new RuntimeException(e); }
        }, "main", 1L << 29);
        t.setUncaughtExceptionHandler((th, e) -> { e.printStackTrace(); System.exit(1); });
        t.start();
        try { t.join(); } catch (InterruptedException e) { throw new RuntimeException(e); }
    }

    static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        int m = in.nextInt();
        String[] tok = new String[m];
        for (int i = 0; i < m; i++) tok[i] = in.next();
        TreeNode root = new TreeNode(Integer.parseInt(tok[0]));
        ArrayDeque<TreeNode> queue = new ArrayDeque<>();
        queue.add(root);
        int i = 1;
        while (!queue.isEmpty() && i < m) {
            TreeNode node = queue.poll();
            if (i < m && !tok[i].equals("null")) { node.left = new TreeNode(Integer.parseInt(tok[i])); queue.add(node.left); }
            i++;
            if (i < m && !tok[i].equals("null")) { node.right = new TreeNode(Integer.parseInt(tok[i])); queue.add(node.right); }
            i++;
        }
        int q = in.nextInt();
        int[] a = new int[q], b = new int[q];
        for (int j = 0; j < q; j++) { a[j] = in.nextInt(); b[j] = in.nextInt(); }
        int[] res = solve(root, q, a, b);
        StringBuilder sb = new StringBuilder();
        for (int x : res) sb.append(x).append('\n');
        System.out.print(sb);
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
