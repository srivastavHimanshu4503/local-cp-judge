import sys
import threading
from collections import deque


class TreeNode:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


# ---------------- your code starts here ----------------
# One traversal records parent and depth; then walk the deeper person up.
def solve(root, q, a, b):
    parent, depth = {root.val: None}, {root.val: 0}
    stack = [root]
    while stack:
        node = stack.pop()
        for ch in (node.left, node.right):
            if ch:
                parent[ch.val] = node.val
                depth[ch.val] = depth[node.val] + 1
                stack.append(ch)
    res = []
    for x, y in zip(a, b):
        while depth[x] > depth[y]:
            x = parent[x]
        while depth[y] > depth[x]:
            y = parent[y]
        while x != y:
            x, y = parent[x], parent[y]
        res.append(x)
    return res
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    m = int(data[0])
    tok = data[1:1 + m]
    root = TreeNode(int(tok[0]))
    queue = deque([root])
    i = 1
    while queue and i < m:
        node = queue.popleft()
        if i < m and tok[i] != b"null":
            node.left = TreeNode(int(tok[i]))
            queue.append(node.left)
        i += 1
        if i < m and tok[i] != b"null":
            node.right = TreeNode(int(tok[i]))
            queue.append(node.right)
        i += 1
    pos = 1 + m
    q = int(data[pos])
    a = [int(x) for x in data[pos + 1:pos + 1 + 2 * q:2]]
    b = [int(x) for x in data[pos + 2:pos + 2 + 2 * q:2]]
    res = solve(root, q, a, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


# allow recursive solutions on very deep trees
sys.setrecursionlimit(1 << 25)
threading.stack_size(512 * 1024 * 1024)


def runner():
    try:
        main()
        sys.stdout.flush()
    except BaseException:
        import os
        import traceback
        traceback.print_exc()
        sys.stderr.flush()
        os._exit(1)  # report a crash as a run error, not a wrong answer


t = threading.Thread(target=runner)
t.start()
t.join()
