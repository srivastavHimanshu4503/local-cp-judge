    // Bug: walks up from each person's MENTOR, so it misses the case where one is above the other.
    static HashMap<Integer, Integer> parent = new HashMap<>(), depth = new HashMap<>();

    static int[] solve(TreeNode root, int q, int[] a, int[] b) {
        ArrayDeque<TreeNode> st = new ArrayDeque<>();
        st.push(root);
        parent.put(root.val, root.val);
        depth.put(root.val, 0);
        while (!st.isEmpty()) {
            TreeNode u = st.pop();
            for (TreeNode c : new TreeNode[]{u.left, u.right})
                if (c != null) { parent.put(c.val, u.val); depth.put(c.val, depth.get(u.val) + 1); st.push(c); }
        }
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int x = parent.get(a[j]), y = parent.get(b[j]);
            while (depth.get(x) > depth.get(y)) x = parent.get(x);
            while (depth.get(y) > depth.get(x)) y = parent.get(y);
            while (x != y) { x = parent.get(x); y = parent.get(y); }
            res[j] = x;
        }
        return res;
    }
