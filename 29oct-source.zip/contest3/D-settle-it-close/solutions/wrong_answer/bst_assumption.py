# Bug: treats the tree as a BST and walks by comparing IDs.
def solve(root, q, a, b):
    res = []
    for x, y in zip(a, b):
        lo, hi = min(x, y), max(x, y)
        node = root
        while node:
            if hi < node.val and node.left:
                node = node.left
            elif lo > node.val and node.right:
                node = node.right
            else:
                break
        res.append(node.val)
    return res
