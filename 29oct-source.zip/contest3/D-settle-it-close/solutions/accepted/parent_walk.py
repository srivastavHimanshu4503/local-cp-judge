# One traversal records parent and depth; then walk the deeper person up.
def solve(root, q, a, b):
    parent, depth = {root.val: None}, {root.val: 0}
    stack = [root]
    while stack:
        node = stack.pop()
        for ch in (node.left, node.right):
            if ch:
                parent[ch.val] = node.val
                depth[ch.val] = depth[node.val] + 1
                stack.append(ch)
    res = []
    for x, y in zip(a, b):
        while depth[x] > depth[y]:
            x = parent[x]
        while depth[y] > depth[x]:
            y = parent[y]
        while x != y:
            x, y = parent[x], parent[y]
        res.append(x)
    return res
