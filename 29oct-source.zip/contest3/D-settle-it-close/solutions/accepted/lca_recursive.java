    static TreeNode lca(TreeNode node, int a, int b) {
        if (node == null || node.val == a || node.val == b) return node;
        TreeNode left = lca(node.left, a, b);
        TreeNode right = lca(node.right, a, b);
        if (left != null && right != null) return node;
        return left != null ? left : right;
    }

    static int[] solve(TreeNode root, int q, int[] a, int[] b) {
        int[] res = new int[q];
        for (int j = 0; j < q; j++) res[j] = lca(root, a[j], b[j]).val;
        return res;
    }
