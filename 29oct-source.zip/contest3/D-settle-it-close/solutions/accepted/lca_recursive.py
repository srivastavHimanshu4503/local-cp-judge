def lca(node, a, b):
    if node is None or node.val == a or node.val == b:
        return node
    left = lca(node.left, a, b)
    right = lca(node.right, a, b)
    if left and right:
        return node
    return left if left else right


def solve(root, q, a, b):
    return [lca(root, a[j], b[j]).val for j in range(q)]
