# Correct but O(n^2) per query: for every person, search their whole subtree for a and b.
def contains(node, x):
    stack = [node]
    while stack:
        u = stack.pop()
        if u.val == x:
            return True
        if u.left:
            stack.append(u.left)
        if u.right:
            stack.append(u.right)
    return False


def solve(root, q, a, b):
    res = []
    for x, y in zip(a, b):
        best, best_d = root.val, 0
        stack = [(root, 0)]
        while stack:
            u, d = stack.pop()
            if d >= best_d and contains(u, x) and contains(u, y):
                best, best_d = u.val, d
            if u.left:
                stack.append((u.left, d + 1))
            if u.right:
                stack.append((u.right, d + 1))
        res.append(best)
    return res
