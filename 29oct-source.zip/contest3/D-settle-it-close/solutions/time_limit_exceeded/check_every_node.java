    // Correct but O(n^2) per query: for every person, search their whole subtree for a and b.
    static boolean contains(TreeNode node, int x) {
        ArrayDeque<TreeNode> st = new ArrayDeque<>();
        st.push(node);
        while (!st.isEmpty()) {
            TreeNode u = st.pop();
            if (u.val == x) return true;
            if (u.left != null) st.push(u.left);
            if (u.right != null) st.push(u.right);
        }
        return false;
    }

    static int[] solve(TreeNode root, int q, int[] a, int[] b) {
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int best = root.val, bestD = 0;
            ArrayDeque<Object[]> st = new ArrayDeque<>();
            st.push(new Object[]{root, 0});
            while (!st.isEmpty()) {
                Object[] top = st.pop();
                TreeNode u = (TreeNode) top[0];
                int d = (Integer) top[1];
                if (d >= bestD && contains(u, a[j]) && contains(u, b[j])) { best = u.val; bestD = d; }
                if (u.left != null) st.push(new Object[]{u.left, d + 1});
                if (u.right != null) st.push(new Object[]{u.right, d + 1});
            }
            res[j] = best;
        }
        return res;
    }
