"""Shared writer for the generators. Each generator defines SAMPLES and secret_tests()."""
import os


def write_all(root, samples, secrets):
    sd = os.path.join(root, "data", "sample")
    xd = os.path.join(root, "data", "secret")
    for d in (sd, xd):
        os.makedirs(d, exist_ok=True)
        for f in os.listdir(d):
            os.remove(os.path.join(d, f))
    for kind, d, items in (("sample", sd, samples), ("secret", xd, secrets)):
        for i, (content, desc) in enumerate(items, 1):
            with open(os.path.join(d, f"{i:02d}.in"), "w") as f:
                f.write(content)
            with open(os.path.join(d, f"{i:02d}.desc"), "w") as f:
                f.write(desc + "\n")
