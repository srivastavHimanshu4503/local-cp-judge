    // Bug that loops forever: lo = guess instead of guess + 1.
    static int[] solve(int q, long[] N, long[] X) {
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            long lo = 1, hi = N[j], x = X[j];
            int guesses = 0;
            while (true) {
                long guess = (lo + hi) / 2;
                guesses++;
                if (guess == x) break;
                if (guess < x) lo = guess;
                else hi = guess - 1;
            }
            res[j] = guesses;
        }
        return res;
    }
