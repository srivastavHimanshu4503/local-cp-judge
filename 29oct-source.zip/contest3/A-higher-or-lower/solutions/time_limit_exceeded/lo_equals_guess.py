# Bug that loops forever: lo = guess instead of guess + 1.
def solve(q, N, X):
    res = []
    for j in range(q):
        lo, hi, x = 1, N[j], X[j]
        g = 0
        while True:
            guess = (lo + hi) // 2
            g += 1
            if guess == x:
                break
            if guess < x:
                lo = guess
            else:
                hi = guess - 1
        res.append(g)
    return res
