def solve(q, N, X):
    res = []
    for j in range(q):
        lo, hi, x = 1, N[j], X[j]
        guesses = 0
        while True:
            guess = (lo + hi) // 2
            guesses += 1
            if guess == x:
                break
            if guess < x:
                lo = guess + 1
            else:
                hi = guess - 1
        res.append(guesses)
    return res
