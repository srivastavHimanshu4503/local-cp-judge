    // Bug: squeezes the numbers into int.
    static int[] solve(int q, long[] N, long[] X) {
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int lo = 1, hi = (int) N[j], x = (int) X[j];
            int guesses = 0;
            while (lo <= hi) {
                int guess = (lo + hi) / 2;
                guesses++;
                if (guess == x) break;
                if (guess < x) lo = guess + 1;
                else hi = guess - 1;
            }
            res[j] = guesses;
        }
        return res;
    }
