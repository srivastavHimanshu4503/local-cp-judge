    // game j has range 1..N[j] and secret number X[j]
    // return an array of q answers
    static int[] solve(int q, long[] N, long[] X) {
        return new int[q];
    }
