def solve(q, N, X):
    # game j has range 1..N[j] and secret number X[j]
    # return a list of q answers
    return [0] * q
