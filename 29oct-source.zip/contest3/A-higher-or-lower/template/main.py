import sys

# ---------------- your code starts here ----------------
def solve(q, N, X):
    # game j has range 1..N[j] and secret number X[j]
    # return a list of q answers
    return [0] * q
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    q = int(data[0])
    N = [int(x) for x in data[1:1 + 2 * q:2]]
    X = [int(x) for x in data[2:2 + 2 * q:2]]
    res = solve(q, N, X)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
