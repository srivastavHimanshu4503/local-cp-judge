import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // game j has range 1..N[j] and secret number X[j]
    // return an array of q answers
    static int[] solve(int q, long[] N, long[] X) {
        return new int[q];
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int q = in.nextInt();
        long[] N = new long[q], X = new long[q];
        for (int j = 0; j < q; j++) { N[j] = in.nextLong(); X[j] = in.nextLong(); }
        int[] res = solve(q, N, X);
        StringBuilder sb = new StringBuilder();
        for (int x : res) sb.append(x).append('\n');
        System.out.print(sb);
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
