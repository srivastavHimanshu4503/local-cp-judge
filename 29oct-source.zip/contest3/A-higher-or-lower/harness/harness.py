import sys

# ---------------- your code starts here ----------------
{{STUDENT_CODE}}
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    q = int(data[0])
    N = [int(x) for x in data[1:1 + 2 * q:2]]
    X = [int(x) for x in data[2:2 + 2 * q:2]]
    res = solve(q, N, X)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
