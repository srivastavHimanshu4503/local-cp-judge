# Problem A — Higher or Lower: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | q = 4 | Statement example 1: N = 10, four secret numbers | `4
1
3
4` |
| sample/02 | q = 2 | Statement example 2: N = 100 and N = 1 | `3
1` |
| sample/03 | q = 2 | Statement example 3: N = 10^18 (needs long) | `59
60` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | q = 1 | single game, N = 1 | `1` |
| secret/02 | q = 5 | N = 2 and N = 3, every X | `1
2
2
1
2` |
| secret/03 | q = 5050 | every X for every N from 1 to 100 | `1
1
2
2
1
2
2
1
2
3
2
3
1
2
3
2
3
1
3…` |
| secret/04 | q = 1000 | N = 1000, every X | `9
10
8
10
9
10
7
10
9
10
8
10
9
10
6
…` |
| secret/05 | q = 20 | small random #1 | `4
3
5
5
5
4
2
5
3
4
2
3
6
2
4
3
5
5
4
3` |
| secret/06 | q = 20 | small random #2 | `5
5
4
1
3
6
5
3
2
3
2
2
3
3
4
2
3
4
2
1` |
| secret/07 | q = 20 | small random #3 | `5
4
5
1
5
4
5
4
6
5
2
4
6
5
3
1
5
5
6
1` |
| secret/08 | q = 708 | N around every power of two, X = 1, N, the middle, and random | `1
1
1
1
1
2
1
1
2
2
1
2
2
2
1
2
2
3
1…` |
| secret/09 | q = 200000 | max q, N = 10^18, random X | `58
60
59
60
60
59
58
59
60
59
60
55
6…` |
| secret/10 | q = 200000 | max q, N = 10^18, X near the top | `60
56
58
58
60
58
59
60
58
59
59
59
5…` |
| secret/11 | q = 200000 | max q, N = 10^18, X near the bottom | `59
58
59
60
60
60
54
58
60
59
60
60
6…` |
| secret/12 | q = 200000 | max q, random N up to 10^18 and random X | `59
55
56
60
56
59
58
56
58
58
57
58
6…` |
| secret/13 | q = 200000 | max q, N just above 2^31 (int overflow fails) | `32
32
32
33
31
33
32
31
33
31
33
31
3…` |
| secret/14 | q = 200000 | max q, X is always the first guess: every answer 1 | `1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1…` |
| secret/15 | q = 200000 | max q, N up to 10^9 | `24
29
23
28
29
24
28
29
25
29
29
30
2…` |
