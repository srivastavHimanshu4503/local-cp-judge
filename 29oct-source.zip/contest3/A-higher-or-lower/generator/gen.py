"""Deterministic test generator for Problem A (Higher or Lower). Usage: python3 gen.py <problem_dir>"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXQ = 200_000
BIG = 10**18

SAMPLES = [
    ("4\n10 7\n10 5\n10 1\n10 10\n", "Statement example 1: N = 10, four secret numbers"),
    ("2\n100 37\n1 1\n", "Statement example 2: N = 100 and N = 1"),
    ("2\n1000000000000000000 1\n1000000000000000000 1000000000000000000\n", "Statement example 3: N = 10^18 (needs long)"),
]


def fmt(games):
    return f"{len(games)}\n" + "".join(f"{n} {x}\n" for n, x in games)


def secret_tests():
    rng = random.Random(20261030)
    t = []
    t.append((fmt([(1, 1)]), "single game, N = 1"))
    t.append((fmt([(2, 1), (2, 2), (3, 1), (3, 2), (3, 3)]), "N = 2 and N = 3, every X"))
    t.append((fmt([(n, x) for n in range(1, 101) for x in range(1, n + 1)]), "every X for every N from 1 to 100"))
    t.append((fmt([(1000, x) for x in range(1, 1001)]), "N = 1000, every X"))
    for i in range(3):
        g = [(n, rng.randint(1, n)) for n in (rng.randint(1, 50) for _ in range(20))]
        t.append((fmt(g), f"small random #{i + 1}"))
    g = []
    for k in range(1, 61):
        for n in (2 ** k - 1, 2 ** k, 2 ** k + 1):
            if n <= BIG:
                g += [(n, 1), (n, n), (n, (n + 1) // 2), (n, rng.randint(1, n))]
    t.append((fmt(g), "N around every power of two, X = 1, N, the middle, and random"))
    t.append((fmt([(BIG, rng.randint(1, BIG)) for _ in range(MAXQ)]), "max q, N = 10^18, random X"))
    t.append((fmt([(BIG, BIG - rng.randint(0, 1000)) for _ in range(MAXQ)]), "max q, N = 10^18, X near the top"))
    t.append((fmt([(BIG, rng.randint(1, 1000)) for _ in range(MAXQ)]), "max q, N = 10^18, X near the bottom"))
    g = []
    for _ in range(MAXQ):
        n = rng.randint(1, BIG)
        g.append((n, rng.randint(1, n)))
    t.append((fmt(g), "max q, random N up to 10^18 and random X"))
    g = []
    for _ in range(MAXQ):
        n = rng.randint(2 ** 31, 2 ** 33)
        g.append((n, rng.randint(1, n)))
    t.append((fmt(g), "max q, N just above 2^31 (int overflow fails)"))
    g = []
    for _ in range(MAXQ):
        n = rng.randint(1, 10**6)
        g.append((n, (1 + n) // 2))
    t.append((fmt(g), "max q, X is always the first guess: every answer 1"))
    g = []
    for _ in range(MAXQ):
        n = rng.randint(1, 10**9)
        g.append((n, rng.randint(1, n)))
    t.append((fmt(g), "max q, N up to 10^9"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
