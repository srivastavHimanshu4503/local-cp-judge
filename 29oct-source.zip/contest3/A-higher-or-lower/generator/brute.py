"""Independent checker for small tests: keeps the explicit list of still-possible numbers and
guesses its middle element (rounding down). Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
q = int(data[0])
games = [(int(data[1 + 2 * j]), int(data[2 + 2 * j])) for j in range(q)]
assert sum(n for n, _ in games) <= 2_000_000, "too big for brute"
out = []
for n, x in games:
    cand = list(range(1, n + 1))
    g = 0
    while True:
        guess = cand[(len(cand) - 1) // 2]
        g += 1
        if guess == x:
            break
        cand = [c for c in cand if c > guess] if guess < x else [c for c in cand if c < guess]
    out.append(g)
print("\n".join(map(str, out)))
