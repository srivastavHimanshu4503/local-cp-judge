"""Strict input validator for Problem A. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+\n(\d+ \d+\n)+", data), "bad format"
lines = data.split("\n")[:-1]
q = int(lines[0])
assert 1 <= q <= 200_000 and len(lines) == q + 1, "bad q"
for ln in lines[1:]:
    n, x = map(int, ln.split())
    assert 1 <= x <= n <= 10**18, f"bad game {n} {x}"
print("OK")
