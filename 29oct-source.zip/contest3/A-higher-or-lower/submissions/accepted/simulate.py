import sys

# ---------------- your code starts here ----------------
def solve(q, N, X):
    res = []
    for j in range(q):
        lo, hi, x = 1, N[j], X[j]
        guesses = 0
        while True:
            guess = (lo + hi) // 2
            guesses += 1
            if guess == x:
                break
            if guess < x:
                lo = guess + 1
            else:
                hi = guess - 1
        res.append(guesses)
    return res
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    q = int(data[0])
    N = [int(x) for x in data[1:1 + 2 * q:2]]
    X = [int(x) for x in data[2:2 + 2 * q:2]]
    res = solve(q, N, X)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
