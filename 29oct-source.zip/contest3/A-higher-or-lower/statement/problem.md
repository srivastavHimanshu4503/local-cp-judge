---
title: "Problem A — Higher or Lower"
---

**Time limit:** 3 seconds (Java), 9 seconds (Python) · **Memory limit:** 1024 MB

Robo the robot and Arjun are playing a guessing game. Robo secretly picks a number **X** between 1 and **N**. Arjun then guesses, and after every guess Robo says **"Higher!"**, **"Lower!"** or **"Correct!"**.

Arjun always plays the same way. He keeps track of the range of numbers that are still possible, from **lo** to **hi**, starting at lo = 1 and hi = N. Each time, he guesses the middle of that range, rounding down:

guess = ⌊(lo + hi) / 2⌋

- If Robo says **"Higher!"**, Arjun sets lo = guess + 1.
- If Robo says **"Lower!"**, Arjun sets hi = guess − 1.
- If Robo says **"Correct!"**, the game ends.

You are given **q** games. For each game, print how many guesses Arjun makes, **including** the correct one.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// game j has range 1..N[j] and secret number X[j]
// return an array of q answers
static int[] solve(int q, long[] N, long[] X)
```

```python
# Python
# game j has range 1..N[j] and secret number X[j]
# return a list of q answers
def solve(q, N, X):
```

> **Note:** N can be as large as 10^18^. In Java, use `long` for lo, hi and guess. lo + hi stays below 2 × 10^18^, which fits in a `long`.

## Input

- The first line has one integer **q**.
- Each of the next **q** lines has two integers **N** and **X**, separated by a space.

## Output

Print **q** lines. Line *j* holds the number of guesses in game *j*.

## Constraints

- 1 ≤ q ≤ 200 000
- 1 ≤ X ≤ N ≤ 10^18^

## Example 1

Input:

```
4
10 7
10 5
10 1
10 10
```

Output:

```
4
1
3
4
```

**Explanation:** Here is the first game, N = 10 and X = 7, step by step:

| Guess no. | lo | hi | Guess ⌊(lo + hi) / 2⌋ | Robo says |
|:---:|:---:|:---:|:---:|:---:|
| 1 | 1 | 10 | 5 | Higher! |
| 2 | 6 | 10 | 8 | Lower! |
| 3 | 6 | 7 | 6 | Higher! |
| 4 | 7 | 7 | 7 | Correct! |

That's **4** guesses. The other games:

- **X = 5:** Arjun's first guess is 5. That's **1** guess.
- **X = 1:** He guesses 5 (Lower!), then 2 (Lower!), then 1 (Correct!). That's **3** guesses.
- **X = 10:** He guesses 5 (Higher!), 8 (Higher!), 9 (Higher!), then 10 (Correct!). That's **4** guesses.

## Example 2

Input:

```
2
100 37
1 1
```

Output:

```
3
1
```

**Explanation:**

- **N = 100, X = 37:** Arjun guesses 50 (Lower!), then ⌊(1 + 49) / 2⌋ = 25 (Higher!), then ⌊(26 + 49) / 2⌋ = 37 (Correct!). That's **3** guesses.
- **N = 1:** The only possible number is 1, so the first guess is correct. That's **1** guess.

## Example 3

Input:

```
2
1000000000000000000 1
1000000000000000000 1000000000000000000
```

Output:

```
59
60
```

**Explanation:** The range is huge, but every guess cuts it roughly in half, so even 10^18^ numbers need only about 60 guesses. Finding X = 1 takes **59** guesses, and finding X = 10^18^ takes **60**.
