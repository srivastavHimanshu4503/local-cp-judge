# Contest package: four problems, 2 hours

| | Problem | Topic | Python function | Java method | Time limit (Java / Python) | Secret tests |
|---|---|---|---|---|---|---|
| A | Higher or Lower | binary search (simulating it exactly) | `solve(q, N, X)` | `int[] solve(int q, long[] N, long[] X)` | 3 s / 9 s | 15 |
| B | The h-Value | sorting | `solve(n, a)` | `int solve(int n, int[] a)` | 2 s / 6 s | 22 |
| C | Don't Forward It | graphs: BFS | `solve(n, m, friends, s, kind)` | `int solve(int n, int m, int[][] friends, int s, String kind)` | 2 s / 6 s | 24 |
| D | Settle It Close | binary trees: lowest common ancestor | `solve(root, q, a, b)` | `int[] solve(TreeNode root, int q, int[] a, int[] b)` | 2 s / 6 s | 16 |

Each problem also has 3 sample tests (the statement examples). The memory limit is 1024 MB for every problem.

## Importing into DOMjudge

1. Import the four zips from `dist/domjudge/` (Jury → Problems → Import). Each zip holds `problem.yaml`, `domjudge-problem.ini`, `problem.pdf`, all sample and secret tests, and the jury submissions.
2. The Python limits assume DOMjudge's **time factor for Python 3 is 3**, the same as the earlier contests.
3. After import, each jury submission should get the verdict of its folder: `accepted`, `wrong_answer` or `time_limit_exceeded`.
4. The largest zip is C, at about 16 MB.

## The tree harness (Problem D)

- The harness defines `TreeNode` (`val`, `left`, `right`) and builds the tree from the LeetCode-style level-order line before calling `solve`.
- It runs the student's code on a **512 MB stack** in both languages: a thread with a large stack in Java, and a raised recursion limit plus a large thread stack in Python. Recursive solutions therefore work on a 100 000-person chain. This was verified with Java's default stack settings, which is how DOMjudge runs it.
- A crash inside that thread exits with a non-zero status, so DOMjudge reports it as RUN-ERROR rather than WRONG-ANSWER.

## What is in each problem folder

| Path | What it is |
|---|---|
| `statement/problem.md` | Statement source; `problem.html` and `problem.pdf` are rendered from it. |
| `harness/` | The I/O code (`harness.py`, `Harness.java`). The student's function goes at the `{{STUDENT_CODE}}` marker. |
| `stub/` | Only the function the student starts from. |
| `template/` | Harness + stub as one runnable file (`main.py`, `Main.java`). |
| `solutions/` | Function-only jury solutions in `accepted`, `wrong_answer` and `time_limit_exceeded`. |
| `submissions/` | The same solutions assembled with the harness into full programs. DOMjudge imports these as jury submissions. |
| `generator/` | `gen.py` (deterministic test generator), `validate.py` (strict input checker), `brute.py` (independent slow checker for small tests). |
| `data/sample`, `data/secret` | The tests: `.in` input, `.ans` expected output, `.desc` one-line description. |
| `TESTS.md` | Catalog of every test: what it targets and its expected output. |
| `verification-report.txt` | Result of judging every jury submission against every test. |

`statements/contest-problems.pdf` is the printable booklet: a one-page rules sheet followed by all four problems.

## Rebuilding

```
python3 tools/build.py        # regenerate tests, validate, cross-check, judge all jury submissions
python3 tools/package.py      # render statements, write metadata and TESTS.md, build dist/domjudge/*.zip
```

Verdicts are checked the way DOMjudge decides them: tests run in order, and the first failing test decides the verdict.

## Checks that were run

- Every input passes the problem's strict validator. For D, this includes rebuilding the tree exactly as the harness does and checking that the IDs are exactly 1 to n.
- Every expected output agrees with an independently written brute-force checker on every test small enough for it (9–13 tests per problem).
- The examples in each statement match `data/sample` byte for byte.
- Every jury submission gets its expected verdict. Slowest accepted runs: A 2.45 s (Python simulation of 2 × 10⁵ games, against a 9 s limit), B 0.17 s, C 0.65 s, D 0.83 s (recursive Python LCA).
- Each Java slow solution was also run on every secret test without stopping early. It took over 2 s on 10 tests (B), 4 (C) and 6 (D). A's slow solution loops forever on Example 1.

## Design notes worth knowing before the contest

- **A (Higher or Lower):** Rounding the middle up, or not counting the correct guess, fails Example 1. Using `lo = guess` loops forever on Example 1. `int` variables in Java fail Example 3, and on larger tests they also loop forever.
- **B (The h-Value):** Comparing the h-th largest value with h − 1 instead of h fails Example 1. Returning a value instead of h fails Example 2. Trying every h is O(n²) and times out.
- **C (Don't Forward It):** Ignoring the kind rule, not counting kind students, or not letting the rumour reach them at all, fails Example 1. Letting the starting student talk even when kind fails Example 2. Re-scanning every friendship round after round is O(n·m) on a long chain and times out. A recursive DFS crashes on the 200 000-student chain in both languages, so BFS or an iterative DFS is needed.
- **D (Settle It Close):** Treating the tree like a BST (comparing IDs) fails Example 1. So does walking up from each person's *mentor*, which misses the case where one person is above the other. Checking every person's whole subtree is O(n²) and times out on long chains. q is at most 20 on purpose, so the basic recursive LCA from class is all that's needed.
