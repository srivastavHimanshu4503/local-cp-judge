def solve(n, m, friends, s, kind):
    # friends[j] = (u, v): u and v are friends
    # kind[i - 1] == '1' means student i is kind
    # return how many students hear the rumour
    return 0
