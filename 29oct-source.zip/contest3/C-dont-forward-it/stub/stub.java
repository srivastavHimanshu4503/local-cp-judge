    // friends[j][0] and friends[j][1] are friends
    // kind.charAt(i - 1) == '1' means student i is kind
    // return how many students hear the rumour
    static int solve(int n, int m, int[][] friends, int s, String kind) {
        return 0;
    }
