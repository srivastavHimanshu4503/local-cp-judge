import sys

# ---------------- your code starts here ----------------
# Bug: forgets the kind rule entirely (counts everyone connected to s).
from collections import deque


def solve(n, m, friends, s, kind):
    adj = [[] for _ in range(n + 1)]
    for u, v in friends:
        adj[u].append(v)
        adj[v].append(u)
    heard = [False] * (n + 1)
    heard[s] = True
    q = deque([s])
    while q:
        u = q.popleft()
        for v in adj[u]:
            if not heard[v]:
                heard[v] = True
                q.append(v)
    return sum(heard)
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m, s = int(data[0]), int(data[1]), int(data[2])
    kind = data[3].decode()
    friends = [(int(data[4 + 2 * j]), int(data[5 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, friends, s, kind)}\n")


main()
