import sys

# ---------------- your code starts here ----------------
# Bug: kind students are treated as if they never heard it.
from collections import deque


def solve(n, m, friends, s, kind):
    adj = [[] for _ in range(n + 1)]
    for u, v in friends:
        adj[u].append(v)
        adj[v].append(u)
    heard = [False] * (n + 1)
    heard[s] = True
    q = deque([s])
    cnt = 0
    while q:
        u = q.popleft()
        if kind[u - 1] == '1':
            continue
        cnt += 1
        for v in adj[u]:
            if not heard[v]:
                heard[v] = True
                q.append(v)
    return cnt
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m, s = int(data[0]), int(data[1]), int(data[2])
    kind = data[3].decode()
    friends = [(int(data[4 + 2 * j]), int(data[5 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, friends, s, kind)}\n")


main()
