import sys

# ---------------- your code starts here ----------------
# Correct but O(m * rounds): every round, scan all friendships and pass the rumour one step.
def solve(n, m, friends, s, kind):
    heard = [False] * (n + 1)
    heard[s] = True
    changed = True
    while changed:
        changed = False
        for u, v in friends:
            for x, y in ((u, v), (v, u)):
                if heard[x] and not heard[y] and kind[x - 1] != '1':
                    heard[y] = True
                    changed = True
    return sum(heard)
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m, s = int(data[0]), int(data[1]), int(data[2])
    kind = data[3].decode()
    friends = [(int(data[4 + 2 * j]), int(data[5 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, friends, s, kind)}\n")


main()
