import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // Correct but O(m * rounds): every round, scan all friendships and pass the rumour one step.
    static int solve(int n, int m, int[][] friends, int s, String kind) {
        boolean[] heard = new boolean[n + 1];
        heard[s] = true;
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int[] f : friends) {
                int u = f[0], v = f[1];
                if (heard[u] && !heard[v] && kind.charAt(u - 1) != '1') { heard[v] = true; changed = true; }
                if (heard[v] && !heard[u] && kind.charAt(v - 1) != '1') { heard[u] = true; changed = true; }
            }
        }
        int c = 0;
        for (boolean h : heard) if (h) c++;
        return c;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int s = in.nextInt();
        String kind = in.next();
        int[][] friends = new int[m][2];
        for (int j = 0; j < m; j++) { friends[j][0] = in.nextInt(); friends[j][1] = in.nextInt(); }
        System.out.println(solve(n, m, friends, s, kind));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
