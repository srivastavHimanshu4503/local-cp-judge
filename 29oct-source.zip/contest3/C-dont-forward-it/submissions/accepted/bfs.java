import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    static int solve(int n, int m, int[][] friends, int s, String kind) {
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) adj.add(new ArrayList<>());
        for (int[] f : friends) { adj.get(f[0]).add(f[1]); adj.get(f[1]).add(f[0]); }
        boolean[] heard = new boolean[n + 1];
        heard[s] = true;
        ArrayDeque<Integer> q = new ArrayDeque<>();
        q.add(s);
        int count = 0;
        while (!q.isEmpty()) {
            int u = q.poll();
            count++;
            if (kind.charAt(u - 1) == '1') continue;
            for (int v : adj.get(u))
                if (!heard[v]) { heard[v] = true; q.add(v); }
        }
        return count;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int s = in.nextInt();
        String kind = in.next();
        int[][] friends = new int[m][2];
        for (int j = 0; j < m; j++) { friends[j][0] = in.nextInt(); friends[j][1] = in.nextInt(); }
        System.out.println(solve(n, m, friends, s, kind));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
