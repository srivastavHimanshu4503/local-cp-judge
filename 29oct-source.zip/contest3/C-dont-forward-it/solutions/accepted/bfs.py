from collections import deque


def solve(n, m, friends, s, kind):
    adj = [[] for _ in range(n + 1)]
    for u, v in friends:
        adj[u].append(v)
        adj[v].append(u)
    heard = [False] * (n + 1)
    heard[s] = True
    q = deque([s])
    count = 0
    while q:
        u = q.popleft()
        count += 1                      # u heard it
        if kind[u - 1] == '1':
            continue                    # kind: hears it, tells no one
        for v in adj[u]:
            if not heard[v]:
                heard[v] = True
                q.append(v)
    return count
