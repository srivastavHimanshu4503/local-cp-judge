    static int solve(int n, int m, int[][] friends, int s, String kind) {
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) adj.add(new ArrayList<>());
        for (int[] f : friends) { adj.get(f[0]).add(f[1]); adj.get(f[1]).add(f[0]); }
        boolean[] heard = new boolean[n + 1];
        heard[s] = true;
        ArrayDeque<Integer> q = new ArrayDeque<>();
        q.add(s);
        int count = 0;
        while (!q.isEmpty()) {
            int u = q.poll();
            count++;
            if (kind.charAt(u - 1) == '1') continue;
            for (int v : adj.get(u))
                if (!heard[v]) { heard[v] = true; q.add(v); }
        }
        return count;
    }
