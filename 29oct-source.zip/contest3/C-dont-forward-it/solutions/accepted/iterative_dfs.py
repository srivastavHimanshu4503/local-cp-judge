def solve(n, m, friends, s, kind):
    adj = [[] for _ in range(n + 1)]
    for u, v in friends:
        adj[u].append(v)
        adj[v].append(u)
    seen = {s}
    stack = [s]
    while stack:
        u = stack.pop()
        if kind[u - 1] == '1':
            continue
        for v in adj[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen)
