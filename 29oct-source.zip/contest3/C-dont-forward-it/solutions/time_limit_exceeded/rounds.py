# Correct but O(m * rounds): every round, scan all friendships and pass the rumour one step.
def solve(n, m, friends, s, kind):
    heard = [False] * (n + 1)
    heard[s] = True
    changed = True
    while changed:
        changed = False
        for u, v in friends:
            for x, y in ((u, v), (v, u)):
                if heard[x] and not heard[y] and kind[x - 1] != '1':
                    heard[y] = True
                    changed = True
    return sum(heard)
