    // Correct but O(m * rounds): every round, scan all friendships and pass the rumour one step.
    static int solve(int n, int m, int[][] friends, int s, String kind) {
        boolean[] heard = new boolean[n + 1];
        heard[s] = true;
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int[] f : friends) {
                int u = f[0], v = f[1];
                if (heard[u] && !heard[v] && kind.charAt(u - 1) != '1') { heard[v] = true; changed = true; }
                if (heard[v] && !heard[u] && kind.charAt(v - 1) != '1') { heard[u] = true; changed = true; }
            }
        }
        int c = 0;
        for (boolean h : heard) if (h) c++;
        return c;
    }
