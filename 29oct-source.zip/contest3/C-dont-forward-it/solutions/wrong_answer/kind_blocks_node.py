# Bug: a kind student blocks themselves, so the rumour never even reaches them.
from collections import deque


def solve(n, m, friends, s, kind):
    adj = [[] for _ in range(n + 1)]
    for u, v in friends:
        adj[u].append(v)
        adj[v].append(u)
    heard = [False] * (n + 1)
    heard[s] = True
    q = deque([s])
    cnt = 0
    while q:
        u = q.popleft()
        cnt += 1
        for v in adj[u]:
            if not heard[v] and kind[v - 1] != '1':
                heard[v] = True
                q.append(v)
    return cnt
