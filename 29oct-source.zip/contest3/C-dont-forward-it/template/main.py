import sys

# ---------------- your code starts here ----------------
def solve(n, m, friends, s, kind):
    # friends[j] = (u, v): u and v are friends
    # kind[i - 1] == '1' means student i is kind
    # return how many students hear the rumour
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m, s = int(data[0]), int(data[1]), int(data[2])
    kind = data[3].decode()
    friends = [(int(data[4 + 2 * j]), int(data[5 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, friends, s, kind)}\n")


main()
