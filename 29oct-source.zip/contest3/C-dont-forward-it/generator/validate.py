"""Strict input validator for Problem C. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+ \d+ \d+\n[01]+\n(\d+ \d+\n)*", data), "bad format"
lines = data.split("\n")[:-1]
n, m, s = map(int, lines[0].split())
assert 1 <= n <= 200_000 and 0 <= m <= 200_000 and 1 <= s <= n, "header out of range"
assert len(lines[1]) == n, "kind string length differs from n"
assert len(lines) == m + 2, "wrong number of friendships"
seen = set()
for ln in lines[2:]:
    u, v = map(int, ln.split())
    assert 1 <= u <= n and 1 <= v <= n and u != v, f"bad friendship {u} {v}"
    key = (min(u, v), max(u, v))
    assert key not in seen, f"duplicate friendship {u} {v}"
    seen.add(key)
print("OK")
