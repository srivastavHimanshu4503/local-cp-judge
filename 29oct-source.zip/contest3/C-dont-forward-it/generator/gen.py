"""Deterministic test generator for Problem C (Don't Forward It). Usage: python3 gen.py <problem_dir>

Students are relabelled with a random permutation (except where noted) so structure is not visible from numbers.
"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXN = 200_000
MAXM = 200_000

SAMPLES = [
    ("7 6 1\n0010000\n1 2\n1 3\n2 4\n3 5\n5 6\n6 7\n", "Statement example 1: one kind student shields three others"),
    ("3 2 2\n010\n1 2\n2 3\n", "Statement example 2: the starting student is kind"),
    ("6 5 1\n010000\n1 2\n1 3\n2 4\n3 4\n4 5\n", "Statement example 3: a second path goes around the kind student; student 6 is isolated"),
]


def fmt(n, s, kind, edges):
    return f"{n} {len(edges)} {s}\n" + "".join("1" if k else "0" for k in kind[1:]) + "\n" +         "".join(f"{u} {v}\n" for u, v in edges)


def relabel(rng, n, s, kind, edges, shuffle_edges=True):
    perm = list(range(1, n + 1))
    rng.shuffle(perm)
    mp = [0] + perm
    nk = [False] * (n + 1)
    for i in range(1, n + 1):
        nk[mp[i]] = kind[i]
    e = [(mp[u], mp[v]) if rng.random() < 0.5 else (mp[v], mp[u]) for u, v in edges]
    if shuffle_edges:
        rng.shuffle(e)
    return n, mp[s], nk, e


def random_graph(rng, n, m):
    s = set()
    while len(s) < m:
        u, v = rng.randint(1, n), rng.randint(1, n)
        if u != v and (u, v) not in s and (v, u) not in s:
            s.add((u, v))
    return list(s)


def busiest(n, edges):
    deg = [0] * (n + 1)
    for u, v in edges:
        deg[u] += 1
        deg[v] += 1
    return max(range(1, n + 1), key=lambda i: deg[i])


def random_kind(rng, n, p):
    return [False] + [rng.random() < p for _ in range(n)]


def secret_tests():
    rng = random.Random(20261101)
    t = []
    t.append((fmt(1, 1, [False, False], []), "n = 1, not kind: answer 1"))
    t.append((fmt(1, 1, [False, True], []), "n = 1, kind: answer 1"))
    t.append((fmt(5, 3, [False] * 6, []), "no friendships at all: answer 1"))
    for i in range(6):
        n = rng.randint(2, 10)
        m = rng.randint(n - 1, n * (n - 1) // 2)
        g = random_graph(rng, n, m)
        t.append((fmt(*relabel(rng, n, rng.randint(1, n), random_kind(rng, n, 0.3), g)),
                  f"small random #{i + 1} (n = {n}, m = {m})"))

    n = MAXN
    edges = [(i, i + 1) for i in range(n - 1, 0, -1)]  # listed back to front
    t.append((fmt(n, 1, [False] * (n + 1), edges),
              "chain of 200000 from student 1, nobody kind, friendships listed back to front: answer n"))
    kind = [False] * (n + 1)
    kind[n // 2] = True
    t.append((fmt(n, 1, kind, edges), "same chain, the middle student is kind: answer 100000"))
    kind = [False] * (n + 1)
    kind[1] = True
    t.append((fmt(*relabel(rng, n, 1, kind, [(i, i + 1) for i in range(1, n)])), "chain, the starting student is kind: answer 1"))

    # star with kind centre, start at a leaf
    kind = [False] * (n + 1)
    kind[1] = True
    star = [(1, i) for i in range(2, n + 1)]
    t.append((fmt(*relabel(rng, n, 2, kind, star)), "star whose centre is kind, rumour starts at a leaf: answer 2"))
    t.append((fmt(*relabel(rng, n, 1, kind, star)), "star whose centre is kind and starts it: answer 1"))

    kind = [False] + [True] * n
    g = random_graph(rng, n, MAXM)
    t.append((fmt(*relabel(rng, n, busiest(n, g), kind, g)), "everybody kind: answer 1"))
    g = random_graph(rng, n, MAXM)
    t.append((fmt(*relabel(rng, n, busiest(n, g), [False] * (n + 1), g)), "nobody kind: the whole connected group hears it"))

    for p in (0.05, 0.15, 0.3):
        g = random_graph(rng, n, MAXM)
        kind = random_kind(rng, n, p)
        st = busiest(n, g)
        kind[st] = False
        t.append((fmt(*relabel(rng, n, st, kind, g)), f"max random graph, {int(p * 100)}% kind, starts at the busiest student"))
    g = random_graph(rng, 50_000, MAXM)
    kind = random_kind(rng, 50_000, 0.5)
    st = busiest(50_000, g)
    kind[st] = False
    t.append((fmt(*relabel(rng, 50_000, st, kind, g)), "dense random graph (n = 50000), half the students kind"))

    # many separate groups
    edges = []
    base = 1
    while base + 50 <= n:
        sz = rng.randint(2, 50)
        edges += [(base + j, base + rng.randrange(j)) for j in range(1, sz)]
        base += sz
    t.append((fmt(*relabel(rng, n, rng.randint(1, base - 1), random_kind(rng, n, 0.2), edges)), "many small separate groups"))

    # ladder: two parallel chains with rungs, every second node of one rail kind
    L = n // 2
    edges = [(i, i + 1) for i in range(1, L)] + [(L + i, L + i + 1) for i in range(1, L)] + [(i, L + i) for i in range(1, L + 1, 10)]
    kind = [False] * (n + 1)
    for i in range(2, L, 2):
        kind[i] = True
    t.append((fmt(*relabel(rng, n, 1, kind, edges[:MAXM])), "ladder: a blocked rail with a parallel open rail around it"))

    # grid-like: 400 x 500 with a wall of kind students that has one gap
    R, C = 400, 500
    idx = lambda r, c: r * C + c + 1
    edges = []
    for r in range(R):
        for c in range(C):
            if c + 1 < C and len(edges) < MAXM:
                edges.append((idx(r, c), idx(r, c + 1)))
            if r + 1 < R and len(edges) < MAXM and c % 2 == 0:
                edges.append((idx(r, c), idx(r + 1, c)))
    kind = [False] * (R * C + 1)
    for r in range(R):
        if r != 123:
            kind[idx(r, 250)] = True
    t.append((fmt(*relabel(rng, R * C, idx(0, 0), kind, edges)), "grid with a wall of kind students down the middle, one gap"))

    # tree with kind students near the root
    edges = [(i, rng.randint(max(1, i - 1000), i - 1)) for i in range(2, n + 1)]
    kind = [False] * (n + 1)
    for i in rng.sample(range(2, 2000), 50):
        kind[i] = True
    t.append((fmt(*relabel(rng, n, 1, kind, edges)), "random tree, kind students near the start"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
