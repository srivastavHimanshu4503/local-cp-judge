"""Independent checker for small tests: repeat 'anyone who heard it and is allowed to talk tells
their friends' until nothing changes. Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, m, s = int(data[0]), int(data[1]), int(data[2])
kind = data[3]
assert n * (m + 1) <= 3_000_000, "too big for brute"
edges = [(int(data[4 + 2 * j]), int(data[5 + 2 * j])) for j in range(m)]
res = []
for respect in (True,):
    heard = {s}
    while True:
        talkers = {u for u in heard if not (respect and kind[u - 1] == "1")}
        new = set(heard)
        for u, v in edges:
            if u in talkers:
                new.add(v)
            if v in talkers:
                new.add(u)
        if new == heard:
            break
        heard = new
    res.append(len(heard))
print(*res)
