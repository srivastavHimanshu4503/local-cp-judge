---
title: "Problem C — Don't Forward It"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

A campus has **n** students, numbered 1 to n, and **m** friendships. Friendships go both ways.

One day, student **s** hears a rumour about someone. From then on, the same thing happens again and again: everyone who hears the rumour passes it on to **all** their friends.

Except some students are **kind**. A kind student hears the rumour, but **keeps it to themselves**. They don't pass it on to anyone. The starting student s can be kind too.

Find how many students hear the rumour, including student s.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// friends[j][0] and friends[j][1] are friends
// kind.charAt(i - 1) == '1' means student i is kind
// return how many students hear the rumour
static int solve(int n, int m, int[][] friends, int s, String kind)
```

```python
# Python
# friends[j] = (u, v): u and v are friends
# kind[i - 1] == '1' means student i is kind
# return how many students hear the rumour
def solve(n, m, friends, s, kind):
```

## Input

- The first line has three integers **n**, **m** and **s**, separated by spaces.
- The second line is a string of **n** characters, each `0` or `1`. Character *i* is `1` if student *i* is kind.
- Each of the next **m** lines has two integers **u** and **v**: students u and v are friends.

## Output

Print one integer: how many students hear the rumour.

## Constraints

- 1 ≤ n ≤ 200 000
- 0 ≤ m ≤ 200 000
- 1 ≤ s ≤ n
- 1 ≤ u, v ≤ n, u ≠ v, and no friendship appears twice.

## Example 1

Input:

```
7 6 1
0010000
1 2
1 3
2 4
3 5
5 6
6 7
```

Output:

```
4
```

**Explanation:** The friendships look like this, with student 3 kind:

```text
        1
       / \
      2   3 (kind)
      |   |
      4   5
          |
          6
          |
          7
```

Student 1 tells 2 and 3. Student 2 tells 4. Student 3 hears it but keeps it to themselves, so 5, 6 and 7 never hear it. Students 1, 2, 3 and 4 hear it, so the answer is **4**.

## Example 2

Input:

```
3 2 2
010
1 2
2 3
```

Output:

```
1
```

**Explanation:** Student 2 hears the rumour first, but student 2 is kind and keeps it to themselves. So only student 2 ever hears it, and the answer is **1**.

## Example 3

Input:

```
6 5 1
010000
1 2
1 3
2 4
3 4
4 5
```

Output:

```
5
```

**Explanation:**

```text
      1
     / \
    2   3          6 (no friends)
     \ /
      4
      |
      5
```

Student 2 is kind and doesn't pass the rumour on. But student 3 does, so the rumour still reaches 4 and then 5. Students 1 to 5 hear it, so the answer is **5**. Student 6 has no friends, so they never hear it.
