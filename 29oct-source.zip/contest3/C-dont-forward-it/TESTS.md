# Problem C — Don't Forward It: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 7, m = 6 | Statement example 1: one kind student shields three others | `4` |
| sample/02 | n = 3, m = 2 | Statement example 2: the starting student is kind | `1` |
| sample/03 | n = 6, m = 5 | Statement example 3: a second path goes around the kind student; student 6 is isolated | `5` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1, m = 0 | n = 1, not kind: answer 1 | `1` |
| secret/02 | n = 1, m = 0 | n = 1, kind: answer 1 | `1` |
| secret/03 | n = 5, m = 0 | no friendships at all: answer 1 | `1` |
| secret/04 | n = 3, m = 2 | small random #1 (n = 3, m = 2) | `3` |
| secret/05 | n = 7, m = 6 | small random #2 (n = 7, m = 6) | `5` |
| secret/06 | n = 3, m = 2 | small random #3 (n = 3, m = 2) | `2` |
| secret/07 | n = 10, m = 35 | small random #4 (n = 10, m = 35) | `10` |
| secret/08 | n = 4, m = 3 | small random #5 (n = 4, m = 3) | `1` |
| secret/09 | n = 3, m = 3 | small random #6 (n = 3, m = 3) | `3` |
| secret/10 | n = 200000, m = 199999 | chain of 200000 from student 1, nobody kind, friendships listed back to front: answer n | `200000` |
| secret/11 | n = 200000, m = 199999 | same chain, the middle student is kind: answer 100000 | `100000` |
| secret/12 | n = 200000, m = 199999 | chain, the starting student is kind: answer 1 | `1` |
| secret/13 | n = 200000, m = 199999 | star whose centre is kind, rumour starts at a leaf: answer 2 | `2` |
| secret/14 | n = 200000, m = 199999 | star whose centre is kind and starts it: answer 1 | `1` |
| secret/15 | n = 200000, m = 200000 | everybody kind: answer 1 | `1` |
| secret/16 | n = 200000, m = 200000 | nobody kind: the whole connected group hears it | `159517` |
| secret/17 | n = 200000, m = 200000 | max random graph, 5% kind, starts at the busiest student | `153108` |
| secret/18 | n = 200000, m = 200000 | max random graph, 15% kind, starts at the busiest student | `137784` |
| secret/19 | n = 200000, m = 200000 | max random graph, 30% kind, starts at the busiest student | `103065` |
| secret/20 | n = 50000, m = 200000 | dense random graph (n = 50000), half the students kind | `49010` |
| secret/21 | n = 200000, m = 192226 | many small separate groups | `22` |
| secret/22 | n = 200000, m = 200000 | ladder: a blocked rail with a parallel open rail around it | `100005` |
| secret/23 | n = 200000, m = 200000 | grid with a wall of kind students down the middle, one gap | `133761` |
| secret/24 | n = 200000, m = 199999 | random tree, kind students near the start | `79736` |
