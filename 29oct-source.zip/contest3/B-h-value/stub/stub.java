    // return the h-value
    static int solve(int n, int[] a) {
        return 0;
    }
