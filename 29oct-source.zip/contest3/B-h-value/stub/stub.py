def solve(n, a):
    # return the h-value
    return 0
