# Correct but O(n^2): try every h from n down and count each time.
def solve(n, a):
    for h in range(n, -1, -1):
        if sum(1 for x in a if x >= h) >= h:
            return h
    return 0
