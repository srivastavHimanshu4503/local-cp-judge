    // Correct but O(n^2): try every h from n down and count each time.
    static int solve(int n, int[] a) {
        for (int h = n; h >= 0; h--) {
            int c = 0;
            for (int i = 0; i < n; i++) if (a[i] >= h) c++;
            if (c >= h) return h;
        }
        return 0;
    }
