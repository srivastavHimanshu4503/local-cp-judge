def solve(n, a):
    a.sort(reverse=True)
    h = 0
    while h < n and a[h] >= h + 1:  # the (h+1)-th largest is at least h+1
        h += 1
    return h
