    static int solve(int n, int[] a) {
        Arrays.sort(a);  // increasing; the i-th largest is a[n - i]
        int h = 0;
        while (h < n && a[n - 1 - h] >= h + 1) h++;
        return h;
    }
