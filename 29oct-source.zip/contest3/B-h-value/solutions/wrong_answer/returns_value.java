    // Bug: returns the value at the boundary instead of h.
    static int solve(int n, int[] a) {
        Arrays.sort(a);
        int h = 0;
        while (h < n && a[n - 1 - h] >= h + 1) h++;
        return h == 0 ? 0 : a[n - h];
    }
