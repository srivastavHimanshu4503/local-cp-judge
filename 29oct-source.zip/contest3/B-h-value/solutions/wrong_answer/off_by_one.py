# Bug: compares the (i+1)-th largest with i instead of i+1.
def solve(n, a):
    a.sort(reverse=True)
    h = 0
    for i in range(n):
        if a[i] >= i:
            h = i + 1
    return h
