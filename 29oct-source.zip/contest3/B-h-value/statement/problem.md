---
title: "Problem B — The h-Value"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

You are given **n** non-negative integers. The **h-value** of the list is the largest number **h** such that at least **h** of the numbers are **≥ h**.

Find the h-value.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// return the h-value
static int solve(int n, int[] a)
```

```python
# Python
# return the h-value
def solve(n, a):
```

## Input

- The first line has one integer **n**.
- The second line has **n** integers a~1~, a~2~, …, a~n~, separated by spaces.

## Output

Print one integer: the h-value.

## Constraints

- 1 ≤ n ≤ 200 000
- 0 ≤ a~i~ ≤ 10^9^

## Example 1

Input:

```
6
3 0 6 1 5 3
```

Output:

```
3
```

**Explanation:** Sorted from largest to smallest, the numbers are 6, 5, 3, 3, 1, 0.

| h | Numbers ≥ h | How many | At least h of them? |
|:---:|:---:|:---:|:---:|
| 3 | 6, 5, 3, 3 | 4 | yes, 4 ≥ 3 |
| 4 | 6, 5 | 2 | no, 2 < 4 |

For every h larger than 4, there are even fewer numbers ≥ h. So the answer is **3**.

## Example 2

Input:

```
3
100 200 300
```

Output:

```
3
```

**Explanation:** All 3 numbers are ≥ 3, so h = 3 works. h = 4 would need at least 4 numbers, but there are only 3. So the answer is **3**. The h-value can never be larger than n.

## Example 3

Input:

```
5
4 4 4 4 4
```

Output:

```
4
```

**Explanation:**

- h = 4 works: all 5 numbers are ≥ 4, and 5 ≥ 4.
- h = 5 fails: none of the numbers is ≥ 5.

So the answer is **4**.
