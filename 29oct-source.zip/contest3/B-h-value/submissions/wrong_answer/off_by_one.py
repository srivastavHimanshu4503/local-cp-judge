import sys

# ---------------- your code starts here ----------------
# Bug: compares the (i+1)-th largest with i instead of i+1.
def solve(n, a):
    a.sort(reverse=True)
    h = 0
    for i in range(n):
        if a[i] >= i:
            h = i + 1
    return h
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
