import sys

# ---------------- your code starts here ----------------
def solve(n, a):
    a.sort(reverse=True)
    h = 0
    while h < n and a[h] >= h + 1:  # the (h+1)-th largest is at least h+1
        h += 1
    return h
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
