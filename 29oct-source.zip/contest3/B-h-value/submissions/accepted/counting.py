import sys

# ---------------- your code starts here ----------------
# O(n): count values, capping anything above n at n.
def solve(n, a):
    cnt = [0] * (n + 1)
    for x in a:
        cnt[min(x, n)] += 1
    at_least = 0
    for h in range(n, -1, -1):
        at_least += cnt[h]
        if at_least >= h:
            return h
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
