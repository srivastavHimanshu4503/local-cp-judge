import sys

# ---------------- your code starts here ----------------
# Correct but O(n^2): try every h from n down and count each time.
def solve(n, a):
    for h in range(n, -1, -1):
        if sum(1 for x in a if x >= h) >= h:
            return h
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
