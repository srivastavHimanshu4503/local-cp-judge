# Problem B — The h-Value: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 6 | Statement example 1: answer 3 | `3` |
| sample/02 | n = 3 | Statement example 2: the answer can never exceed n | `3` |
| sample/03 | n = 5 | Statement example 3: all equal, answer 4 | `4` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1 | n = 1, value 0: answer 0 | `0` |
| secret/02 | n = 1 | n = 1, value 10^9: answer 1 | `1` |
| secret/03 | n = 2 | two 1s: answer 1 | `1` |
| secret/04 | n = 2 | two 2s: answer 2 | `2` |
| secret/05 | n = 9 | small random #1 (n = 9) | `7` |
| secret/06 | n = 5 | small random #2 (n = 5) | `4` |
| secret/07 | n = 5 | small random #3 (n = 5) | `3` |
| secret/08 | n = 11 | small random #4 (n = 11) | `6` |
| secret/09 | n = 4 | small random #5 (n = 4) | `4` |
| secret/10 | n = 3 | small random #6 (n = 3) | `3` |
| secret/11 | n = 200000 | max n, all zeros: answer 0 (trying every h counts n times) | `0` |
| secret/12 | n = 200000 | max n, all ones: answer 1 | `1` |
| secret/13 | n = 200000 | max n, all 10^9: answer n | `200000` |
| secret/14 | n = 200000 | max n, values 0..3: tiny answer | `3` |
| secret/15 | n = 200000 | max n, all equal to 100000: answer 100000 | `100000` |
| secret/16 | n = 200000 | max n, a permutation of 0..n-1: answer 100000 | `100000` |
| secret/17 | n = 200000 | max n, values 0..n, sorted increasing | `100069` |
| secret/18 | n = 200000 | max n, values 0..n, sorted decreasing | `100181` |
| secret/19 | n = 200000 | max n random values up to 10^9 | `199967` |
| secret/20 | n = 200000 | max n, many duplicates exactly at the answer 77777 | `77777` |
| secret/21 | n = 200000 | max n, exactly 50000 values >= 50000 and the rest are 49999: answer 50000 | `50000` |
| secret/22 | n = 200000 | max n, values 0..50 (answer far below n) | `50` |
