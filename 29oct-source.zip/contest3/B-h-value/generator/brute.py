"""Independent checker for small tests: straight from the definition. Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n = int(data[0])
a = [int(x) for x in data[1:1 + n]]
assert n <= 2000, "too big for brute"
print(max(h for h in range(n + 1) if sum(x >= h for x in a) >= h))
