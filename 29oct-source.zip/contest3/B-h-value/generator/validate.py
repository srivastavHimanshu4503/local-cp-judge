"""Strict input validator for Problem B. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+\n\d+( \d+)*\n", data), "bad format"
lines = data.split("\n")
n = int(lines[0])
assert 1 <= n <= 200_000, "n out of range"
a = list(map(int, lines[1].split()))
assert len(a) == n and all(0 <= x <= 10**9 for x in a), "bad values"
print("OK")
