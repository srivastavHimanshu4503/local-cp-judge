"""Deterministic test generator for Problem B (The h-Value). Usage: python3 gen.py <problem_dir>"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXN = 200_000
MAXV = 10**9

SAMPLES = [
    ("6\n3 0 6 1 5 3\n", "Statement example 1: answer 3"),
    ("3\n100 200 300\n", "Statement example 2: the answer can never exceed n"),
    ("5\n4 4 4 4 4\n", "Statement example 3: all equal, answer 4"),
]


def fmt(a):
    return f"{len(a)}\n" + " ".join(map(str, a)) + "\n"


def secret_tests():
    rng = random.Random(20261029)
    t = []
    t.append((fmt([0]), "n = 1, value 0: answer 0"))
    t.append((fmt([MAXV]), "n = 1, value 10^9: answer 1"))
    t.append((fmt([1, 1]), "two 1s: answer 1"))
    t.append((fmt([2, 2]), "two 2s: answer 2"))
    for i in range(6):
        n = rng.randint(1, 12)
        t.append((fmt([rng.randint(0, 15) for _ in range(n)]), f"small random #{i + 1} (n = {n})"))
    t.append((fmt([0] * MAXN), "max n, all zeros: answer 0 (trying every h counts n times)"))
    t.append((fmt([1] * MAXN), "max n, all ones: answer 1"))
    t.append((fmt([MAXV] * MAXN), "max n, all 10^9: answer n"))
    t.append((fmt([rng.randint(0, 3) for _ in range(MAXN)]), "max n, values 0..3: tiny answer"))
    t.append((fmt([100_000] * MAXN), "max n, all equal to 100000: answer 100000"))
    a = list(range(MAXN))
    rng.shuffle(a)
    t.append((fmt(a), "max n, a permutation of 0..n-1: answer 100000"))
    t.append((fmt(sorted(rng.randint(0, MAXN) for _ in range(MAXN))), "max n, values 0..n, sorted increasing"))
    t.append((fmt(sorted((rng.randint(0, MAXN) for _ in range(MAXN)), reverse=True)), "max n, values 0..n, sorted decreasing"))
    t.append((fmt([rng.randint(0, MAXV) for _ in range(MAXN)]), "max n random values up to 10^9"))
    h = 77_777
    a = [h] * (h + 5) + [h - 1] * 1000 + [rng.randint(0, h - 1) for _ in range(MAXN - h - 1005)]
    rng.shuffle(a)
    t.append((fmt(a), "max n, many duplicates exactly at the answer 77777"))
    h = 50_000
    a = [h + rng.randint(0, 5) for _ in range(h)] + [h - 1] * (MAXN - h)
    rng.shuffle(a)
    t.append((fmt(a), "max n, exactly 50000 values >= 50000 and the rest are 49999: answer 50000"))
    t.append((fmt([rng.randint(0, 50) for _ in range(MAXN)]), "max n, values 0..50 (answer far below n)"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
