# Contest package: four problems, 2 hours

| | Problem | Topic | Python function | Java method | Time limit (Java / Python) | Secret tests |
|---|---|---|---|---|---|---|
| A | Busy Blocks | sorting | `solve(n, intervals)` | `int[] solve(int n, int[][] intervals)` | 2 s / 6 s | 24 |
| B | Delayed Printers | binary search on the answer | `solve(n, m, s, p)` | `long solve(int n, int m, int[] s, int[] p)` | 2 s / 6 s | 22 |
| C | Widest Window | sliding window, heaps with lazy deletion | `solve(n, k, a)` | `int solve(int n, int k, int[] a)` | 3 s / 9 s | 27 |
| D | Task Rounds | graphs: topological sort by levels | `solve(n, m, deps)` | `int solve(int n, int m, int[][] deps)` | 2 s / 6 s | 25 |

Each problem also has 3 sample tests (the statement examples). The memory limit is 1024 MB for every problem.

## Importing into DOMjudge

1. Import the four zips from `dist/domjudge/` (Jury → Problems → Import, or with the contest). Each zip holds `problem.yaml`, `domjudge-problem.ini` (short name, name, time limit, colour), `problem.pdf`, all sample and secret tests, and the jury submissions.
2. The Python limits assume DOMjudge's **time factor for Python 3 is 3** (Jury → Languages → python3). That is how the 2 s / 6 s split worked in your earlier contests.
3. After import, DOMjudge judges the jury submissions. Every one of them should get the verdict of its folder: `accepted`, `wrong_answer`, or `time_limit_exceeded`. If a `time_limit_exceeded` submission is accepted on your server, its hardware is much faster than expected; tell me and I'll tighten the tests.
4. The zips are 8–24 MB. If the web import rejects one, the server's PHP `upload_max_filesize` / `post_max_size` is too small; raise it, or import through the API.

## What is in each problem folder

| Path | What it is |
|---|---|
| `statement/problem.md` | Statement source with exact input/output format and copy-pasteable samples. `problem.html` and `problem.pdf` are rendered from it. |
| `harness/` | The I/O code (`harness.py`, `Harness.java`). The student's function goes at the `{{STUDENT_CODE}}` marker. |
| `stub/` | Only the function the student starts from. |
| `template/` | Harness + stub as one runnable file (`main.py`, `Main.java`), for a contest page that shows the whole program. |
| `solutions/` | Function-only jury solutions in `accepted`, `wrong_answer` and `time_limit_exceeded`. |
| `submissions/` | The same solutions assembled with the harness into full programs. DOMjudge imports these as jury submissions. |
| `generator/` | `gen.py` (deterministic test generator), `validate.py` (strict input checker), `brute.py` (independent slow checker for small tests). |
| `data/sample`, `data/secret` | The tests: `.in` input, `.ans` expected output, `.desc` one-line description. |
| `TESTS.md` | Catalog of every test: what it targets and its expected output. |
| `verification-report.txt` | Result of judging every jury submission against every test. |

`statements/contest-problems.pdf` is the printable booklet: a one-page rules sheet followed by all four problems. Single-problem PDFs are next to it.

## Rebuilding

```
python3 tools/build.py        # regenerate tests, validate, cross-check, judge all jury submissions
python3 tools/package.py      # render statements, write metadata and TESTS.md, build dist/domjudge/*.zip
```

The generators use fixed seeds, so the tests come out byte-for-byte identical every time. `tools/build.py` exits with an error if any check fails.

## Checks that were run

- Every input passes the problem's strict validator.
- Every expected output was produced by the Python reference and agrees with an independently written brute-force checker on every test small enough for it (12–18 tests per problem).
- The examples in each statement match `data/sample` byte for byte.
- Every jury submission gets its expected verdict (see each `verification-report.txt`). Slowest accepted runs: A 0.43 s, B 1.20 s, C 2.91 s, D 0.69 s, all Python. Every time-limit submission was still running at twice the limit when it was stopped.

## Design notes worth knowing before the contest

- **A:** Example 2 fixes the touching-endpoints rule and Example 3 shows the nested-interval case, so the two common bugs are visible before submitting. O(n²) pairwise merging times out.
- **B:** A missing `max(0, T − s_i)` clamp fails **Example 1 in both languages**: Java's division rounds toward zero, but a printer that starts more than p_i seconds after T still gives a negative count. Using an `int` page counter also fails Example 1, because the search starts with T near 2 × 10¹³. Page-by-page heap simulation times out (m up to 10⁹).
- **C:** n goes up to **10⁶** (not 2 × 10⁵), with a **3 s / 9 s** limit. At n = 2 × 10⁵, a plain Java double loop over every window ran in 0.65 s, because the JIT vectorises it, so brute force would have passed. At n = 10⁶ with k = n/2, the same loop takes about 30 s, while the two-heap Python solution needs 2.9 s. Monotonic deques are also accepted.
- **D:** Example 2 has a cycle in only part of the graph, so forgetting to check that all n tasks were processed fails a sample. A first-visit BFS (shortest chain instead of longest) fails the hidden tests. Recursive DFS in Python hits the recursion limit on the 200 000-task chain, so Python students need Kahn's algorithm or an iterative DFS.
