import sys

# ---------------- your code starts here ----------------
def solve(n, m, s, p):
    def pages(T):
        total = 0
        for si, pi in zip(s, p):
            if T > si:
                total += (T - si) // pi
        return total

    lo, hi = 0, 2 * 10**13  # pages(lo) < m, pages(hi) >= m
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if pages(mid) >= m:
            hi = mid
        else:
            lo = mid
    return hi
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    s = [int(data[2 + 2 * i]) for i in range(n)]
    p = [int(data[3 + 2 * i]) for i in range(n)]
    sys.stdout.write(f"{solve(n, m, s, p)}\n")


main()
