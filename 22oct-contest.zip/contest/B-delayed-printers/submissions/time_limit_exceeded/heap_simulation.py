import sys

# ---------------- your code starts here ----------------
# Correct but O(m log n): take the next finished page from a heap, one page at a time.
import heapq


def solve(n, m, s, p):
    h = [(s[i] + p[i], i) for i in range(n)]
    heapq.heapify(h)
    t = 0
    for _ in range(m):
        t, i = heapq.heappop(h)
        heapq.heappush(h, (t + p[i], i))
    return t
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    s = [int(data[2 + 2 * i]) for i in range(n)]
    p = [int(data[3 + 2 * i]) for i in range(n)]
    sys.stdout.write(f"{solve(n, m, s, p)}\n")


main()
