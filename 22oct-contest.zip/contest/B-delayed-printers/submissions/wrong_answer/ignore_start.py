import sys

# ---------------- your code starts here ----------------
# Bug: memorised Factory Machines; ignores start times completely.
def solve(n, m, s, p):
    lo, hi = 0, 2 * 10**13
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if sum(mid // pi for pi in p) >= m:
            hi = mid
        else:
            lo = mid
    return hi
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    s = [int(data[2 + 2 * i]) for i in range(n)]
    p = [int(data[3 + 2 * i]) for i in range(n)]
    sys.stdout.write(f"{solve(n, m, s, p)}\n")


main()
