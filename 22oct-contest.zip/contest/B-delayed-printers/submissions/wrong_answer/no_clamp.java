import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // Bug: no max(0, T - s_i). Java division truncates toward zero, but a printer that
    // starts more than p_i seconds after T still contributes a negative count.
    static long solve(int n, int m, int[] s, int[] p) {
        long lo = 0, hi = 20_000_000_000_000L;
        while (hi - lo > 1) {
            long mid = (lo + hi) / 2;
            long total = 0;
            for (int i = 0; i < n; i++) total += (mid - s[i]) / p[i];
            if (total >= m) hi = mid;
            else lo = mid;
        }
        return hi;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int[] s = new int[n];
        int[] p = new int[n];
        for (int i = 0; i < n; i++) {
            s[i] = in.nextInt();
            p[i] = in.nextInt();
        }
        System.out.println(solve(n, m, s, p));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
