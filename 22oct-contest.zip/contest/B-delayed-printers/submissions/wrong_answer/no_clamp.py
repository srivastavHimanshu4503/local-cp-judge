import sys

# ---------------- your code starts here ----------------
# Bug: no max(0, T - s_i); printers that have not started yet count negative pages.
def solve(n, m, s, p):
    def pages(T):
        return sum((T - si) // pi for si, pi in zip(s, p))

    lo, hi = 0, 2 * 10**13
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if pages(mid) >= m:
            hi = mid
        else:
            lo = mid
    return hi
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    s = [int(data[2 + 2 * i]) for i in range(n)]
    p = [int(data[3 + 2 * i]) for i in range(n)]
    sys.stdout.write(f"{solve(n, m, s, p)}\n")


main()
