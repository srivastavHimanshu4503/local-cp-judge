# Problem B — Delayed Printers: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 3, m = 6 | Statement example 1: a printer that has not started contributes 0 | `8` |
| sample/02 | n = 2, m = 4 | Statement example 2: a late fast printer beats an early slow one | `9` |
| sample/03 | n = 1, m = 3 | Statement example 3: single printer | `17` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1, m = 1 | n = 1, m = 1: answer 1 | `1` |
| secret/02 | n = 1, m = 1000000000 | n = 1, largest possible answer: 10^9 + 10^13 | `10001000000000` |
| secret/03 | n = 1, m = 1000000000 | n = 1, s = 0, p = 1, m = 10^9 | `1000000000` |
| secret/04 | n = 5, m = 5 | five identical printers, answer exactly when they all finish together | `10` |
| secret/05 | n = 6, m = 7 | small random #1 (n = 6) | `7` |
| secret/06 | n = 2, m = 25 | small random #2 (n = 2) | `41` |
| secret/07 | n = 2, m = 15 | small random #3 (n = 2) | `27` |
| secret/08 | n = 1, m = 12 | small random #4 (n = 1) | `30` |
| secret/09 | n = 2, m = 2 | small random #5 (n = 2) | `17` |
| secret/10 | n = 2, m = 19 | small random #6 (n = 2) | `18` |
| secret/11 | n = 200000, m = 1000000000 | max n, every printer starts at 0 (plain Factory Machines case), m = 10^9 | `5194087` |
| secret/12 | n = 200000, m = 1000000000 | max n, all s = 0 and p = 1, m = 10^9: answer 5000 (page counts above 2^31 inside the search) | `5000` |
| secret/13 | n = 200000, m = 1000000000 | max n, every printer starts at 10^9 | `1005061668` |
| secret/14 | n = 200000, m = 1000 | one printer starts at 0, the rest start near 10^9: answer 1000 (missing clamp fails) | `1000` |
| secret/15 | n = 200000, m = 300 | ten early printers finish before the others start: answer 1500 (missing clamp fails) | `1500` |
| secret/16 | n = 200000, m = 1000000000 | many slow early printers and one fast printer that starts at 5*10^8 | `50010000` |
| secret/17 | n = 200000, m = 6293209 | max n, start times spread over [0, 10^9] (ignoring start times fails) | `1210025` |
| secret/18 | n = 200000, m = 1000000000 | max n random, m = 10^9 | `106798209` |
| secret/19 | n = 200000, m = 1000000000 | max n, small start times and fast printers, m = 10^9 | `17126` |
| secret/20 | n = 200000, m = 1 | max n random, m = 1: answer is min(s_i + p_i) | `9712` |
| secret/21 | n = 200000, m = 326502795 | max n random, random m | `2191615` |
| secret/22 | n = 200000, m = 1000000000 | max n, start times and speeds sharing a common period of 6 (many pages finish at once) | `10162` |
