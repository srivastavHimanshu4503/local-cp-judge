    // Correct but O(m log n): take the next finished page from a heap, one page at a time.
    static long solve(int n, int m, int[] s, int[] p) {
        PriorityQueue<long[]> pq = new PriorityQueue<>((x, y) -> Long.compare(x[0], y[0]));
        for (int i = 0; i < n; i++) pq.add(new long[]{(long) s[i] + p[i], i});
        long t = 0;
        for (int k = 0; k < m; k++) {
            long[] top = pq.poll();
            t = top[0];
            top[0] += p[(int) top[1]];
            pq.add(top);
        }
        return t;
    }
