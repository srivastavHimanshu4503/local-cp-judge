# Correct but O(m log n): take the next finished page from a heap, one page at a time.
import heapq


def solve(n, m, s, p):
    h = [(s[i] + p[i], i) for i in range(n)]
    heapq.heapify(h)
    t = 0
    for _ in range(m):
        t, i = heapq.heappop(h)
        heapq.heappush(h, (t + p[i], i))
    return t
