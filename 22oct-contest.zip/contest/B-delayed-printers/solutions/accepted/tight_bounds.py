# Same idea with a tight upper bound and early exit in the check.
def solve(n, m, s, p):
    hi = min(si + pi * m for si, pi in zip(s, p))
    lo = min(s)

    def enough(T):
        total = 0
        for si, pi in zip(s, p):
            if T > si:
                total += (T - si) // pi
                if total >= m:
                    return True
        return False

    while lo < hi:
        mid = (lo + hi) // 2
        if enough(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo
