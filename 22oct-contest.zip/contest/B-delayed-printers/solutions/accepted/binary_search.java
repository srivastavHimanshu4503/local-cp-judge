    static long pages(long T, int n, int[] s, int[] p) {
        long total = 0;
        for (int i = 0; i < n; i++)
            if (T > s[i]) total += (T - s[i]) / p[i];
        return total;
    }

    static long solve(int n, int m, int[] s, int[] p) {
        long lo = 0, hi = 20_000_000_000_000L;
        while (hi - lo > 1) {
            long mid = (lo + hi) / 2;
            if (pages(mid, n, s, p) >= m) hi = mid;
            else lo = mid;
        }
        return hi;
    }
