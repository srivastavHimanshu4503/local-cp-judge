# Bug: memorised Factory Machines; ignores start times completely.
def solve(n, m, s, p):
    lo, hi = 0, 2 * 10**13
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if sum(mid // pi for pi in p) >= m:
            hi = mid
        else:
            lo = mid
    return hi
