    // Bug: no max(0, T - s_i). Java division truncates toward zero, but a printer that
    // starts more than p_i seconds after T still contributes a negative count.
    static long solve(int n, int m, int[] s, int[] p) {
        long lo = 0, hi = 20_000_000_000_000L;
        while (hi - lo > 1) {
            long mid = (lo + hi) / 2;
            long total = 0;
            for (int i = 0; i < n; i++) total += (mid - s[i]) / p[i];
            if (total >= m) hi = mid;
            else lo = mid;
        }
        return hi;
    }
