# Bug: no max(0, T - s_i); printers that have not started yet count negative pages.
def solve(n, m, s, p):
    def pages(T):
        return sum((T - si) // pi for si, pi in zip(s, p))

    lo, hi = 0, 2 * 10**13
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if pages(mid) >= m:
            hi = mid
        else:
            lo = mid
    return hi
