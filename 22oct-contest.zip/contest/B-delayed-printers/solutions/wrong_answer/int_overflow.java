    // Bug: accumulates the page count in an int.
    static long solve(int n, int m, int[] s, int[] p) {
        long lo = 0, hi = 20_000_000_000_000L;
        while (hi - lo > 1) {
            long mid = (lo + hi) / 2;
            int total = 0;
            for (int i = 0; i < n; i++)
                if (mid > s[i]) total += (mid - s[i]) / p[i];
            if (total >= m) hi = mid;
            else lo = mid;
        }
        return hi;
    }
