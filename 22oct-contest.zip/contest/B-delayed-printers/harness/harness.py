import sys

# ---------------- your code starts here ----------------
{{STUDENT_CODE}}
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    s = [int(data[2 + 2 * i]) for i in range(n)]
    p = [int(data[3 + 2 * i]) for i in range(n)]
    sys.stdout.write(f"{solve(n, m, s, p)}\n")


main()
