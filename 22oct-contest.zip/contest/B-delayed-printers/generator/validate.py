"""Strict input validator for Problem B. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"(\d+ \d+\n)(\d+ \d+\n)+", data), "bad format"
lines = data.split("\n")[:-1]
n, m = map(int, lines[0].split())
assert 1 <= n <= 200_000, "n out of range"
assert 1 <= m <= 10**9, "m out of range"
assert len(lines) == n + 1, "wrong number of lines"
for ln in lines[1:]:
    s, p = map(int, ln.split())
    assert 0 <= s <= 10**9, f"bad s {s}"
    assert 1 <= p <= 10**4, f"bad p {p}"
print("OK")
