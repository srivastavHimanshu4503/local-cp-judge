"""Independent checker for small tests: list every page's finishing time, sort, take the m-th.
Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, m = int(data[0]), int(data[1])
assert n * m <= 3_000_000, "too big for brute"
times = []
for i in range(n):
    s, p = int(data[2 + 2 * i]), int(data[3 + 2 * i])
    times.extend(s + p * k for k in range(1, m + 1))
times.sort()
print(times[m - 1])
