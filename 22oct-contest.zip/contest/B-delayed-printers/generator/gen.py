"""Deterministic test generator for Problem B (Delayed Printers).

Usage: python3 gen.py <problem_dir>
"""
import os
import random
import sys

MAXN = 200_000
MAXM = 10**9
MAXS = 10**9
MAXP = 10**4

SAMPLES = [
    ("3 6\n0 3\n4 1\n10 2\n", "Statement example 1: a printer that has not started contributes 0"),
    ("2 4\n5 1\n0 10\n", "Statement example 2: a late fast printer beats an early slow one"),
    ("1 3\n2 5\n", "Statement example 3: single printer"),
]


def fmt(m, pr):
    return f"{len(pr)} {m}\n" + "".join(f"{s} {p}\n" for s, p in pr)


def secret_tests():
    rng = random.Random(20261022)
    t = []
    t.append((1, [(0, 1)], "n = 1, m = 1: answer 1"))
    t.append((MAXM, [(MAXS, MAXP)], "n = 1, largest possible answer: 10^9 + 10^13"))
    t.append((MAXM, [(0, 1)], "n = 1, s = 0, p = 1, m = 10^9"))
    t.append((5, [(7, 3)] * 5, "five identical printers, answer exactly when they all finish together"))

    for i in range(6):
        n = rng.randint(1, 6)
        pr = [(rng.randint(0, 20), rng.randint(1, 5)) for _ in range(n)]
        t.append((rng.randint(1, 30), pr, f"small random #{i + 1} (n = {n})"))

    pr = [(0, rng.randint(1, MAXP)) for _ in range(MAXN)]
    t.append((MAXM, pr, "max n, every printer starts at 0 (plain Factory Machines case), m = 10^9"))

    pr = [(0, 1)] * MAXN
    t.append((MAXM, pr, "max n, all s = 0 and p = 1, m = 10^9: answer 5000 (page counts above 2^31 inside the search)"))

    pr = [(MAXS, rng.randint(1, MAXP)) for _ in range(MAXN)]
    t.append((MAXM, pr, "max n, every printer starts at 10^9"))

    pr = [(0, 1)] + [(MAXS - rng.randint(0, 1000), rng.randint(1, 3)) for _ in range(MAXN - 1)]
    rng.shuffle(pr)
    t.append((1000, pr, "one printer starts at 0, the rest start near 10^9: answer 1000 (missing clamp fails)"))

    pr = [(0, 50)] * 10 + [(rng.randint(2000, 10**6), rng.randint(1, 20)) for _ in range(MAXN - 10)]
    rng.shuffle(pr)
    t.append((300, pr, "ten early printers finish before the others start: answer 1500 (missing clamp fails)"))

    pr = [(0, MAXP)] * (MAXN - 1) + [(5 * 10**8, 1)]
    rng.shuffle(pr)
    t.append((MAXM, pr, "many slow early printers and one fast printer that starts at 5*10^8"))

    pr = [(rng.randint(0, MAXS), rng.randint(1, 100)) for _ in range(MAXN)]
    t.append((rng.randint(10**6, 10**7), pr, "max n, start times spread over [0, 10^9] (ignoring start times fails)"))

    pr = [(rng.randint(0, MAXS), rng.randint(1, MAXP)) for _ in range(MAXN)]
    t.append((MAXM, pr, "max n random, m = 10^9"))

    pr = [(rng.randint(0, 100), rng.randint(1, 10)) for _ in range(MAXN)]
    t.append((MAXM, pr, "max n, small start times and fast printers, m = 10^9"))

    pr = [(rng.randint(0, MAXS), rng.randint(1, MAXP)) for _ in range(MAXN)]
    t.append((1, pr, "max n random, m = 1: answer is min(s_i + p_i)"))

    pr = [(rng.randint(0, 10**6), rng.randint(1, MAXP)) for _ in range(MAXN)]
    t.append((rng.randint(1, MAXM), pr, "max n random, random m"))

    # answer lands exactly on many printers' page boundaries
    pr = [(rng.randint(0, 50) * 6, rng.choice([1, 2, 3, 6])) for _ in range(MAXN)]
    t.append((MAXM, pr, "max n, start times and speeds sharing a common period of 6 (many pages finish at once)"))
    return t


def write(dirpath, name, content, desc):
    with open(os.path.join(dirpath, name + ".in"), "w") as f:
        f.write(content)
    with open(os.path.join(dirpath, name + ".desc"), "w") as f:
        f.write(desc + "\n")


def main():
    root = sys.argv[1]
    sd = os.path.join(root, "data", "sample")
    xd = os.path.join(root, "data", "secret")
    for d in (sd, xd):
        os.makedirs(d, exist_ok=True)
        for f in os.listdir(d):
            os.remove(os.path.join(d, f))
    for i, (content, desc) in enumerate(SAMPLES, 1):
        write(sd, f"{i:02d}", content, desc)
    for i, (m, pr, desc) in enumerate(secret_tests(), 1):
        write(xd, f"{i:02d}", fmt(m, pr), desc)


if __name__ == "__main__":
    main()
