---
title: "Problem B — Delayed Printers"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

There are **n** printers. Printer *i* is switched on at time **s~i~**. After that, it prints one page every **p~i~** seconds, without stopping. Before time s~i~, it prints nothing. All printers work at the same time.

Find the minimum time **T** by which at least **m** pages have been printed in total.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// printer i is switched on at time s[i],
// then prints one page every p[i] seconds
// return the minimum time T
static long solve(int n, int m, int[] s, int[] p)
```

```python
# Python
# printer i is switched on at time s[i],
# then prints one page every p[i] seconds
# return the minimum time T
def solve(n, m, s, p):
```

> **Note:** The answer is at most 2 × 10^13^, which does not fit in a Java `int`. Use `long`.

## Input

- The first line has two integers **n** and **m**, separated by a space.
- Each of the next **n** lines has two integers **s~i~** and **p~i~**, separated by a space.

## Output

Print one integer: the minimum time **T**.

## Constraints

- 1 ≤ n ≤ 200 000
- 1 ≤ m ≤ 10^9^
- 0 ≤ s~i~ ≤ 10^9^
- 1 ≤ p~i~ ≤ 10^4^

## Example 1

Input:

```
3 6
0 3
4 1
10 2
```

Output:

```
8
```

**Explanation:** By time T, printer *i* has finished ⌊(T − s~i~) / p~i~⌋ pages if T ≥ s~i~, and 0 pages if T < s~i~.

| Time T | Printer 1 (starts 0, 3 s/page) | Printer 2 (starts 4, 1 s/page) | Printer 3 (starts 10, 2 s/page) | Total |
|:---:|:---:|:---:|:---:|:---:|
| 7 | ⌊7/3⌋ = 2 | ⌊3/1⌋ = 3 | not started, 0 | 5 |
| 8 | ⌊8/3⌋ = 2 | ⌊4/1⌋ = 4 | not started, 0 | **6** |

At time 8, the total reaches 6, so the answer is **8**. Printer 3 never gets a chance to help.

## Example 2

Input:

```
2 4
5 1
0 10
```

Output:

```
9
```

**Explanation:** Printer 2 starts immediately but is slow: its first page is ready only at time 10. Printer 1 starts at time 5 and then prints a page every second, finishing pages at times 6, 7, 8 and 9.

- At time 8, there are 3 + 0 = 3 pages.
- At time 9, there are 4 + 0 = 4 pages.

So the answer is **9**.

## Example 3

Input:

```
1 3
2 5
```

Output:

```
17
```

**Explanation:** The only printer starts at time 2 and needs 5 seconds per page. Its pages finish at times 7, 12 and **17**.
