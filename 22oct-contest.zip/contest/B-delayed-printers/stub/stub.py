def solve(n, m, s, p):
    # printer i is switched on at time s[i] and then prints one page every p[i] seconds
    # return the minimum time T by which at least m pages are printed
    return 0
