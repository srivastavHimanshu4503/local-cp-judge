    // printer i is switched on at time s[i] and then prints one page every p[i] seconds
    // return the minimum time T by which at least m pages are printed
    static long solve(int n, int m, int[] s, int[] p) {
        return 0;
    }
