import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // printer i is switched on at time s[i] and then prints one page every p[i] seconds
    // return the minimum time T by which at least m pages are printed
    static long solve(int n, int m, int[] s, int[] p) {
        return 0;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int[] s = new int[n];
        int[] p = new int[n];
        for (int i = 0; i < n; i++) {
            s[i] = in.nextInt();
            p[i] = in.nextInt();
        }
        System.out.println(solve(n, m, s, p));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
