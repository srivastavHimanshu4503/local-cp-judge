import sys

# ---------------- your code starts here ----------------
def solve(n, m, s, p):
    # printer i is switched on at time s[i] and then prints one page every p[i] seconds
    # return the minimum time T by which at least m pages are printed
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    s = [int(data[2 + 2 * i]) for i in range(n)]
    p = [int(data[3 + 2 * i]) for i in range(n)]
    sys.stdout.write(f"{solve(n, m, s, p)}\n")


main()
