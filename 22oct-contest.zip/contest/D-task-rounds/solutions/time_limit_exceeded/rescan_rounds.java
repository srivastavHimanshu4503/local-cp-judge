    // Correct but O(n * rounds): every round scans all tasks to find the ready ones.
    static int solve(int n, int m, int[][] deps) {
        int[] remaining = new int[n + 1];
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) adj.add(new ArrayList<>());
        for (int[] d : deps) { adj.get(d[0]).add(d[1]); remaining[d[1]]++; }
        boolean[] finished = new boolean[n + 1];
        int done = 0, rounds = 0;
        while (done < n) {
            List<Integer> ready = new ArrayList<>();
            for (int v = 1; v <= n; v++)
                if (!finished[v] && remaining[v] == 0) ready.add(v);
            if (ready.isEmpty()) return -1;
            for (int v : ready) {
                finished[v] = true;
                done++;
                for (int w : adj.get(v)) remaining[w]--;
            }
            rounds++;
        }
        return rounds;
    }
