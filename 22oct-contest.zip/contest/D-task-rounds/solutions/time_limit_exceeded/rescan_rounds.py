# Correct but O(n * rounds): every round scans all unfinished tasks to find the ready ones.
def solve(n, m, deps):
    pre = [[] for _ in range(n + 1)]
    for a, b in deps:
        pre[b].append(a)
    finished = [False] * (n + 1)
    left = list(range(1, n + 1))
    rounds = 0
    while left:
        ready = [v for v in left if all(finished[w] for w in pre[v])]
        if not ready:
            return -1
        for v in ready:
            finished[v] = True
        rounds += 1
        left = [v for v in left if not finished[v]]
    return rounds
