    // Bug: ordinary BFS from tasks with no prerequisites, marking a task the FIRST time it
    // is reached. That gives the shortest chain to each task, not the longest, and it
    // cannot see cycles that are reachable from a starting task.
    static int solve(int n, int m, int[][] deps) {
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) adj.add(new ArrayList<>());
        int[] indeg = new int[n + 1];
        for (int[] d : deps) {
            adj.get(d[0]).add(d[1]);
            indeg[d[1]]++;
        }
        int[] round = new int[n + 1];
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int v = 1; v <= n; v++)
            if (indeg[v] == 0) { round[v] = 1; q.add(v); }
        int seen = q.size(), best = 0;
        while (!q.isEmpty()) {
            int u = q.poll();
            best = Math.max(best, round[u]);
            for (int v : adj.get(u))
                if (round[v] == 0) { round[v] = round[u] + 1; seen++; q.add(v); }
        }
        return seen == n ? best : -1;
    }
