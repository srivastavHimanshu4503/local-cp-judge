# Iterative DFS: longest chain ending at each task, with three-colour cycle detection.
def solve(n, m, deps):
    pre = [[] for _ in range(n + 1)]  # pre[b] = tasks that must come before b
    for a, b in deps:
        pre[b].append(a)
    depth = [0] * (n + 1)  # rounds needed to finish this task
    state = [0] * (n + 1)  # 0 = new, 1 = on stack, 2 = done
    for start in range(1, n + 1):
        if state[start]:
            continue
        stack = [(start, 0)]
        state[start] = 1
        while stack:
            u, i = stack[-1]
            if i < len(pre[u]):
                stack[-1] = (u, i + 1)
                w = pre[u][i]
                if state[w] == 1:
                    return -1
                if state[w] == 0:
                    state[w] = 1
                    stack.append((w, 0))
            else:
                stack.pop()
                depth[u] = 1 + max((depth[w] for w in pre[u]), default=0)
                state[u] = 2
    return max(depth[1:])
