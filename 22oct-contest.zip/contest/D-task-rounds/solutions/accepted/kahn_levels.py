def solve(n, m, deps):
    adj = [[] for _ in range(n + 1)]
    indeg = [0] * (n + 1)
    for a, b in deps:
        adj[a].append(b)
        indeg[b] += 1
    current = [v for v in range(1, n + 1) if indeg[v] == 0]
    done = 0
    rounds = 0
    while current:
        rounds += 1
        done += len(current)
        nxt = []
        for u in current:
            for v in adj[u]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    nxt.append(v)
        current = nxt
    return rounds if done == n else -1
