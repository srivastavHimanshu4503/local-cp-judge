    static int solve(int n, int m, int[][] deps) {
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) adj.add(new ArrayList<>());
        int[] indeg = new int[n + 1];
        for (int[] d : deps) {
            adj.get(d[0]).add(d[1]);
            indeg[d[1]]++;
        }
        ArrayDeque<Integer> q = new ArrayDeque<>();
        int[] round = new int[n + 1];
        for (int v = 1; v <= n; v++)
            if (indeg[v] == 0) { q.add(v); round[v] = 1; }
        int done = 0, rounds = 0;
        while (!q.isEmpty()) {
            int u = q.poll();
            done++;
            rounds = Math.max(rounds, round[u]);
            for (int v : adj.get(u)) {
                if (--indeg[v] == 0) {
                    round[v] = round[u] + 1;
                    q.add(v);
                }
            }
        }
        return done == n ? rounds : -1;
    }
