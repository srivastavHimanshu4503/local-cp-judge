import sys

# ---------------- your code starts here ----------------
{{STUDENT_CODE}}
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    deps = [(int(data[2 + 2 * j]), int(data[3 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, deps)}\n")


main()
