# Problem D — Task Rounds: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 5, m = 4 | Statement example 1: three rounds | `3` |
| sample/02 | n = 4, m = 3 | Statement example 2: a cycle in part of the graph gives -1 | `-1` |
| sample/03 | n = 3, m = 0 | Statement example 3: no dependencies, one round | `1` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1, m = 0 | n = 1, m = 0: answer 1 | `1` |
| secret/02 | n = 2, m = 2 | two tasks that need each other: -1 | `-1` |
| secret/03 | n = 2, m = 1 | two tasks, task 2 before task 1: answer 2 | `2` |
| secret/04 | n = 4, m = 0 | small random DAG #1 (n = 4, m = 0) | `1` |
| secret/05 | n = 5, m = 4 | small random DAG #2 (n = 5, m = 4) | `4` |
| secret/06 | n = 6, m = 1 | small random DAG #3 (n = 6, m = 1) | `2` |
| secret/07 | n = 4, m = 2 | small random DAG #4 (n = 4, m = 2) | `2` |
| secret/08 | n = 10, m = 3 | small random graph with a 2-cycle #1 (n = 10) | `-1` |
| secret/09 | n = 3, m = 3 | small random graph with a 2-cycle #2 (n = 3) | `-1` |
| secret/10 | n = 9, m = 11 | small random graph with a 2-cycle #3 (n = 9) | `-1` |
| secret/11 | n = 200000, m = 0 | max n, m = 0: answer 1 | `1` |
| secret/12 | n = 200000, m = 199999 | max n, one chain through all tasks (shuffled): answer 200000 | `200000` |
| secret/13 | n = 200000, m = 199999 | star: one task before all others: answer 2 | `2` |
| secret/14 | n = 200000, m = 199999 | reverse star: all others before one task: answer 2 | `2` |
| secret/15 | n = 1001, m = 1999 | task needing every task of a 1000-long chain: answer 1001 (first-visit BFS gives 2) | `1001` |
| secret/16 | n = 200000, m = 80000 | 60000-long chain, a task depending on every third chain task, and 139998 free tasks | `60000` |
| secret/17 | n = 200000, m = 200000 | max size random DAG with one 2-cycle in the middle: -1 | `-1` |
| secret/18 | n = 200000, m = 200000 | one cycle through all tasks: -1 | `-1` |
| secret/19 | n = 100005, m = 100005 | a 100000-long chain that leads into a 5-cycle: -1 (every task is reachable) | `-1` |
| secret/20 | n = 5000, m = 4999 | 1000 tasks blocked behind a 3-cycle, plus an unrelated chain: -1 | `-1` |
| secret/21 | n = 200000, m = 200000 | max size random DAG | `23` |
| secret/22 | n = 200000, m = 200000 | max size random DAG with short jumps (long chains) | `52` |
| secret/23 | n = 1000, m = 200000 | n = 1000, m = 200000 dense random DAG | `577` |
| secret/24 | n = 200000, m = 198818 | many separate chains of random length (answer = longest = 2988) | `2988` |
| secret/25 | n = 200000, m = 199600 | 500 layers of 400 tasks, edges between consecutive layers | `500` |
