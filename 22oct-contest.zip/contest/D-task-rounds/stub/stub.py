def solve(n, m, deps):
    # deps[j] = (a, b): task a must be finished before task b can start
    # return the minimum number of rounds, or -1
    return 0
