    // deps[j][0] = a, deps[j][1] = b: task a must be finished before task b can start
    // return the minimum number of rounds, or -1
    static int solve(int n, int m, int[][] deps) {
        return 0;
    }
