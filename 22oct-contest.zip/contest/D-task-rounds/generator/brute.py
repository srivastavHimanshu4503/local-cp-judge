"""Independent checker for small tests (n <= 2000).
Repeatedly relaxes round[b] >= round[a] + 1. In a DAG this settles within n passes;
if it is still changing after n passes there is a cycle.
Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, m = int(data[0]), int(data[1])
assert n <= 2000 and n * m <= 4_000_000, "too big for brute"
deps = [(int(data[2 + 2 * j]), int(data[3 + 2 * j])) for j in range(m)]
r = [1] * (n + 1)
for _ in range(n + 1):
    changed = False
    for a, b in deps:
        if r[b] < r[a] + 1:
            r[b] = r[a] + 1
            changed = True
    if not changed:
        print(max(r[1:]))
        break
else:
    print(-1)
