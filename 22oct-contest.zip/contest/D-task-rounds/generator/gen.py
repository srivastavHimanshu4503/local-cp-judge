"""Deterministic test generator for Problem D (Task Rounds).

Usage: python3 gen.py <problem_dir>
"""
import os
import random
import sys

MAXN = 200_000
MAXM = 200_000

SAMPLES = [
    ("5 4\n1 2\n1 3\n3 4\n2 4\n", "Statement example 1: three rounds"),
    ("4 3\n1 2\n2 3\n3 2\n", "Statement example 2: a cycle in part of the graph gives -1"),
    ("3 0\n", "Statement example 3: no dependencies, one round"),
]


def fmt(n, edges):
    return f"{n} {len(edges)}\n" + "".join(f"{a} {b}\n" for a, b in edges)


def relabel(rng, n, edges):
    """Random task numbers and random edge order, so structure is not visible from labels."""
    perm = list(range(1, n + 1))
    rng.shuffle(perm)
    mp = [0] + perm
    e = [(mp[a], mp[b]) for a, b in edges]
    rng.shuffle(e)
    return e


def random_dag(rng, n, m, maxjump=None):
    """Edges go from lower to higher position, so there is no cycle."""
    s = set()
    while len(s) < m:
        a = rng.randint(1, n - 1)
        b = rng.randint(a + 1, n if maxjump is None else min(n, a + maxjump))
        s.add((a, b))
    return list(s)


def secret_tests():
    rng = random.Random(20261024)
    t = []
    t.append((1, [], "n = 1, m = 0: answer 1"))
    t.append((2, [(1, 2), (2, 1)], "two tasks that need each other: -1"))
    t.append((2, [(2, 1)], "two tasks, task 2 before task 1: answer 2"))

    for i in range(4):
        n = rng.randint(2, 10)
        m = rng.randint(0, n * (n - 1) // 4)
        t.append((n, relabel(rng, n, random_dag(rng, n, m)), f"small random DAG #{i + 1} (n = {n}, m = {m})"))
    for i in range(3):
        n = rng.randint(3, 10)
        e = set(random_dag(rng, n, rng.randint(1, n)))
        a, b = rng.sample(range(1, n + 1), 2)
        e.add((a, b))
        e.add((b, a))
        t.append((n, relabel(rng, n, sorted(e)), f"small random graph with a 2-cycle #{i + 1} (n = {n})"))

    t.append((MAXN, [], "max n, m = 0: answer 1"))

    chain = [(i, i + 1) for i in range(1, MAXN)]
    t.append((MAXN, relabel(rng, MAXN, chain), "max n, one chain through all tasks (shuffled): answer 200000"))

    t.append((MAXN, relabel(rng, MAXN, [(1, i) for i in range(2, MAXN + 1)]), "star: one task before all others: answer 2"))
    t.append((MAXN, relabel(rng, MAXN, [(i, 1) for i in range(2, MAXN + 1)]), "reverse star: all others before one task: answer 2"))

    # final task depends on every task of a chain: it is reachable in 1 step but ready only at the end
    L = 1000
    e = [(i, i + 1) for i in range(1, L)] + [(i, L + 1) for i in range(1, L + 1)]
    t.append((L + 1, relabel(rng, L + 1, e), "task needing every task of a 1000-long chain: answer 1001 (first-visit BFS gives 2)"))

    L = 60_000
    e = [(i, i + 1) for i in range(1, L)] + [(i, L + 1) for i in range(1, L + 1, 3)] + [(L + 1, L + 2)]
    t.append((MAXN, relabel(rng, MAXN, e), "60000-long chain, a task depending on every third chain task, and 139998 free tasks"))

    # big DAG with one 2-cycle among the sources' descendants
    e = set(random_dag(rng, MAXN, MAXM - 2))
    a, b = MAXN // 2, MAXN // 2 + 1
    e.discard((a, b))
    e.add((a, b))
    e.add((b, a))
    t.append((MAXN, relabel(rng, MAXN, sorted(e)), "max size random DAG with one 2-cycle in the middle: -1"))

    cyc = [(i, i % MAXN + 1) for i in range(1, MAXN + 1)]
    t.append((MAXN, relabel(rng, MAXN, cyc), "one cycle through all tasks: -1"))

    # cycle reachable from valid tasks: chain 1..k feeds into cycle k+1..k+5
    k = 100_000
    e = [(i, i + 1) for i in range(1, k)] + [(k, k + 1)] + [(k + j, k + j + 1) for j in range(1, 5)] + [(k + 5, k + 1)]
    n = k + 5
    t.append((n, relabel(rng, n, e), "a 100000-long chain that leads into a 5-cycle: -1 (every task is reachable)"))

    # tasks hanging off a cycle
    e = [(1, 2), (2, 3), (3, 1)] + [(rng.randint(1, 3), i) for i in range(4, 1001)]
    e += [(i, i + 1) for i in range(1001, 5000)]
    t.append((5000, relabel(rng, 5000, list(set(e))), "1000 tasks blocked behind a 3-cycle, plus an unrelated chain: -1"))

    t.append((MAXN, relabel(rng, MAXN, random_dag(rng, MAXN, MAXM)), "max size random DAG"))
    t.append((MAXN, relabel(rng, MAXN, random_dag(rng, MAXN, MAXM, maxjump=5)), "max size random DAG with short jumps (long chains)"))
    t.append((1000, relabel(rng, 1000, random_dag(rng, 1000, MAXM)), "n = 1000, m = 200000 dense random DAG"))

    # many disjoint chains of different lengths
    e, pos, best = [], 1, 0
    while True:
        L = rng.randint(1, 3000)
        if pos + L - 1 > MAXN:
            break
        e += [(pos + j, pos + j + 1) for j in range(L - 1)]
        best = max(best, L)
        pos += L
    t.append((MAXN, relabel(rng, MAXN, e), f"many separate chains of random length (answer = longest = {best})"))

    # layered: every task in layer i points to 4 random tasks in layer i+1
    W, layers = 400, 500
    e = set()
    for li in range(layers - 1):
        for x in range(W):
            u = li * W + x + 1
            for _ in range(1):
                e.add((u, (li + 1) * W + rng.randint(0, W - 1) + 1))
    t.append((W * layers, relabel(rng, W * layers, sorted(e)), "500 layers of 400 tasks, edges between consecutive layers"))
    return t


def write(dirpath, name, content, desc):
    with open(os.path.join(dirpath, name + ".in"), "w") as f:
        f.write(content)
    with open(os.path.join(dirpath, name + ".desc"), "w") as f:
        f.write(desc + "\n")


def main():
    root = sys.argv[1]
    sd = os.path.join(root, "data", "sample")
    xd = os.path.join(root, "data", "secret")
    for d in (sd, xd):
        os.makedirs(d, exist_ok=True)
        for f in os.listdir(d):
            os.remove(os.path.join(d, f))
    for i, (content, desc) in enumerate(SAMPLES, 1):
        write(sd, f"{i:02d}", content, desc)
    for i, (n, e, desc) in enumerate(secret_tests(), 1):
        write(xd, f"{i:02d}", fmt(n, e), desc)


if __name__ == "__main__":
    main()
