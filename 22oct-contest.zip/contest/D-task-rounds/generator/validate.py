"""Strict input validator for Problem D. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+ \d+\n(\d+ \d+\n)*", data), "bad format"
lines = data.split("\n")[:-1]
n, m = map(int, lines[0].split())
assert 1 <= n <= 200_000, "n out of range"
assert 0 <= m <= 200_000, "m out of range"
assert len(lines) == m + 1, "wrong number of lines"
seen = set()
for ln in lines[1:]:
    a, b = map(int, ln.split())
    assert 1 <= a <= n and 1 <= b <= n, f"task out of range {a} {b}"
    assert a != b, "self dependency"
    assert (a, b) not in seen, f"duplicate dependency {a} {b}"
    seen.add((a, b))
print("OK")
