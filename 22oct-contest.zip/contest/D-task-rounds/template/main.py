import sys

# ---------------- your code starts here ----------------
def solve(n, m, deps):
    # deps[j] = (a, b): task a must be finished before task b can start
    # return the minimum number of rounds, or -1
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    deps = [(int(data[2 + 2 * j]), int(data[3 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, deps)}\n")


main()
