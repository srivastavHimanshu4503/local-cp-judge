---
title: "Problem D — Task Rounds"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

There are **n** tasks, numbered 1 to n, and **m** dependencies. A dependency "a b" means task **a** must be finished before task **b** can start.

Work happens in **rounds**. In each round, you may do **any number** of tasks at the same time, as long as every task you do has all its prerequisites finished in earlier rounds.

Find the minimum number of rounds needed to finish all tasks. If it is impossible to finish all tasks, print **−1**.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// deps[j][0] = a, deps[j][1] = b  (a must be finished before b)
// return the minimum number of rounds, or -1
static int solve(int n, int m, int[][] deps)
```

```python
# Python
# deps[j] = (a, b)  (a must be finished before b)
# return the minimum number of rounds, or -1
def solve(n, m, deps):
```

## Input

- The first line has two integers **n** and **m**, separated by a space.
- Each of the next **m** lines has two integers **a** and **b**, separated by a space.

## Output

Print one integer: the minimum number of rounds, or **−1** if not all tasks can be finished.

## Constraints

- 1 ≤ n ≤ 200 000
- 0 ≤ m ≤ 200 000
- 1 ≤ a, b ≤ n and a ≠ b
- No dependency appears twice.

## Example 1

Input:

```
5 4
1 2
1 3
3 4
2 4
```

Output:

```
3
```

**Explanation:**

- **Round 1:** Tasks 1 and 5 have no prerequisites, so do both.
- **Round 2:** Tasks 2 and 3 each need only task 1, which is done. Do both.
- **Round 3:** Task 4 needs tasks 2 and 3, which are both done. Do it.

All 5 tasks are finished in **3** rounds. Fewer is impossible: the chain 1 → 3 → 4 alone needs 3 rounds, because each task must come in a later round than the one before it.

## Example 2

Input:

```
4 3
1 2
2 3
3 2
```

Output:

```
-1
```

**Explanation:** Task 2 needs task 3 to be finished first, and task 3 needs task 2 to be finished first. Neither can ever start, so tasks 2 and 3 can never be finished. Tasks 1 and 4 can be done, but not **all** tasks can be finished, so the answer is **−1**.

## Example 3

Input:

```
3 0
```

Output:

```
1
```

**Explanation:** There are no dependencies, so all 3 tasks can be done together in round **1**.
