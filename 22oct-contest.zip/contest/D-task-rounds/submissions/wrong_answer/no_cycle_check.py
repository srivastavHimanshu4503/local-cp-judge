import sys

# ---------------- your code starts here ----------------
# Bug: counts the rounds but never checks that all n tasks were finished.
def solve(n, m, deps):
    adj = [[] for _ in range(n + 1)]
    indeg = [0] * (n + 1)
    for a, b in deps:
        adj[a].append(b)
        indeg[b] += 1
    current = [v for v in range(1, n + 1) if indeg[v] == 0]
    rounds = 0
    while current:
        rounds += 1
        nxt = []
        for u in current:
            for v in adj[u]:
                indeg[v] -= 1
                if indeg[v] == 0:
                    nxt.append(v)
        current = nxt
    return rounds if rounds > 0 else -1
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    deps = [(int(data[2 + 2 * j]), int(data[3 + 2 * j])) for j in range(m)]
    sys.stdout.write(f"{solve(n, m, deps)}\n")


main()
