import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    static int solve(int n, int m, int[][] deps) {
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i <= n; i++) adj.add(new ArrayList<>());
        int[] indeg = new int[n + 1];
        for (int[] d : deps) {
            adj.get(d[0]).add(d[1]);
            indeg[d[1]]++;
        }
        ArrayDeque<Integer> q = new ArrayDeque<>();
        int[] round = new int[n + 1];
        for (int v = 1; v <= n; v++)
            if (indeg[v] == 0) { q.add(v); round[v] = 1; }
        int done = 0, rounds = 0;
        while (!q.isEmpty()) {
            int u = q.poll();
            done++;
            rounds = Math.max(rounds, round[u]);
            for (int v : adj.get(u)) {
                if (--indeg[v] == 0) {
                    round[v] = round[u] + 1;
                    q.add(v);
                }
            }
        }
        return done == n ? rounds : -1;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int[][] deps = new int[m][2];
        for (int j = 0; j < m; j++) {
            deps[j][0] = in.nextInt();
            deps[j][1] = in.nextInt();
        }
        System.out.println(solve(n, m, deps));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
