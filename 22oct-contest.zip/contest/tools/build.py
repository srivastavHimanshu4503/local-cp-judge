"""Build and verify one or more problems.

Usage: python3 tools/build.py [A B C D] [--skip-judge]

For each problem it:
  1. regenerates data/ with generator/gen.py (fixed seeds, so output is identical every run)
  2. validates every .in with generator/validate.py
  3. writes .ans with the Python reference solution (solutions/accepted/<REFERENCE>)
  4. cross-checks every .ans against generator/brute.py where brute can handle the test
  5. checks that the samples in statement/problem.md match data/sample exactly
  6. assembles solutions/ + harness/ into full programs in submissions/, and stub + harness into template/
  7. judges every submission on every test and checks it gets the verdict its folder claims
"""
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# key: (folder, reference solution, base time limit in seconds = the Java limit)
PROBLEMS = {
    "A": ("A-busy-blocks", "sort_merge.py", 2),
    "B": ("B-delayed-printers", "binary_search.py", 2),
    "C": ("C-widest-window", "two_heaps.py", 3),
    "D": ("D-task-rounds", "kahn_levels.py", 2),
}
PY_FACTOR = 3  # DOMjudge language time factor for Python 3
VERDICT_DIRS = ["accepted", "wrong_answer", "time_limit_exceeded"]


def sh(cmd, **kw):
    return subprocess.run(cmd, shell=isinstance(cmd, str), **kw)


def assemble(pdir):
    """Insert function code into the harness; write submissions/ and template/."""
    hp = open(os.path.join(pdir, "harness", "harness.py")).read()
    hj = open(os.path.join(pdir, "harness", "Harness.java")).read()

    def build(code, ext):
        code = code.rstrip("\n")
        if ext == "py":
            return hp.replace("{{STUDENT_CODE}}", code)
        return hj.replace("{{STUDENT_CODE}}", code)

    sub = os.path.join(pdir, "submissions")
    shutil.rmtree(sub, ignore_errors=True)
    out = []
    for v in VERDICT_DIRS:
        os.makedirs(os.path.join(sub, v), exist_ok=True)
        for f in sorted(glob.glob(os.path.join(pdir, "solutions", v, "*"))):
            ext = f.rsplit(".", 1)[1]
            dst = os.path.join(sub, v, os.path.basename(f))
            with open(dst, "w") as fh:
                fh.write(build(open(f).read(), ext))
            out.append((v, dst, ext))
    tdir = os.path.join(pdir, "template")
    shutil.rmtree(tdir, ignore_errors=True)
    os.makedirs(tdir)
    with open(os.path.join(tdir, "main.py"), "w") as fh:
        fh.write(build(open(os.path.join(pdir, "stub", "stub.py")).read(), "py"))
    with open(os.path.join(tdir, "Main.java"), "w") as fh:
        fh.write(build(open(os.path.join(pdir, "stub", "stub.java")).read(), "java"))
    return out


def compile_java(path, workdir):
    d = tempfile.mkdtemp(dir=workdir)
    shutil.copy(path, os.path.join(d, "Main.java"))
    r = sh(["javac", "-encoding", "UTF-8", "-d", d, os.path.join(d, "Main.java")], capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"compile error in {path}:\n{r.stderr}")
    return d


def run(cmd, infile, limit):
    with open(infile, "rb") as fin:
        t0 = time.perf_counter()
        try:
            r = subprocess.run(cmd, stdin=fin, capture_output=True, timeout=limit)
        except subprocess.TimeoutExpired:
            return "TLE", None, time.perf_counter() - t0
        dt = time.perf_counter() - t0
    if r.returncode != 0:
        return "RTE", r.stderr.decode()[-500:], dt
    return "OK", r.stdout.decode(), dt


def same(out, ans):
    return out.split() == ans.split()


def tests(pdir):
    return sorted(glob.glob(os.path.join(pdir, "data", "sample", "*.in"))) + \
        sorted(glob.glob(os.path.join(pdir, "data", "secret", "*.in")))


def check_statement_samples(pdir):
    md = open(os.path.join(pdir, "statement", "problem.md")).read()
    blocks, cur, lang = [], None, None
    for line in md.splitlines(keepends=True):
        if line.startswith("```"):
            if cur is None:
                cur, lang = [], line[3:].strip()
            else:
                if lang == "":
                    blocks.append("".join(cur))
                cur = None
        elif cur is not None:
            cur.append(line)
    samples = sorted(glob.glob(os.path.join(pdir, "data", "sample", "*.in")))
    expected = []
    for s in samples:
        expected.append(open(s).read())
        expected.append(open(s[:-3] + ".ans").read())
    assert len(blocks) == len(expected), f"statement has {len(blocks)} sample blocks, data has {len(expected)}"
    for i, (b, e) in enumerate(zip(blocks, expected)):
        assert b == e, f"statement sample block {i + 1} differs from data:\n{b!r}\n{e!r}"


def build_problem(key, skip_judge=False):
    pname, ref, base = PROBLEMS[key]
    TL = {"java": float(base), "py": float(base * PY_FACTOR)}
    HARD_KILL = {k: 2 * v for k, v in TL.items()}
    pdir = os.path.join(ROOT, pname)
    gen = os.path.join(pdir, "generator")
    log = []

    def note(s):
        print(s, flush=True)
        log.append(s)

    note(f"===== {pname} =====")
    sh([sys.executable, os.path.join(gen, "gen.py"), pdir], check=True)
    T = tests(pdir)
    note(f"generated {len(T)} tests")

    for t in T:
        r = sh([sys.executable, os.path.join(gen, "validate.py")], stdin=open(t), capture_output=True, text=True)
        if r.returncode != 0 or r.stdout.strip() != "OK":
            raise SystemExit(f"VALIDATION FAILED {t}: {r.stderr[-400:]}")
    note("validator: all inputs OK")

    subs = assemble(pdir)
    work = tempfile.mkdtemp()
    refsub = os.path.join(pdir, "submissions", "accepted", ref)
    for t in T:
        st, out, dt = run([sys.executable, refsub], t, 60)
        assert st == "OK", f"reference failed on {t}: {st} {out}"
        with open(t[:-3] + ".ans", "w") as fh:
            fh.write(out)

    brute_checked = 0
    for t in T:
        r = sh([sys.executable, os.path.join(gen, "brute.py")], stdin=open(t), capture_output=True, text=True, timeout=120)
        if r.returncode != 0:
            continue  # brute cannot handle this size
        ans = open(t[:-3] + ".ans").read()
        if not same(r.stdout, ans):
            raise SystemExit(f"BRUTE MISMATCH on {t}: brute={r.stdout.strip()[:200]} ref={ans.strip()[:200]}")
        brute_checked += 1
    note(f"brute force agrees with the reference on {brute_checked}/{len(T)} tests (the rest are too large for brute force)")

    check_statement_samples(pdir)
    note("statement samples match data/sample exactly")

    if skip_judge:
        return
    note("")
    note(f"Judging every submission (limits: Java {TL['java']} s, Python {TL['py']} s)")
    all_good = True
    for verdict, path, ext in subs:
        if ext == "java":
            cdir = compile_java(path, work)
            cmd = ["java", "-Xss256m", "-Xmx1g", "-cp", cdir, "Main"]
        else:
            cmd = [sys.executable, path]
        results = []
        worst = 0.0
        for t in T:
            st, out, dt = run(cmd, t, HARD_KILL[ext])
            name = os.path.relpath(t, os.path.join(pdir, "data"))
            if st == "OK":
                if dt > TL[ext]:
                    st = "TLE"
                elif not same(out, open(t[:-3] + ".ans").read()):
                    st = "WA"
                else:
                    st = "AC"
            worst = max(worst, dt)
            results.append((name, st, dt))
            if verdict == "time_limit_exceeded" and st == "TLE":
                break  # DOMjudge would stop here too
        kinds = {st for _, st, _ in results}
        if verdict == "accepted":
            ok = kinds == {"AC"}
            final = "AC" if ok else "FAIL"
        elif verdict == "wrong_answer":
            ok = "WA" in kinds and "TLE" not in kinds and "RTE" not in kinds
            final = "WA" if ok else "FAIL"
        else:
            ok = "TLE" in kinds and "RTE" not in kinds
            final = "TLE" if ok else "FAIL"
        all_good &= ok
        first_bad = next(((n, s) for n, s, _ in results if s != "AC"), None)
        detail = f"slowest test {worst:.2f} s" if verdict == "accepted" else \
            (f"first failure: {first_bad[0]} -> {first_bad[1]}; fails {sum(s != 'AC' for _, s, _ in results)}/{len(results)} tests run"
             if first_bad else "never failed")
        note(f"{'OK ' if ok else 'BAD'} {verdict:20s} {os.path.basename(path):28s} {final:4s} ({detail})")
    shutil.rmtree(work, ignore_errors=True)
    note("")
    note("ALL JURY SUBMISSIONS GOT THEIR EXPECTED VERDICT" if all_good else "SOME JURY SUBMISSIONS DID NOT GET THEIR EXPECTED VERDICT")
    with open(os.path.join(pdir, "verification-report.txt"), "w") as fh:
        fh.write("\n".join(log) + "\n")
    if not all_good:
        raise SystemExit(1)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    for k in (args or list(PROBLEMS)):
        build_problem(k, "--skip-judge" in sys.argv)
