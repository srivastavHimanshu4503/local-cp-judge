"""Render statements, write DOMjudge metadata and test catalogs, and build the import zips.

Usage: python3 tools/package.py
Run tools/build.py first (it generates the tests and the assembled submissions).
Output: dist/domjudge/<A..D>.zip, statements/contest-problems.pdf, <problem>/TESTS.md
"""
import glob
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import PROBLEMS, PY_FACTOR, ROOT  # noqa: E402

CSS = os.path.join(ROOT, "tools", "statement.css")
NAMES = {"A": "Busy Blocks", "B": "Delayed Printers", "C": "Widest Window", "D": "Task Rounds"}
COLORS = {"A": "#2E7D32", "B": "#1565C0", "C": "#EF6C00", "D": "#C62828"}


def html_of(md_path, out_html):
    with open(CSS) as f:
        css = f.read()
    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False) as hdr:
        hdr.write(f"<style>\n{css}\n</style>\n")
    subprocess.run(["pandoc", md_path, "-f", "markdown", "-t", "html5", "--standalone", "--no-highlight",
                    "--include-in-header", hdr.name, "--metadata", "lang=en", "-o", out_html], check=True)
    os.unlink(hdr.name)


def pdf_of(html_files, out_pdf):
    subprocess.run(["wkhtmltopdf", "--quiet", "--enable-local-file-access", "-s", "A4", "--zoom", "1.25",
                    "--margin-top", "14mm", "--margin-bottom", "14mm", "--margin-left", "12mm", "--margin-right", "12mm",
                    "--footer-center", "[page]", "--footer-font-size", "8", *html_files, out_pdf], check=True)


def tests_md(key, pdir):
    lines = [f"# Problem {key} — {NAMES[key]}: test catalog", "",
             "Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).", ""]
    for kind in ("sample", "secret"):
        lines += [f"## {kind}", "", "| Test | Size | What it targets | Expected output |", "|---|---|---|---|"]
        for f in sorted(glob.glob(os.path.join(pdir, "data", kind, "*.in"))):
            name = os.path.basename(f)[:-3]
            desc = open(f[:-3] + ".desc").read().strip()
            ans = open(f[:-3] + ".ans").read().strip()
            ans = ans if len(ans) <= 40 else ans[:37] + "…"
            first = open(f).readline().split()
            size = f"n = {first[0]}" + (f", {'k' if key == 'C' else 'm'} = {first[1]}" if len(first) > 1 else "")
            lines.append(f"| {kind}/{name} | {size} | {desc} | `{ans}` |")
        lines.append("")
    with open(os.path.join(pdir, "TESTS.md"), "w") as fh:
        fh.write("\n".join(lines))


def write_meta(key, pdir, base):
    name = NAMES[key]
    with open(os.path.join(pdir, "problem.yaml"), "w") as fh:
        fh.write(f"name: {name}\nlimits:\n  memory: 1024\n")
    with open(os.path.join(pdir, "domjudge-problem.ini"), "w") as fh:
        fh.write(f"short-name = {key}\nname = \"{name}\"\ntimelimit = {base}\ncolor = \"{COLORS[key]}\"\n")
    with open(os.path.join(pdir, ".timelimit"), "w") as fh:
        fh.write(f"{base}\n")


def make_zip(key, pdir, out):
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in ("problem.yaml", "domjudge-problem.ini", ".timelimit"):
            z.write(os.path.join(pdir, f), f)
        z.write(os.path.join(pdir, "statement", "problem.pdf"), "problem.pdf")
        for kind in ("sample", "secret"):
            for f in sorted(glob.glob(os.path.join(pdir, "data", kind, "*"))):
                if f.endswith((".in", ".ans")):
                    z.write(f, f"data/{kind}/{os.path.basename(f)}")
        for f in sorted(glob.glob(os.path.join(pdir, "submissions", "*", "*"))):
            rel = os.path.relpath(f, pdir)
            z.write(f, rel)


def main():
    dist = os.path.join(ROOT, "dist", "domjudge")
    shutil.rmtree(os.path.join(ROOT, "dist"), ignore_errors=True)
    os.makedirs(dist)
    os.makedirs(os.path.join(ROOT, "statements"), exist_ok=True)
    htmls = []
    rules_html = os.path.join(ROOT, "statements", "rules.html")
    html_of(os.path.join(ROOT, "tools", "rules.md"), rules_html)
    for key, (pname, _, base) in PROBLEMS.items():
        pdir = os.path.join(ROOT, pname)
        sdir = os.path.join(pdir, "statement")
        html = os.path.join(sdir, "problem.html")
        html_of(os.path.join(sdir, "problem.md"), html)
        pdf_of([html], os.path.join(sdir, "problem.pdf"))
        htmls.append(html)
        write_meta(key, pdir, base)
        tests_md(key, pdir)
        out = os.path.join(dist, f"{key}-{pname.split('-', 1)[1]}.zip")
        make_zip(key, pdir, out)
        print(f"{os.path.relpath(out, ROOT)}: {os.path.getsize(out) / 2**20:.1f} MB "
              f"(time limit {base} s Java / {base * PY_FACTOR} s Python)")
    rules_pdf = os.path.join(ROOT, "statements", "rules.pdf")
    pdf_of([rules_html], rules_pdf)
    parts = [rules_pdf] + [h[:-5] + ".pdf" for h in htmls]
    subprocess.run(["pdfunite", *parts, os.path.join(ROOT, "statements", "contest-problems.pdf")], check=True)
    for key, (pname, _, _) in PROBLEMS.items():
        shutil.copy(os.path.join(ROOT, pname, "statement", "problem.pdf"),
                    os.path.join(ROOT, "statements", f"{key}-{pname.split('-', 1)[1]}.pdf"))
    print("statements/contest-problems.pdf written")


if __name__ == "__main__":
    main()
