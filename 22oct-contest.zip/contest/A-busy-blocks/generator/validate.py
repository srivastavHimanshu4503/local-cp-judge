"""Strict input validator for Problem A. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"(\d+\n)(\d+ \d+\n)+", data), "bad format"
lines = data.split("\n")[:-1]
n = int(lines[0])
assert 1 <= n <= 200_000, "n out of range"
assert len(lines) == n + 1, "wrong number of lines"
for ln in lines[1:]:
    s, e = map(int, ln.split())
    assert 0 <= s < e <= 10**9, f"bad interval {s} {e}"
print("OK")
