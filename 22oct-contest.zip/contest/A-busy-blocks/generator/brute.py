"""Independent checker for small tests (coordinates <= 10^6): marks every unit cell [x, x+1) covered.
Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n = int(data[0])
iv = [(int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n)]
hi = max(e for _, e in iv)
assert hi <= 3 * 10**6, "too big for brute"
diff = [0] * (hi + 2)
for s, e in iv:
    diff[s] += 1
    diff[e] -= 1
blocks, longest, run, cov = 0, 0, 0, 0
for x in range(hi + 1):
    cov += diff[x]
    if cov > 0:
        run += 1
    else:
        if run:
            blocks += 1
            longest = max(longest, run)
        run = 0
if run:
    blocks += 1
    longest = max(longest, run)
print(blocks, longest)
