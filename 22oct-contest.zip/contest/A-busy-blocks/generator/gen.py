"""Deterministic test generator for Problem A (Busy Blocks).

Usage: python3 gen.py <problem_dir>
Writes data/sample/*.in, data/secret/*.in and a one-line .desc next to each.
"""
import os
import random
import sys

MAXN = 200_000
MAXV = 10**9

SAMPLES = [
    ("4\n1 3\n8 10\n2 6\n12 15\n", "Statement example 1: overlapping intervals give 3 blocks"),
    ("3\n5 7\n1 3\n3 5\n", "Statement example 2: touching intervals join into one block"),
    ("3\n1 10\n2 4\n11 12\n", "Statement example 3: nested interval does not shorten the block"),
]


def fmt(iv):
    return f"{len(iv)}\n" + "".join(f"{s} {e}\n" for s, e in iv)


def rand_iv(rng, lo, hi, maxlen):
    s = rng.randint(lo, hi - 1)
    e = min(hi, s + rng.randint(1, maxlen))
    return (s, e)


def secret_tests():
    rng = random.Random(20261021)
    t = []
    t.append(([(5, 9)], "n = 1"))
    t.append(([(0, MAXV)], "n = 1, longest possible block (10^9)"))
    t.append(([(3, 5), (1, 3)], "two touching intervals, given out of order"))
    t.append(([(1, 3), (4, 6)], "two intervals with a gap of exactly 1"))
    t.append(([(2, 6), (2, 6), (2, 6)], "identical intervals"))

    # many small random tests in one-shot files (each file is one test)
    for i in range(6):
        n = rng.randint(2, 12)
        iv = [rand_iv(rng, 0, 30, 6) for _ in range(n)]
        t.append((iv, f"small random #{i + 1} (n = {n}, coordinates <= 30)"))

    # everything nested inside one big interval; big one placed in the middle
    iv = [(0, MAXV)] + [rand_iv(rng, 1, MAXV - 1, 1000) for _ in range(MAXN - 2)]
    iv.append((MAXV - 5, MAXV))
    rng.shuffle(iv)
    t.append((iv, "max n, all intervals inside [0, 10^9]: answer 1 block of 10^9"))

    # staircase that breaks "end = current end": long interval then many short nested ones, then gaps
    iv = []
    pos = 0
    for _ in range(2000):
        iv.append((pos, pos + 1000))
        for j in range(1, 50):
            iv.append((pos + j, pos + j + 3))
        pos += 1002
    rng.shuffle(iv)
    t.append((iv, "2000 blocks, each a long interval with 49 short nested ones (catches end = e bug)"))

    # long touching chain
    iv = [(i, i + 1) for i in range(MAXN)]
    rng.shuffle(iv)
    t.append((iv, "max n, touching chain [i, i+1] shuffled: 1 block of length 200000"))

    # touching chain with varied lengths
    iv = []
    pos = 0
    for _ in range(MAXN):
        L = rng.randint(1, 5000)
        iv.append((pos, pos + L))
        pos += L
    rng.shuffle(iv)
    t.append((iv, "max n, touching chain of random lengths shuffled: 1 block"))

    # all separate
    iv = []
    pos = 0
    for _ in range(MAXN):
        L = rng.randint(1, 4000)
        iv.append((pos, pos + L))
        pos += L + rng.randint(1, 900)
    rng.shuffle(iv)
    t.append((iv, "max n, every interval separate: 200000 blocks"))

    # alternating touch / gap
    iv = []
    pos = 0
    for i in range(MAXN):
        iv.append((pos, pos + 3))
        pos += 3 if i % 2 == 0 else 4
    rng.shuffle(iv)
    t.append((iv, "max n, pairs of touching intervals separated by gaps of 1: 100000 blocks of length 6"))

    # sorted input
    iv = sorted(rand_iv(rng, 0, MAXV, 20000) for _ in range(MAXN))
    t.append((iv, "max n random, already sorted by start"))

    # reverse sorted
    iv = sorted((rand_iv(rng, 0, MAXV, 20000) for _ in range(MAXN)), reverse=True)
    t.append((iv, "max n random, sorted in decreasing order"))

    # random wide: many blocks
    iv = [rand_iv(rng, 0, MAXV, 3000) for _ in range(MAXN)]
    t.append((iv, "max n random, short intervals over [0, 10^9]: many blocks"))

    # random dense: few blocks
    iv = [rand_iv(rng, 0, 10**7, 200) for _ in range(MAXN)]
    t.append((iv, "max n random, dense in [0, 10^7]: few blocks"))

    # duplicates heavy
    base = [rand_iv(rng, 0, 10**6, 50) for _ in range(500)]
    iv = [rng.choice(base) for _ in range(MAXN)]
    t.append((iv, "max n, only 500 distinct intervals repeated"))

    # same start, different ends
    iv = [(7, 7 + rng.randint(1, 10**6)) for _ in range(MAXN)]
    t.append((iv, "max n, every interval starts at 7"))

    # mixed: a few huge, many small
    iv = [rand_iv(rng, 0, MAXV, 10**8) for _ in range(20)] + [rand_iv(rng, 0, MAXV, 100) for _ in range(MAXN - 20)]
    rng.shuffle(iv)
    t.append((iv, "max n, 20 huge intervals swallowing many small ones"))
    return t


def write(dirpath, name, content, desc):
    with open(os.path.join(dirpath, name + ".in"), "w") as f:
        f.write(content)
    with open(os.path.join(dirpath, name + ".desc"), "w") as f:
        f.write(desc + "\n")


def main():
    root = sys.argv[1]
    sd = os.path.join(root, "data", "sample")
    xd = os.path.join(root, "data", "secret")
    for d in (sd, xd):
        os.makedirs(d, exist_ok=True)
        for f in os.listdir(d):
            os.remove(os.path.join(d, f))
    for i, (content, desc) in enumerate(SAMPLES, 1):
        write(sd, f"{i:02d}", content, desc)
    for i, (iv, desc) in enumerate(secret_tests(), 1):
        write(xd, f"{i:02d}", fmt(iv), desc)


if __name__ == "__main__":
    main()
