# Problem A — Busy Blocks: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 4 | Statement example 1: overlapping intervals give 3 blocks | `3 5` |
| sample/02 | n = 3 | Statement example 2: touching intervals join into one block | `1 6` |
| sample/03 | n = 3 | Statement example 3: nested interval does not shorten the block | `2 9` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1 | n = 1 | `1 4` |
| secret/02 | n = 1 | n = 1, longest possible block (10^9) | `1 1000000000` |
| secret/03 | n = 2 | two touching intervals, given out of order | `1 4` |
| secret/04 | n = 2 | two intervals with a gap of exactly 1 | `2 2` |
| secret/05 | n = 3 | identical intervals | `1 4` |
| secret/06 | n = 10 | small random #1 (n = 10, coordinates <= 30) | `5 9` |
| secret/07 | n = 11 | small random #2 (n = 11, coordinates <= 30) | `5 8` |
| secret/08 | n = 4 | small random #3 (n = 4, coordinates <= 30) | `3 9` |
| secret/09 | n = 6 | small random #4 (n = 6, coordinates <= 30) | `5 4` |
| secret/10 | n = 12 | small random #5 (n = 12, coordinates <= 30) | `3 13` |
| secret/11 | n = 11 | small random #6 (n = 11, coordinates <= 30) | `4 9` |
| secret/12 | n = 200000 | max n, all intervals inside [0, 10^9]: answer 1 block of 10^9 | `1 1000000000` |
| secret/13 | n = 100000 | 2000 blocks, each a long interval with 49 short nested ones (catches end = e bug) | `2000 1000` |
| secret/14 | n = 200000 | max n, touching chain [i, i+1] shuffled: 1 block of length 200000 | `1 200000` |
| secret/15 | n = 200000 | max n, touching chain of random lengths shuffled: 1 block | `1 500347578` |
| secret/16 | n = 200000 | max n, every interval separate: 200000 blocks | `200000 4000` |
| secret/17 | n = 200000 | max n, pairs of touching intervals separated by gaps of 1: 100000 blocks of length 6 | `100000 6` |
| secret/18 | n = 200000 | max n random, already sorted by start | `27215 321663` |
| secret/19 | n = 200000 | max n random, sorted in decreasing order | `27084 297341` |
| secret/20 | n = 200000 | max n random, short intervals over [0, 10^9]: many blocks | `148239 14751` |
| secret/21 | n = 200000 | max n random, dense in [0, 10^7]: few blocks | `26582 4043` |
| secret/22 | n = 200000 | max n, only 500 distinct intervals repeated | `492 77` |
| secret/23 | n = 200000 | max n, every interval starts at 7 | `1 999976` |
| secret/24 | n = 200000 | max n, 20 huge intervals swallowing many small ones | `75826 225114671` |
