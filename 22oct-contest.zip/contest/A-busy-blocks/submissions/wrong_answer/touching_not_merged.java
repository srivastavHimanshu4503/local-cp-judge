import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // Bug: uses s < curE, so intervals that only touch start a new block.
    static int[] solve(int n, int[][] intervals) {
        Arrays.sort(intervals, (x, y) -> x[0] != y[0] ? Integer.compare(x[0], y[0]) : Integer.compare(x[1], y[1]));
        int blocks = 0, longest = 0;
        int curS = intervals[0][0], curE = intervals[0][1];
        for (int i = 1; i < n; i++) {
            int s = intervals[i][0], e = intervals[i][1];
            if (s < curE) {
                curE = Math.max(curE, e);
            } else {
                blocks++;
                longest = Math.max(longest, curE - curS);
                curS = s;
                curE = e;
            }
        }
        blocks++;
        longest = Math.max(longest, curE - curS);
        return new int[]{blocks, longest};
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int[][] intervals = new int[n][2];
        for (int i = 0; i < n; i++) {
            intervals[i][0] = in.nextInt();
            intervals[i][1] = in.nextInt();
        }
        int[] res = solve(n, intervals);
        System.out.println(res[0] + " " + res[1]);
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
