import sys

# ---------------- your code starts here ----------------
# Bug: sets the block end to the current interval's end instead of the max.
def solve(n, intervals):
    intervals.sort()
    blocks = 0
    longest = 0
    cur_s, cur_e = intervals[0]
    for s, e in intervals[1:]:
        if s <= cur_e:
            cur_e = e
        else:
            blocks += 1
            longest = max(longest, cur_e - cur_s)
            cur_s, cur_e = s, e
    blocks += 1
    longest = max(longest, cur_e - cur_s)
    return (blocks, longest)
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    intervals = [(int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n)]
    blocks, longest = solve(n, intervals)
    sys.stdout.write(f"{blocks} {longest}\n")


main()
