import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // Correct but O(n^2): union every pair of overlapping/touching intervals.
    static int[] par;

    static int find(int x) {
        while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; }
        return x;
    }

    static int[] solve(int n, int[][] intervals) {
        par = new int[n];
        for (int i = 0; i < n; i++) par[i] = i;
        for (int i = 0; i < n; i++)
            for (int j = i + 1; j < n; j++)
                if (intervals[i][0] <= intervals[j][1] && intervals[j][0] <= intervals[i][1]) {
                    int a = find(i), b = find(j);
                    if (a != b) par[a] = b;
                }
        int[] lo = new int[n], hi = new int[n];
        Arrays.fill(lo, Integer.MAX_VALUE);
        Arrays.fill(hi, Integer.MIN_VALUE);
        for (int i = 0; i < n; i++) {
            int r = find(i);
            lo[r] = Math.min(lo[r], intervals[i][0]);
            hi[r] = Math.max(hi[r], intervals[i][1]);
        }
        int blocks = 0, longest = 0;
        for (int i = 0; i < n; i++)
            if (lo[i] != Integer.MAX_VALUE) { blocks++; longest = Math.max(longest, hi[i] - lo[i]); }
        return new int[]{blocks, longest};
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int[][] intervals = new int[n][2];
        for (int i = 0; i < n; i++) {
            intervals[i][0] = in.nextInt();
            intervals[i][1] = in.nextInt();
        }
        int[] res = solve(n, intervals);
        System.out.println(res[0] + " " + res[1]);
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
