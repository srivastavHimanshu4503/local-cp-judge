import sys

# ---------------- your code starts here ----------------
# Correct but O(n^2): union every pair of overlapping/touching intervals.
def solve(n, intervals):
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for i in range(n):
        si, ei = intervals[i]
        for j in range(i + 1, n):
            sj, ej = intervals[j]
            if si <= ej and sj <= ei:
                a, b = find(i), find(j)
                if a != b:
                    parent[a] = b
    lo = {}
    hi = {}
    for i in range(n):
        r = find(i)
        s, e = intervals[i]
        lo[r] = min(lo.get(r, s), s)
        hi[r] = max(hi.get(r, e), e)
    return (len(lo), max(hi[r] - lo[r] for r in lo))
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    intervals = [(int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n)]
    blocks, longest = solve(n, intervals)
    sys.stdout.write(f"{blocks} {longest}\n")


main()
