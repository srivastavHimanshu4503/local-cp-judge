    static int[] solve(int n, int[][] intervals) {
        Arrays.sort(intervals, (x, y) -> x[0] != y[0] ? Integer.compare(x[0], y[0]) : Integer.compare(x[1], y[1]));
        int blocks = 0, longest = 0;
        int curS = intervals[0][0], curE = intervals[0][1];
        for (int i = 1; i < n; i++) {
            int s = intervals[i][0], e = intervals[i][1];
            if (s <= curE) {
                curE = Math.max(curE, e);
            } else {
                blocks++;
                longest = Math.max(longest, curE - curS);
                curS = s;
                curE = e;
            }
        }
        blocks++;
        longest = Math.max(longest, curE - curS);
        return new int[]{blocks, longest};
    }
