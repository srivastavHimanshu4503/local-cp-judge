    // Correct but O(n^2): union every pair of overlapping/touching intervals.
    static int[] par;

    static int find(int x) {
        while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; }
        return x;
    }

    static int[] solve(int n, int[][] intervals) {
        par = new int[n];
        for (int i = 0; i < n; i++) par[i] = i;
        for (int i = 0; i < n; i++)
            for (int j = i + 1; j < n; j++)
                if (intervals[i][0] <= intervals[j][1] && intervals[j][0] <= intervals[i][1]) {
                    int a = find(i), b = find(j);
                    if (a != b) par[a] = b;
                }
        int[] lo = new int[n], hi = new int[n];
        Arrays.fill(lo, Integer.MAX_VALUE);
        Arrays.fill(hi, Integer.MIN_VALUE);
        for (int i = 0; i < n; i++) {
            int r = find(i);
            lo[r] = Math.min(lo[r], intervals[i][0]);
            hi[r] = Math.max(hi[r], intervals[i][1]);
        }
        int blocks = 0, longest = 0;
        for (int i = 0; i < n; i++)
            if (lo[i] != Integer.MAX_VALUE) { blocks++; longest = Math.max(longest, hi[i] - lo[i]); }
        return new int[]{blocks, longest};
    }
