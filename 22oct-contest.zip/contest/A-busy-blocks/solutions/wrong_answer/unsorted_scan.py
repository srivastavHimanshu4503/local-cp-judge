# Bug: forgets to sort, merges in input order.
def solve(n, intervals):
    blocks = 0
    longest = 0
    cur_s, cur_e = intervals[0]
    for s, e in intervals[1:]:
        if cur_s <= s <= cur_e:
            cur_e = max(cur_e, e)
        else:
            blocks += 1
            longest = max(longest, cur_e - cur_s)
            cur_s, cur_e = s, e
    blocks += 1
    longest = max(longest, cur_e - cur_s)
    return (blocks, longest)
