def solve(n, intervals):
    # intervals[i] = (s_i, e_i)
    # return (number_of_blocks, longest_block_length)
    return (0, 0)
