    // intervals[i][0] = s_i, intervals[i][1] = e_i
    // return {numberOfBlocks, longestBlockLength}
    static int[] solve(int n, int[][] intervals) {
        return new int[]{0, 0};
    }
