---
title: "Problem A — Busy Blocks"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

You are given **n** time intervals. Interval *i* starts at time **s~i~** and ends at time **e~i~**.

Overlapping intervals join into one **busy block**. Intervals that touch also join: if one interval ends at time *t* and another starts at the same time *t*, there is no gap between them, so they are part of the same block.

Find:

1. the number of busy blocks, and
2. the length of the longest busy block. A block from time *x* to time *y* has length *y − x*.

The intervals are **not** given in any particular order.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// intervals[i][0] = s_i, intervals[i][1] = e_i
// return {numberOfBlocks, longestBlockLength}
static int[] solve(int n, int[][] intervals)
```

```python
# Python
# intervals[i] = (s_i, e_i)
# return (number_of_blocks, longest_block_length)
def solve(n, intervals):
```

## Input

- The first line has one integer **n**.
- Each of the next **n** lines has two integers **s~i~** and **e~i~**, separated by a space.

## Output

Print two integers on one line, separated by a space: the number of busy blocks, then the length of the longest block.

## Constraints

- 1 ≤ n ≤ 200 000
- 0 ≤ s~i~ < e~i~ ≤ 10^9^

## Example 1

Input:

```
4
1 3
8 10
2 6
12 15
```

Output:

```
3 5
```

**Explanation:** Sorted by start time, the intervals are [1, 3], [2, 6], [8, 10] and [12, 15].

- [1, 3] and [2, 6] overlap, so together they form the block **[1, 6]**.
- [8, 10] starts after 6, so it is a new block, **[8, 10]**.
- [12, 15] starts after 10, so it is another block, **[12, 15]**.

That gives **3** blocks, with lengths 5, 2 and 3. The longest is **5**.

## Example 2

Input:

```
3
5 7
1 3
3 5
```

Output:

```
1 6
```

**Explanation:** Sorted, the intervals are [1, 3], [3, 5] and [5, 7].

- [1, 3] ends at 3, which is exactly when [3, 5] starts, so they join.
- [3, 5] ends at 5, which is exactly when [5, 7] starts, so it joins too.

Everything forms one block, [1, 7], so there is **1** block of length 7 − 1 = **6**.

## Example 3

Input:

```
3
1 10
2 4
11 12
```

Output:

```
2 9
```

**Explanation:** [2, 4] lies completely inside [1, 10], so the block is still [1, 10]. Notice that the block ends at 10, not at 4. Next, [11, 12] starts at 11, which is after 10, so it is a separate block. There are **2** blocks, with lengths 9 and 1. The longest is **9**.
