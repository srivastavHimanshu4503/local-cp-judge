import sys

# ---------------- your code starts here ----------------
def solve(n, intervals):
    # intervals[i] = (s_i, e_i)
    # return (number_of_blocks, longest_block_length)
    return (0, 0)
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    intervals = [(int(data[1 + 2 * i]), int(data[2 + 2 * i])) for i in range(n)]
    blocks, longest = solve(n, intervals)
    sys.stdout.write(f"{blocks} {longest}\n")


main()
