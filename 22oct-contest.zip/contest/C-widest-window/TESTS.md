# Problem C — Widest Window: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 6, k = 3 | Statement example 1: four windows, best spread 7 in the last one | `7` |
| sample/02 | n = 3, k = 1 | Statement example 2: k = 1, every spread is 0 | `0` |
| sample/03 | n = 4, k = 4 | Statement example 3: k = n, one window | `9` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1, k = 1 | n = 1 | `0` |
| secret/02 | n = 2, k = 2 | n = 2, k = 2: largest possible spread 10^9 - 1 | `999999999` |
| secret/03 | n = 6, k = 3 | small random #1 (n = 6, k = 3) | `11` |
| secret/04 | n = 2, k = 2 | small random #2 (n = 2, k = 2) | `10` |
| secret/05 | n = 14, k = 4 | small random #3 (n = 14, k = 4) | `19` |
| secret/06 | n = 15, k = 7 | small random #4 (n = 15, k = 7) | `18` |
| secret/07 | n = 15, k = 15 | small random #5 (n = 15, k = 15) | `19` |
| secret/08 | n = 15, k = 4 | small random #6 (n = 15, k = 4) | `18` |
| secret/09 | n = 1000000, k = 500000 | n = 10^6, k = n/2: rescanning every window takes ~2.5*10^11 steps | `999999945` |
| secret/10 | n = 1000000, k = 500000 | n = 10^6 strictly increasing, k = n/2: answer 499999; min expires every step | `499999` |
| secret/11 | n = 1000000, k = 500000 | n = 10^6 strictly decreasing, k = n/2: answer 499999; max expires every step | `499999` |
| secret/12 | n = 200000, k = 1 | n = 200000, k = 1: answer 0 | `0` |
| secret/13 | n = 1000000, k = 1000000 | n = 10^6, k = n: one window | `999997096` |
| secret/14 | n = 200000, k = 100000 | n = 200000, all elements equal: answer 0 | `0` |
| secret/15 | n = 200000, k = 1000 | strictly increasing 1..n, k = 1000: answer 999 (a window of k+1 gives 1000) | `999` |
| secret/16 | n = 200000, k = 50000 | strictly decreasing, k = 50000: answer 49999 | `49999` |
| secret/17 | n = 200000, k = 2 | n = 200000 random, k = 2 | `999622243` |
| secret/18 | n = 200000, k = 10 | n = 200000 random, k = 10 | `999312013` |
| secret/19 | n = 200000, k = 1000 | n = 200000 random, k = 1000 | `999968433` |
| secret/20 | n = 200000, k = 199999 | n = 200000 random, k = n - 1 | `999993952` |
| secret/21 | n = 200000, k = 5000 | n = 200000, values only 1..3, k = 5000 | `2` |
| secret/22 | n = 200000, k = 100 | best window at the very start (contains 1 and 10^9) | `999999999` |
| secret/23 | n = 200000, k = 100 | best window at the very end (contains 10^9 and 1) | `999999999` |
| secret/24 | n = 200000, k = 1000 | global min near the start, global max near the end, never in the same window | `500000999` |
| secret/25 | n = 200000, k = 500 | a high spike every 1000 positions, k = 500 | `999851851` |
| secret/26 | n = 1000000, k = 500000 | n = 10^6, zig-zag 1, 10^9, 1, 10^9, ...: every window has spread 10^9 - 1 | `999999999` |
| secret/27 | n = 1000000, k = 333333 | n = 10^6 random walk (neighbours close in value), k = n/3 | `10064973` |
