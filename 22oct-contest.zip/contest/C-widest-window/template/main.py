import sys

# ---------------- your code starts here ----------------
def solve(n, k, a):
    # return the largest (max - min) over all windows of exactly k consecutive elements
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    sys.stdout.write(f"{solve(n, k, a)}\n")


main()
