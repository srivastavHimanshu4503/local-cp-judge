import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    static int solve(int n, int k, int[] a) {
        // each entry is {value, index}
        PriorityQueue<int[]> maxHeap = new PriorityQueue<>((x, y) -> Integer.compare(y[0], x[0]));
        PriorityQueue<int[]> minHeap = new PriorityQueue<>((x, y) -> Integer.compare(x[0], y[0]));
        int best = 0;
        for (int i = 0; i < n; i++) {
            maxHeap.add(new int[]{a[i], i});
            minHeap.add(new int[]{a[i], i});
            if (i >= k - 1) {
                int left = i - k + 1;
                while (maxHeap.peek()[1] < left) maxHeap.poll();
                while (minHeap.peek()[1] < left) minHeap.poll();
                best = Math.max(best, maxHeap.peek()[0] - minHeap.peek()[0]);
            }
        }
        return best;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = in.nextInt();
        System.out.println(solve(n, k, a));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
