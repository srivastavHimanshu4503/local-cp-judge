import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    static int solve(int n, int k, int[] a) {
        ArrayDeque<Integer> mx = new ArrayDeque<>(), mn = new ArrayDeque<>();
        int best = 0;
        for (int i = 0; i < n; i++) {
            while (!mx.isEmpty() && a[mx.peekLast()] <= a[i]) mx.pollLast();
            mx.addLast(i);
            while (!mn.isEmpty() && a[mn.peekLast()] >= a[i]) mn.pollLast();
            mn.addLast(i);
            int left = i - k + 1;
            if (mx.peekFirst() < left) mx.pollFirst();
            if (mn.peekFirst() < left) mn.pollFirst();
            if (left >= 0) best = Math.max(best, a[mx.peekFirst()] - a[mn.peekFirst()]);
        }
        return best;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int k = in.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = in.nextInt();
        System.out.println(solve(n, k, a));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
