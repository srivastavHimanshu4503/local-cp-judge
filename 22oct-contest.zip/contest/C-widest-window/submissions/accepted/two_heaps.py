import sys

# ---------------- your code starts here ----------------
import heapq


def solve(n, k, a):
    max_heap = []  # (-value, index)
    min_heap = []  # (value, index)
    best = 0
    for i in range(n):
        heapq.heappush(max_heap, (-a[i], i))
        heapq.heappush(min_heap, (a[i], i))
        if i >= k - 1:
            left = i - k + 1  # window is a[left..i]
            while max_heap[0][1] < left:
                heapq.heappop(max_heap)
            while min_heap[0][1] < left:
                heapq.heappop(min_heap)
            best = max(best, -max_heap[0][0] - min_heap[0][0])
    return best
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    sys.stdout.write(f"{solve(n, k, a)}\n")


main()
