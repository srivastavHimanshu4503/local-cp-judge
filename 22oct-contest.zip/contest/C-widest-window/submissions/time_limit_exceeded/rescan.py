import sys

# ---------------- your code starts here ----------------
# Correct but O(n * k): recompute max and min of every window from scratch.
def solve(n, k, a):
    best = 0
    for i in range(n - k + 1):
        w = a[i:i + k]
        best = max(best, max(w) - min(w))
    return best
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    sys.stdout.write(f"{solve(n, k, a)}\n")


main()
