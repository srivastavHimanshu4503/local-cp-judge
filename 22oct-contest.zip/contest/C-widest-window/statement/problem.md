---
title: "Problem C — Widest Window"
---

**Time limit:** 3 seconds (Java), 9 seconds (Python) · **Memory limit:** 1024 MB

You are given an array of **n** integers and a window size **k**. For every contiguous window of exactly **k** elements, its **spread** is its maximum element minus its minimum element.

Find the largest spread over all windows.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// return the largest spread over all windows of size k
static int solve(int n, int k, int[] a)
```

```python
# Python
# return the largest spread over all windows of size k
def solve(n, k, a):
```

## Input

- The first line has two integers **n** and **k**, separated by a space.
- The second line has **n** integers a~1~, a~2~, …, a~n~, separated by spaces.

## Output

Print one integer: the largest spread among all windows of size **k**.

## Constraints

- 1 ≤ k ≤ n ≤ 1 000 000
- 1 ≤ a~i~ ≤ 10^9^

## Example 1

Input:

```
6 3
4 1 7 3 9 2
```

Output:

```
7
```

**Explanation:** There are 6 − 3 + 1 = 4 windows of size 3:

| Window (positions) | Elements | Max | Min | Spread |
|:---:|:---:|:---:|:---:|:---:|
| 1–3 | 4, 1, 7 | 7 | 1 | 6 |
| 2–4 | 1, 7, 3 | 7 | 1 | 6 |
| 3–5 | 7, 3, 9 | 9 | 3 | 6 |
| 4–6 | 3, 9, 2 | 9 | 2 | **7** |

The largest spread is **7**.

## Example 2

Input:

```
3 1
5 9 2
```

Output:

```
0
```

**Explanation:** Each window has a single element, so its max equals its min and every spread is 0. The answer is **0**.

## Example 3

Input:

```
4 4
3 10 6 1
```

Output:

```
9
```

**Explanation:** There is only one window, the whole array. Its max is 10 and its min is 1, so the spread is 10 − 1 = **9**.
