def solve(n, k, a):
    # return the largest (max - min) over all windows of exactly k consecutive elements
    return 0
