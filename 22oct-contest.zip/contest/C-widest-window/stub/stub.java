    // return the largest (max - min) over all windows of exactly k consecutive elements
    static int solve(int n, int k, int[] a) {
        return 0;
    }
