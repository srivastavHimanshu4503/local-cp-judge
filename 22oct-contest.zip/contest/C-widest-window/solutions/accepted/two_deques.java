    static int solve(int n, int k, int[] a) {
        ArrayDeque<Integer> mx = new ArrayDeque<>(), mn = new ArrayDeque<>();
        int best = 0;
        for (int i = 0; i < n; i++) {
            while (!mx.isEmpty() && a[mx.peekLast()] <= a[i]) mx.pollLast();
            mx.addLast(i);
            while (!mn.isEmpty() && a[mn.peekLast()] >= a[i]) mn.pollLast();
            mn.addLast(i);
            int left = i - k + 1;
            if (mx.peekFirst() < left) mx.pollFirst();
            if (mn.peekFirst() < left) mn.pollFirst();
            if (left >= 0) best = Math.max(best, a[mx.peekFirst()] - a[mn.peekFirst()]);
        }
        return best;
    }
