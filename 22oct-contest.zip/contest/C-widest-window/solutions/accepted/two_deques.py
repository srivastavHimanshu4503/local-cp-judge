from collections import deque


def solve(n, k, a):
    mx = deque()  # indices, values decreasing
    mn = deque()  # indices, values increasing
    best = 0
    for i in range(n):
        while mx and a[mx[-1]] <= a[i]:
            mx.pop()
        mx.append(i)
        while mn and a[mn[-1]] >= a[i]:
            mn.pop()
        mn.append(i)
        left = i - k + 1
        if mx[0] < left:
            mx.popleft()
        if mn[0] < left:
            mn.popleft()
        if left >= 0:
            best = max(best, a[mx[0]] - a[mn[0]])
    return best
