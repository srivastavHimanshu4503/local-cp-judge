# Correct but O(n * k): recompute max and min of every window from scratch.
def solve(n, k, a):
    best = 0
    for i in range(n - k + 1):
        w = a[i:i + k]
        best = max(best, max(w) - min(w))
    return best
