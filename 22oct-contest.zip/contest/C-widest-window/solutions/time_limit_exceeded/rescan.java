    // Correct but O(n * k): recompute max and min of every window from scratch.
    static int solve(int n, int k, int[] a) {
        int best = 0;
        for (int i = 0; i + k <= n; i++) {
            int mx = a[i], mn = a[i];
            for (int j = i; j < i + k; j++) {
                mx = Math.max(mx, a[j]);
                mn = Math.min(mn, a[j]);
            }
            best = Math.max(best, mx - mn);
        }
        return best;
    }
