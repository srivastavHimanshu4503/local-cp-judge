    // Bug: lazy deletion only on the max-heap; the min-heap keeps expired elements.
    static int solve(int n, int k, int[] a) {
        PriorityQueue<int[]> maxHeap = new PriorityQueue<>((x, y) -> Integer.compare(y[0], x[0]));
        PriorityQueue<int[]> minHeap = new PriorityQueue<>((x, y) -> Integer.compare(x[0], y[0]));
        int best = 0;
        for (int i = 0; i < n; i++) {
            maxHeap.add(new int[]{a[i], i});
            minHeap.add(new int[]{a[i], i});
            if (i >= k - 1) {
                int left = i - k + 1;
                while (maxHeap.peek()[1] < left) maxHeap.poll();
                best = Math.max(best, maxHeap.peek()[0] - minHeap.peek()[0]);
            }
        }
        return best;
    }
