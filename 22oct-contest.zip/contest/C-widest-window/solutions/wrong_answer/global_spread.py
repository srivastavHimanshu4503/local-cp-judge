# Bug: ignores the window and returns max(a) - min(a).
def solve(n, k, a):
    return max(a) - min(a)
