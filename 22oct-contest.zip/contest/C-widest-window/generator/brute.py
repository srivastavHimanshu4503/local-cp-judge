"""Independent checker for small tests: try every window directly.
Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, k = int(data[0]), int(data[1])
assert n * k <= 5_000_000, "too big for brute"
a = [int(x) for x in data[2:2 + n]]
best = 0
for i in range(n - k + 1):
    best = max(best, max(a[i:i + k]) - min(a[i:i + k]))
print(best)
