"""Strict input validator for Problem C. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+ \d+\n\d+( \d+)*\n", data), "bad format"
lines = data.split("\n")
n, k = map(int, lines[0].split())
assert 1 <= k <= n <= 1_000_000, "n or k out of range"
a = list(map(int, lines[1].split()))
assert len(a) == n, "wrong number of values"
assert all(1 <= x <= 10**9 for x in a), "value out of range"
print("OK")
