"""Deterministic test generator for Problem C (Widest Window).

Usage: python3 gen.py <problem_dir>
"""
import os
import random
import sys

MAXN = 200_000      # most large tests
BIGN = 1_000_000    # the tests that must defeat O(n*k) rescanning
MAXV = 10**9

SAMPLES = [
    ("6 3\n4 1 7 3 9 2\n", "Statement example 1: four windows, best spread 7 in the last one"),
    ("3 1\n5 9 2\n", "Statement example 2: k = 1, every spread is 0"),
    ("4 4\n3 10 6 1\n", "Statement example 3: k = n, one window"),
]


def fmt(k, a):
    return f"{len(a)} {k}\n" + " ".join(map(str, a)) + "\n"


def secret_tests():
    rng = random.Random(20261023)
    t = []
    t.append((1, [42], "n = 1"))
    t.append((2, [1, MAXV], "n = 2, k = 2: largest possible spread 10^9 - 1"))
    for i in range(6):
        n = rng.randint(2, 15)
        k = rng.randint(1, n)
        t.append((k, [rng.randint(1, 20) for _ in range(n)], f"small random #{i + 1} (n = {n}, k = {k})"))

    rand = lambda n, lo=1, hi=MAXV: [rng.randint(lo, hi) for _ in range(n)]

    t.append((BIGN // 2, rand(BIGN), "n = 10^6, k = n/2: rescanning every window takes ~2.5*10^11 steps"))
    t.append((BIGN // 2, list(range(1, BIGN + 1)), "n = 10^6 strictly increasing, k = n/2: answer 499999; min expires every step"))
    t.append((BIGN // 2, list(range(BIGN, 0, -1)), "n = 10^6 strictly decreasing, k = n/2: answer 499999; max expires every step"))
    t.append((1, rand(MAXN), "n = 200000, k = 1: answer 0"))
    t.append((BIGN, rand(BIGN), "n = 10^6, k = n: one window"))
    t.append((MAXN // 2, [777] * MAXN, "n = 200000, all elements equal: answer 0"))
    t.append((1000, list(range(1, MAXN + 1)), "strictly increasing 1..n, k = 1000: answer 999 (a window of k+1 gives 1000)"))
    t.append((50_000, list(range(MAXN, 0, -1)), "strictly decreasing, k = 50000: answer 49999"))
    t.append((2, rand(MAXN), "n = 200000 random, k = 2"))
    t.append((10, rand(MAXN), "n = 200000 random, k = 10"))
    t.append((1000, rand(MAXN), "n = 200000 random, k = 1000"))
    t.append((MAXN - 1, rand(MAXN), "n = 200000 random, k = n - 1"))
    t.append((5000, rand(MAXN, 1, 3), "n = 200000, values only 1..3, k = 5000"))

    a = rand(MAXN, 400_000_000, 600_000_000)
    a[0], a[1] = 1, MAXV
    t.append((100, a, "best window at the very start (contains 1 and 10^9)"))

    a = rand(MAXN, 400_000_000, 600_000_000)
    a[-1], a[-2] = MAXV, 1
    t.append((100, a, "best window at the very end (contains 10^9 and 1)"))

    # global minimum early, maximum late, far apart: a min-heap without lazy deletion pairs them
    a = rand(MAXN, 500_000_000, 500_001_000)
    a[5] = 1
    a[MAXN - 5] = MAXV
    t.append((1000, a, "global min near the start, global max near the end, never in the same window"))

    # spikes: a spike every 1000 positions, window shorter than the gap
    a = rand(MAXN, 1000, 2000)
    for i in range(0, MAXN, 1000):
        a[i] = rng.randint(MAXV // 2, MAXV)
    t.append((500, a, "a high spike every 1000 positions, k = 500"))

    # zig-zag
    a = [1 if i % 2 == 0 else MAXV for i in range(BIGN)]
    t.append((BIGN // 2, a, "n = 10^6, zig-zag 1, 10^9, 1, 10^9, ...: every window has spread 10^9 - 1"))

    # valleys: slowly varying random walk
    a, x = [], MAXV // 2
    for _ in range(BIGN):
        x = min(MAXV, max(1, x + rng.randint(-10**4, 10**4)))
        a.append(x)
    t.append((BIGN // 3, a, "n = 10^6 random walk (neighbours close in value), k = n/3"))
    return t


def write(dirpath, name, content, desc):
    with open(os.path.join(dirpath, name + ".in"), "w") as f:
        f.write(content)
    with open(os.path.join(dirpath, name + ".desc"), "w") as f:
        f.write(desc + "\n")


def main():
    root = sys.argv[1]
    sd = os.path.join(root, "data", "sample")
    xd = os.path.join(root, "data", "secret")
    for d in (sd, xd):
        os.makedirs(d, exist_ok=True)
        for f in os.listdir(d):
            os.remove(os.path.join(d, f))
    for i, (content, desc) in enumerate(SAMPLES, 1):
        write(sd, f"{i:02d}", content, desc)
    for i, (k, a, desc) in enumerate(secret_tests(), 1):
        write(xd, f"{i:02d}", fmt(k, a), desc)


if __name__ == "__main__":
    main()
