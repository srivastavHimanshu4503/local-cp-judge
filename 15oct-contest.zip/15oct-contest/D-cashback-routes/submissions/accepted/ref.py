from __future__ import annotations

import sys
import threading

INF = 10**18   # return this as the cost of a stop that cannot be reached from s

# Bellman-Ford: n-1 rounds of relaxing every route, then one more round to look for a negative loop.
def shortest_costs(n: int, routes: list[list[int]], s: int) -> list[int] | None:
    cost = [INF] * n
    cost[s] = 0
    for _ in range(n - 1):
        changed = False
        for u, v, w in routes:
            if cost[u] != INF and cost[u] + w < cost[v]:   # never relax out of an unreached stop
                cost[v] = cost[u] + w
                changed = True
        if not changed:
            break
    for u, v, w in routes:
        if cost[u] != INF and cost[u] + w < cost[v]:
            return None                                   # still improving: a negative loop is reachable
    return cost



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _show(x) -> str:
    if x == INF or x == float("inf"):
        return "INF"
    return str(int(x))


def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m, s = int(data[0]), int(data[1]), int(data[2])
    routes = [[int(data[3 + 3 * i]), int(data[4 + 3 * i]), int(data[5 + 3 * i])] for i in range(m)]
    result = shortest_costs(n, routes, s)
    if result is None:
        print("NEGATIVE CYCLE")
    else:
        sys.stdout.write("\n".join(_show(x) for x in result) + "\n")


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
