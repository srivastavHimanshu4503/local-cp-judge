from __future__ import annotations

import sys
import threading

INF = 10**18   # return this as the cost of a stop that cannot be reached from s

# Dijkstra with a "done" set: once a stop is finalised it is never improved again,
# which is wrong as soon as a negative route exists.
import heapq


def shortest_costs(n: int, routes: list[list[int]], s: int) -> list[int] | None:
    out = [[] for _ in range(n)]
    for u, v, w in routes:
        out[u].append((v, w))
    cost = [INF] * n
    cost[s] = 0
    done = [False] * n
    heap = [(0, s)]
    while heap:
        c, u = heapq.heappop(heap)
        if done[u]:
            continue
        done[u] = True
        for v, w in out[u]:
            if not done[v] and c + w < cost[v]:
                cost[v] = c + w
                heapq.heappush(heap, (cost[v], v))
    return cost



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _show(x) -> str:
    if x == INF or x == float("inf"):
        return "INF"
    return str(int(x))


def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m, s = int(data[0]), int(data[1]), int(data[2])
    routes = [[int(data[3 + 3 * i]), int(data[4 + 3 * i]), int(data[5 + 3 * i])] for i in range(m)]
    result = shortest_costs(n, routes, s)
    if result is None:
        print("NEGATIVE CYCLE")
    else:
        sys.stdout.write("\n".join(_show(x) for x in result) + "\n")


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
