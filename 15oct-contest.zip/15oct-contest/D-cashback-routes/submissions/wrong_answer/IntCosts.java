import java.io.*;
import java.util.*;

// Stores costs in int. Totals can reach about 2.5 * 10^12, which overflows.
class Solution {
    public long[] shortestCosts(int n, int[][] routes, int s) {
        int[] cost = new int[n];
        Arrays.fill(cost, Integer.MAX_VALUE);
        cost[s] = 0;
        for (int round = 1; round < n; round++)
            for (int[] r : routes)
                if (cost[r[0]] != Integer.MAX_VALUE && cost[r[0]] + r[2] < cost[r[1]]) cost[r[1]] = cost[r[0]] + r[2];
        for (int[] r : routes)
            if (cost[r[0]] != Integer.MAX_VALUE && cost[r[0]] + r[2] < cost[r[1]]) return null;
        long[] ans = new long[n];
        for (int i = 0; i < n; i++) ans[i] = cost[i] == Integer.MAX_VALUE ? 1_000_000_000_000_000_000L : cost[i];
        return ans;
    }
}



// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    static final long INF = 1_000_000_000_000_000_000L;

    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt(), m = in.nextInt(), s = in.nextInt();
        int[][] routes = new int[m][3];
        for (int i = 0; i < m; i++) {
            routes[i][0] = in.nextInt();
            routes[i][1] = in.nextInt();
            routes[i][2] = in.nextInt();
        }
        long[] result = new Solution().shortestCosts(n, routes, s);
        StringBuilder sb = new StringBuilder();
        if (result == null) {
            sb.append("NEGATIVE CYCLE\n");
        } else {
            for (long x : result) {
                if (x == INF || x == Long.MAX_VALUE) sb.append("INF\n");
                else sb.append(x).append('\n');
            }
        }
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        out.print(sb);
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }
}
