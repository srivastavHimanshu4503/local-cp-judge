from __future__ import annotations

import sys
import threading

# Treats each cable as ONE-WAY (a -> b only), so groups split when cables are listed "backwards".
from collections import deque


def can_reach(n: int, cables: list[list[int]], queries: list[list[int]]) -> list[bool]:
    adj = [[] for _ in range(n)]
    for a, b in cables:
        adj[a].append(b)                 # bug: missing adj[b].append(a)
    comp = [-1] * n
    for start in range(n):
        if comp[start] != -1:
            continue
        comp[start] = start
        queue = deque([start])
        while queue:
            x = queue.popleft()
            for y in adj[x]:
                if comp[y] == -1:
                    comp[y] = start
                    queue.append(y)
    return [comp[u] == comp[v] for u, v in queries]



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m, q = int(data[0]), int(data[1]), int(data[2])
    p = 3
    cables = [[int(data[p + 2 * i]), int(data[p + 2 * i + 1])] for i in range(m)]
    p += 2 * m
    queries = [[int(data[p + 2 * i]), int(data[p + 2 * i + 1])] for i in range(q)]
    answers = can_reach(n, cables, queries)
    sys.stdout.write("\n".join("YES" if a else "NO" for a in answers) + "\n")


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
