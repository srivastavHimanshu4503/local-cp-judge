import java.io.*;
import java.util.*;

class Solution {
    public boolean[] canReach(int n, int[][] cables, int[][] queries) {
        List<List<Integer>> adj = new ArrayList<>();
        for (int i = 0; i < n; i++) adj.add(new ArrayList<>());
        for (int[] c : cables) {
            adj.get(c[0]).add(c[1]);
            adj.get(c[1]).add(c[0]);
        }
        int[] comp = new int[n];
        Arrays.fill(comp, -1);
        int[] queue = new int[n];
        for (int start = 0; start < n; start++) {
            if (comp[start] != -1) continue;
            int head = 0, tail = 0;
            comp[start] = start;
            queue[tail++] = start;
            while (head < tail) {
                int x = queue[head++];
                for (int y : adj.get(x))
                    if (comp[y] == -1) { comp[y] = start; queue[tail++] = y; }
            }
        }
        boolean[] ans = new boolean[queries.length];
        for (int i = 0; i < queries.length; i++) ans[i] = comp[queries[i][0]] == comp[queries[i][1]];
        return ans;
    }
}



// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt(), m = in.nextInt(), q = in.nextInt();
        int[][] cables = new int[m][2];
        for (int i = 0; i < m; i++) {
            cables[i][0] = in.nextInt();
            cables[i][1] = in.nextInt();
        }
        int[][] queries = new int[q][2];
        for (int i = 0; i < q; i++) {
            queries[i][0] = in.nextInt();
            queries[i][1] = in.nextInt();
        }
        boolean[] answers = new Solution().canReach(n, cables, queries);
        StringBuilder sb = new StringBuilder();
        for (boolean a : answers) sb.append(a ? "YES" : "NO").append('\n');
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        out.print(sb);
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }
}
