from __future__ import annotations

import sys
import threading

# Sorts both, but compares pairwise with zip(), which silently stops at the shorter string.
def is_anagram(s: str, t: str) -> bool:
    return all(a == b for a, b in zip(sorted(s), sorted(t)))



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    s = data[0].decode()
    t = data[1].decode()
    print("YES" if is_anagram(s, t) else "NO")


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
