from __future__ import annotations

import sys
import threading

# O(n^2): delete each letter of s from t, one at a time.
# At |s| = 2*10^5 this runs in about 0.6 s; at 10^6 it needs about 15 s.
def is_anagram(s: str, t: str) -> bool:
    if len(s) != len(t):
        return False
    for c in s:
        if c not in t:
            return False
        t = t.replace(c, "", 1)
    return True



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    s = data[0].decode()
    t = data[1].decode()
    print("YES" if is_anagram(s, t) else "NO")


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
