from __future__ import annotations

import sys
import threading

from bisect import bisect_right


def floor_index(arr: list[int], key: int) -> int:
    return bisect_right(arr, key) - 1



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    arr = [int(x) for x in data[2:2 + n]]
    keys = data[2 + n:2 + n + q]
    answers = [floor_index(arr, int(k)) for k in keys]   # your function is called once per query
    sys.stdout.write("\n".join(map(str, answers)) + "\n")


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
