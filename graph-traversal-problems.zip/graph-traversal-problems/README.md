# Graph Traversals Contest

Open `index.html` in a browser to see the four problems.

| Folder | Problem | Difficulty |
|---|---|---|
| `A-notes-chain` | The Notes Chain | Very easy |
| `B-power-cut` | Power Cut | Easy |
| `C-hackathon-leaderboard` | Hackathon Leaderboard | Medium |
| `D-networking-night` | Networking Night | Hard |

Each folder contains `statement.html` and a `tests` folder:

- `tests/sample/` are the examples from the statement.
- `tests/secret/` are the hidden tests used to judge submissions during the contest.

Every test is a pair of files. `NN-name.in` is the input, and `NN-name.ans` is the expected output. The file names describe what each test checks, so if you fail one, the name is a hint about what your solution missed.

## Testing your solution

Run your program on all tests of a problem with `run_tests.py` (needs Python 3):

```
python3 run_tests.py A-notes-chain python3 notes.py
python3 run_tests.py D-networking-night java Main.java
```

Add `--samples` to run only the examples, or `--timeout 1` to use the contest's time limit of 1 second. Outputs are compared word by word, so extra spaces and blank lines don't matter.

To try a single test by hand:

```
python3 notes.py < A-notes-chain/tests/secret/04-student1-isolated.in
```
