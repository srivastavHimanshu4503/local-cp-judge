#!/usr/bin/env python3
"""Check your solution against all tests for one problem.

Usage:
    python3 run_tests.py <problem-folder> <command to run your solution>

Examples:
    python3 run_tests.py A-notes-chain python3 notes.py
    python3 run_tests.py D-networking-night java Main.java
    python3 run_tests.py C-hackathon-leaderboard ./a.out

Options (put them before the problem folder):
    --timeout SECONDS   time allowed per test (default 2; the contest used 1)
    --samples           run only the sample tests
"""
import glob, os, subprocess, sys, time

args = sys.argv[1:]; timeout = 2.0; only_samples = False
while args and args[0].startswith("--"):
    if args[0] == "--timeout": timeout = float(args[1]); args = args[2:]
    elif args[0] == "--samples": only_samples = True; args = args[1:]
    else: sys.exit(f"Unknown option {args[0]}\n\n{__doc__}")
if len(args) < 2: sys.exit(__doc__)
folder, cmd = args[0].rstrip("/"), args[1:]
here = os.path.dirname(os.path.abspath(__file__))
if not os.path.isdir(folder): folder = os.path.join(here, folder)
kinds = ["sample"] if only_samples else ["sample", "secret"]
tests = [f for k in kinds for f in sorted(glob.glob(os.path.join(folder, "tests", k, "*.in")))]
if not tests: sys.exit(f"No tests found in {folder}/tests. Check the folder name.")

passed = 0
for f in tests:
    name = os.path.relpath(f, os.path.join(folder, "tests"))[:-3]
    expected = open(f[:-3] + ".ans").read().split()
    start = time.time()
    try:
        with open(f) as inp:
            r = subprocess.run(cmd, stdin=inp, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        print(f"TIME LIMIT     {name}  (over {timeout:g}s)"); continue
    except FileNotFoundError:
        sys.exit(f"Could not run {' '.join(cmd)}. Check the command.")
    t = time.time() - start
    if r.returncode != 0:
        print(f"RUNTIME ERROR  {name}  (exit code {r.returncode})")
        if r.stderr.strip(): print("    " + r.stderr.strip().splitlines()[-1])
    elif r.stdout.split() != expected:
        got = " ".join(r.stdout.split()); exp = " ".join(expected)
        print(f"WRONG ANSWER   {name}")
        print(f"    expected: {exp[:100]}{'...' if len(exp) > 100 else ''}")
        print(f"    got:      {got[:100]}{'...' if len(got) > 100 else ''}")
    else:
        passed += 1; print(f"ok             {name}  ({t:.2f}s)")
print(f"\n{passed}/{len(tests)} tests passed")
