import sys
d=sys.stdin.read().split(); n,m=int(d[0]),int(d[1]); t=[0]+[int(x) for x in d[2:2+n]]
best=[-1]*(n+1); best[1]=t[1]
for i in range(m):
    a,b=int(d[2+n+2*i]),int(d[3+n+2*i])
    if best[a]>=0: best[b]=max(best[b],best[a]+t[b])
print(max(best))
