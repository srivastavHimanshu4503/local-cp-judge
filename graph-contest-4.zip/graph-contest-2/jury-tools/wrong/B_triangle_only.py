import sys
d=sys.stdin.read().split(); n,m=int(d[0]),int(d[1]); g=[set() for _ in range(n+1)]
for i in range(m):
    a,b=int(d[2+2*i]),int(d[3+2*i])
    if g[a]&g[b]: print(i+1); sys.exit()
    g[a].add(b); g[b].add(a)
print(-1)
