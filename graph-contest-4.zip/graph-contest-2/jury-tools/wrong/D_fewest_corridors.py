import sys
from collections import deque
d=sys.stdin.read().split(); n,m,c,k=int(d[0]),int(d[1]),int(d[2]),int(d[3]); g=[[] for _ in range(n+1)]
for i in range(m): u,v,t=int(d[4+3*i]),int(d[5+3*i]),int(d[6+3*i]); g[v].append((u,t))
hop=[-1]*(n+1); tm=[0]*(n+1); hop[c]=0; q=deque([c])
while q:
    u=q.popleft()
    for v,t in g[u]:
        if hop[v]<0: hop[v]=hop[u]+1; tm[v]=tm[u]+t; q.append(v)
print(max(tm[int(s)] for s in d[4+3*m:4+3*m+k]))
