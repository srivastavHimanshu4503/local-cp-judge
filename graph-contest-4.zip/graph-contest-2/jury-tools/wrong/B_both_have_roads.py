import sys
d=sys.stdin.read().split(); n,m=int(d[0]),int(d[1]); has=set()
for i in range(m):
    a,b=int(d[2+2*i]),int(d[3+2*i])
    if a in has and b in has: print(i+1); sys.exit()
    has|={a,b}
print(-1)
