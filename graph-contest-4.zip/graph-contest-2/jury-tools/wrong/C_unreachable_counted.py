import sys
d=sys.stdin.read().split(); n,m=int(d[0]),int(d[1]); t=[0]+[int(x) for x in d[2:2+n]]
out=[[] for _ in range(n+1)]
for i in range(m): out[int(d[2+n+2*i])].append(int(d[3+n+2*i]))
best=t[:]
for a in range(1,n+1):
    for b in out[a]: best[b]=max(best[b],best[a]+t[b])
print(max(best[1:]))
