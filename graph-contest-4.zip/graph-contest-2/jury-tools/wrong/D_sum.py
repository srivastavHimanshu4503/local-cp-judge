import sys, heapq
d=sys.stdin.read().split(); n,m,c,k=int(d[0]),int(d[1]),int(d[2]),int(d[3]); g=[[] for _ in range(n+1)]
for i in range(m): u,v,t=int(d[4+3*i]),int(d[5+3*i]),int(d[6+3*i]); g[v].append((u,t))
I=float('inf'); D=[I]*(n+1); D[c]=0; h=[(0,c)]
while h:
    du,u=heapq.heappop(h)
    if du>D[u]: continue
    for v,t in g[u]:
        if du+t<D[v]: D[v]=du+t; heapq.heappush(h,(du+t,v))
print(sum(D[int(s)] for s in d[4+3*m:4+3*m+k]))
