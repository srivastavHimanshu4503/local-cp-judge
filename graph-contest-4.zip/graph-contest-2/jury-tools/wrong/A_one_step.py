import sys
d=sys.stdin.read().split(); n,m,s=int(d[0]),int(d[1]),int(d[2])
print(len({int(d[3+2*i]) for i in range(m) if int(d[4+2*i])==s}))
