import sys
d=sys.stdin.read().split(); n,m,s=int(d[0]),int(d[1]),int(d[2]); g=[[] for _ in range(n+1)]
for i in range(m): a,b=int(d[3+2*i]),int(d[4+2*i]); g[a].append(b); g[b].append(a)
seen={s}; st=[s]
while st:
    u=st.pop()
    for v in g[u]:
        if v not in seen: seen.add(v); st.append(v)
print(len(seen)-1)
