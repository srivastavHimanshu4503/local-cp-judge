import sys, heapq
d=sys.stdin.buffer.read().split(); n,m,c,k=int(d[0]),int(d[1]),int(d[2]),int(d[3]); g=[[] for _ in range(n+1)]
for i in range(m): u,v,t=int(d[4+3*i]),int(d[5+3*i]),int(d[6+3*i]); g[u].append((v,t))
ans=0
for s in set(int(x) for x in d[4+3*m:4+3*m+k]):
    D={s:0}; h=[(0,s)]
    while h:
        du,u=heapq.heappop(h)
        if u==c: ans=max(ans,du); break
        if du>D[u]: continue
        for v,t in g[u]:
            if du+t<D.get(v,1<<60): D[v]=du+t; heapq.heappush(h,(du+t,v))
print(ans)
