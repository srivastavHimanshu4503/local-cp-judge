import java.util.*; import java.io.*;
public class DPerStudent { public static void main(String[] x) throws IOException {
  StreamTokenizer st=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
  st.nextToken(); int n=(int)st.nval; st.nextToken(); int m=(int)st.nval; st.nextToken(); int c=(int)st.nval; st.nextToken(); int k=(int)st.nval;
  List<List<int[]>> g=new ArrayList<>(); for(int i=0;i<=n;i++) g.add(new ArrayList<>());
  for(int i=0;i<m;i++){st.nextToken();int u=(int)st.nval;st.nextToken();int v=(int)st.nval;st.nextToken();int t=(int)st.nval;g.get(u).add(new int[]{v,t});}
  TreeSet<Integer> ss=new TreeSet<>(); for(int i=0;i<k;i++){st.nextToken(); ss.add((int)st.nval);}
  int ans=0; int[] dist=new int[n+1];
  for(int s:ss){ Arrays.fill(dist,Integer.MAX_VALUE); dist[s]=0; PriorityQueue<int[]> pq=new PriorityQueue<>((a,b)->Integer.compare(a[0],b[0])); pq.add(new int[]{0,s});
    while(!pq.isEmpty()){int[] e=pq.poll(); if(e[1]==c){ans=Math.max(ans,e[0]);break;} if(e[0]>dist[e[1]]) continue;
      for(int[] w:g.get(e[1])) if(e[0]+w[1]<dist[w[0]]){dist[w[0]]=e[0]+w[1]; pq.add(new int[]{dist[w[0]],w[0]});}}}
  System.out.println(ans);
}}
