import sys, glob, re
from collections import deque
def lines(path):
    s=open(path).read(); assert s.endswith("\n") and "\r" not in s and "  " not in s, "whitespace"
    L=s.split("\n")[:-1]
    for l in L: assert l==l.strip() and l!="", "bad line"
    return L
def ints(l):
    for t in l.split(): assert re.fullmatch(r"-?\d+",t), t
    return list(map(int,l.split()))
def vA(p):
    L=lines(p); n,m,s=ints(L[0]); assert 1<=n<=500 and 0<=m<=2000 and 1<=s<=n and len(L)==m+1
    seen=set()
    for l in L[1:]:
        a,b=ints(l); assert 1<=a<=n and 1<=b<=n and a!=b and (a,b) not in seen; seen.add((a,b))
def vB(p):
    L=lines(p); n,m=ints(L[0]); assert 1<=n<=300 and 0<=m<=1000 and len(L)==m+1
    seen=set()
    for l in L[1:]:
        a,b=ints(l); k=(min(a,b),max(a,b)); assert 1<=a<=n and 1<=b<=n and a!=b and k not in seen; seen.add(k)
def vC(p):
    L=lines(p); n,m=ints(L[0]); assert 1<=n<=500 and 0<=m<=5000 and len(L)==m+2
    t=ints(L[1]); assert len(t)==n and all(1<=x<=10**6 for x in t)
    seen=set()
    for l in L[2:]:
        a,b=ints(l); assert 1<=a<b<=n and (a,b) not in seen; seen.add((a,b))
def vD(p):
    L=lines(p); n,m,c,k=ints(L[0]); assert 2<=n<=10**4 and 1<=m<=5*10**4 and 1<=c<=n and 1<=k<=10**4 and len(L)==m+2
    seen=set(); rg=[[] for _ in range(n+1)]
    for l in L[1:m+1]:
        u,v,t=ints(l); assert 1<=u<=n and 1<=v<=n and u!=v and 1<=t<=1000 and (u,v) not in seen; seen.add((u,v)); rg[v].append(u)
    st=ints(L[m+1]); assert len(st)==k and all(1<=x<=n for x in st)
    ok=[False]*(n+1); ok[c]=True; q=deque([c])
    while q:
        u=q.popleft()
        for w in rg[u]:
            if not ok[w]: ok[w]=True; q.append(w)
    assert all(ok[x] for x in st), "student cannot reach canteen"
V=dict(A=vA,B=vB,C=vC,D=vD); bad=0
for P in "ABCD":
    for f in sorted(glob.glob(f"pkg/{P}/data/*/*.in")):
        try: V[P](f)
        except Exception as e: bad+=1; print("INVALID",f,repr(e))
print("invalid files:",bad)
