cd /home/claude/c2
for P in A B C D; do for f in pkg/$P/data/*/*.in; do python3 sol/$P.py < $f > ${f%.in}.ans; done; done
jm=0; for P in A B C D; do for f in pkg/$P/data/*/*.in; do
  [ "$(java -Xss64m sol/$P.java < $f)" != "$(cat ${f%.in}.ans)" ] && { echo "JAVA MISMATCH $f"; jm=1; }; done; done
echo "java mismatch=$jm"
for P in A B C D; do n=0; bm=0; for f in pkg/$P/data/*/*.in; do
  N=$(head -1 $f | cut -d' ' -f1)
  case $P in C) [ $N -gt 12 ] && continue;; D) [ $N -gt 60 ] && continue;; esac
  n=$((n+1)); [ "$(timeout 60 python3 brute/$P.py < $f)" != "$(cat ${f%.in}.ans)" ] && { echo "BRUTE MISMATCH $f"; bm=1; }; done
  echo "$P brute-checked $n files, mismatch=$bm"; done
