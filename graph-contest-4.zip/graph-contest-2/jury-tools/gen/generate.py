import random, os, shutil
OUT = "/home/claude/c2/pkg"; rng = random.Random(20261001)
def write(P, kind, name, text):
    d = f"{OUT}/{P}/data/{kind}"; os.makedirs(d, exist_ok=True)
    open(f"{d}/{name}.in", "w").write(text)
def emit(P, samples, tests):
    for k,(nm,t) in enumerate(samples,1): write(P,"sample",f"{k:02d}-{nm}",t)
    for k,(nm,t) in enumerate(tests,1): write(P,"secret",f"{k:02d}-{nm}",t)
def uniq_pairs(pairs):
    seen=set(); out=[]
    for p in pairs:
        if p not in seen: seen.add(p); out.append(p)
    return out

# ---------------- A: Story Reshares ----------------
def fa(n, s, E, shuffle=True):
    E = uniq_pairs(E)
    if shuffle: rng.shuffle(E)
    return f"{n} {len(E)} {s}\n" + "".join(f"{a} {b}\n" for a,b in E)
def gen_A():
    S = [("sample1", fa(6,1,[(2,1),(3,2),(1,4),(5,3),(4,6)],False)), ("sample2", fa(3,2,[(2,1),(2,3)],False))]
    T = [("single-student", fa(1,1,[])),
         ("one-follower", fa(2,1,[(2,1)])),
         ("poster-follows-other", fa(2,1,[(1,2)])),
         ("mutual-follow", fa(2,2,[(1,2),(2,1)])),
         ("chain-one-way-only", fa(5,3,[(4,3),(5,4),(3,2),(2,1)])),
         ("poster-follows-everyone", fa(6,1,[(1,i) for i in range(2,7)])),
         ("follow-cycle", fa(5,2,[(3,2),(4,3),(5,4),(1,5),(2,1)])),
         ("poster-is-last-student", fa(5,5,[(1,5),(2,1),(3,4)])),
         ("two-routes-same-viewer", fa(4,1,[(2,1),(3,1),(4,2),(4,3)])),
         ("long-chain-with-wrong-way-branches", fa(8,1,[(2,1),(3,2),(4,3),(3,5),(6,5),(4,7),(8,7)]))]
    n = 500
    T.append(("max-n-no-follows", fa(n,250,[])))
    T.append(("everyone-follows-poster", fa(n,137,[(i,137) for i in range(1,n+1) if i!=137])))
    T.append(("poster-follows-everyone-big", fa(n,1,[(1,i) for i in range(2,n+1)])))
    p=list(range(1,n+1)); rng.shuffle(p)
    T.append(("long-chain-right-way", fa(n,p[0],[(p[i+1],p[i]) for i in range(n-1)])))
    T.append(("long-chain-wrong-way", fa(n,p[0],[(p[i],p[i+1]) for i in range(n-1)])))
    def popular(E):
        cnt={}
        for a,b in E: cnt[b]=cnt.get(b,0)+1
        return rng.choice([x for x in cnt if cnt[x]>=2])
    E=[tuple(rng.sample(range(1,n+1),2)) for _ in range(2000)]
    T.append(("random-dense", fa(n,popular(E),E)))
    E=[tuple(rng.sample(range(1,n+1),2)) for _ in range(550)]
    T.append(("random-sparse", fa(n,popular(E),E)))
    # reachable group R (300): followers tree toward s; group R also follows lots of outsiders (wrong way)
    rng.shuffle(p); s=p[0]; R=p[:300]; O=p[300:]; E=[]
    for i in range(1,300): E.append((R[i], R[rng.randrange(i)]))
    while len(E)<1500: E.append((rng.choice(R), rng.choice(O)))
    while len(E)<2000:
        a,b=rng.sample(O,2); E.append((a,b))
    T.append(("big-group-plus-wrong-way-links", fa(n,s,E)))
    rng.shuffle(p); s=p[0]; E=[(s,x) for x in p[1:200]]
    while len(E)<2000:
        a,b=rng.sample(p[1:],2); E.append((a,b))
    T.append(("poster-has-no-followers-busy-app", fa(n,s,E)))
    rng.shuffle(p); E=[]
    for i in range(1,n): E.append((p[i], p[rng.randrange(i)]))
    for i in range(1,n):
        if rng.random()<.6: E.append((p[rng.randrange(i)], p[i]))
    T.append(("follower-tree-plus-reverse-follows", fa(n,p[0],E)))
    E=[]
    for _ in range(900):
        a,b=rng.sample(range(1,n+1),2); E+= [(a,b),(b,a)]
    T.append(("random-mutual-follows", fa(n,rng.randint(1,n),E)))
    emit("A",S,T)

# ---------------- B: Loop Alert ----------------
def fb(n, E):
    seen=set(); F=[]
    for a,b in E:
        k=(min(a,b),max(a,b))
        if k not in seen and a!=b: seen.add(k); F.append((a,b))
    return f"{n} {len(F)}\n" + "".join(f"{a} {b}\n" for a,b in F)
def rtree(nodes):
    nodes=list(nodes); rng.shuffle(nodes)
    return [(nodes[i], nodes[rng.randrange(i)]) for i in range(1,len(nodes))]
def gen_B():
    S=[("sample1", fb(5,[(1,2),(3,4),(2,3),(5,1),(4,1),(2,5)])), ("sample2", fb(4,[(1,2),(2,3),(3,4)]))]
    T=[("one-spot-no-roads", fb(1,[])), ("single-road", fb(2,[(1,2)])), ("triangle", fb(3,[(1,2),(2,3),(3,1)])),
       ("square-closes-last", fb(4,[(1,2),(3,4),(2,3),(4,1)])),
       ("join-groups-then-loop", fb(6,[(1,2),(3,4),(5,6),(2,3),(4,5),(6,1)])),
       ("path-then-nothing", fb(6,[(1,2),(2,3),(3,4),(4,5),(5,6)])),
       ("star-then-leaf-link", fb(5,[(1,2),(1,3),(1,4),(1,5),(3,4)])),
       ("long-loop-of-six", fb(6,[(1,2),(2,3),(3,4),(4,5),(5,6),(6,1)])),
       ("loop-away-from-spot-1", fb(7,[(1,2),(5,6),(6,7),(3,4),(7,5),(2,3)])),
       ("more-roads-after-loop", fb(5,[(1,2),(2,3),(1,3),(3,4),(4,5),(1,5),(2,4)])),
       ("isolated-spots-exist", fb(8,[(2,5),(5,7),(7,2)])),
       ("every-new-road-touches-old-ones", fb(6,[(1,2),(3,4),(5,6),(1,3),(4,5),(2,6),(1,6)]))]
    n=300
    T.append(("spanning-tree-no-loop", fb(n, rtree(range(1,n+1)))))
    t=rtree(range(1,n+1)); a,b=rng.sample(range(1,n+1),2)
    while (a,b) in t or (b,a) in t: a,b=rng.sample(range(1,n+1),2)
    T.append(("spanning-tree-then-extra", fb(n, t+[(a,b)])))
    p=list(range(1,n+1)); rng.shuffle(p); path=[(p[i],p[i+1]) for i in range(n-1)]; rng.shuffle(path)
    T.append(("shuffled-long-path-then-close", fb(n, path+[(p[-1],p[0])])))
    h1=rtree(range(1,151)); h2=rtree(range(151,301)); E=h1+h2; rng.shuffle(E)
    T.append(("two-trees-bridge-then-loop", fb(n, E+[(7,200),(3,111) if (3,111) not in h1 and (111,3) not in h1 else (4,99)])))
    E=[(1,i) for i in range(2,n+1)]; rng.shuffle(E)
    extra=[]
    while len(extra)<700:
        a,b=rng.sample(range(2,n+1),2); extra.append((a,b))
    T.append(("star-then-many-roads", fb(n, E+extra)))
    groups=[list(range(i,min(i+10,n+1))) for i in range(1,n+1,10)]; E=[]
    for g in groups: E+=rtree(g)
    rng.shuffle(E)
    T.append(("many-small-trees-no-loop", fb(n, E)))
    t=rtree(range(1,n+1)); rng.shuffle(t); k=rng.randint(150,250); pre=t[:k]
    # find a pair already connected within prefix forest to close first loop
    par=list(range(n+1))
    def f(x):
        while par[x]!=x: x=par[x]
        return x
    for a,b in pre: par[f(a)]=f(b)
    while True:
        a,b=rng.sample(range(1,n+1),2)
        if f(a)==f(b) and (a,b) not in pre and (b,a) not in pre: break
    rest=[]
    while len(rest)<700:
        x,y=rng.sample(range(1,n+1),2); rest.append((x,y))
    T.append(("loop-midway-then-noise", fb(n, pre+[(a,b)]+rest)))
    E=[tuple(rng.sample(range(1,n+1),2)) for _ in range(1000)]
    T.append(("random-roads", fb(n, E)))
    # loop only when last possible tree edge closes it: caterpillar merges
    p=list(range(1,n+1)); rng.shuffle(p); E=[]
    for i in range(0,n-1,2): E.append((p[i],p[i+1]))
    for i in range(1,n-2,2): E.append((p[i],p[i+1]))
    E.append((p[-1],p[0]))
    T.append(("pairs-then-links-then-close", fb(n, E)))
    emit("B",S,T)

# ---------------- C: Fest Food Trail ----------------
def fc(n, taste, E, shuffle=True):
    E=uniq_pairs([(min(a,b),max(a,b)) for a,b in E if a!=b])
    if shuffle: rng.shuffle(E)
    return f"{n} {len(E)}\n" + " ".join(map(str,taste)) + "\n" + "".join(f"{a} {b}\n" for a,b in E)
def gen_C():
    S=[("sample1", fc(5,[3,2,10,1,4],[(2,3),(1,2),(3,5),(1,3),(2,4)],False)),
       ("sample2", fc(5,[5,1,100,2,3],[(1,2),(2,4),(3,4),(3,5)],False))]
    T=[("single-stall", fc(1,[7],[])), ("two-stalls-no-path", fc(2,[4,9],[])), ("two-stalls-path", fc(2,[4,9],[(1,2)])),
       ("greedy-trap", fc(6,[1,50,2,1,1,100],[(1,2),(1,3),(2,4),(3,5),(5,6)])),
       ("unreachable-feeds-reachable", fc(5,[1,1000,1,1,1],[(2,3),(1,3),(3,4),(2,5)])),
       ("best-ends-before-last-stall", fc(4,[1,1,50,1],[(1,3),(1,2),(2,4)])),
       ("last-stall-unreachable", fc(5,[2,3,4,5,99],[(1,2),(2,3),(3,4)])),
       ("stall-1-has-no-paths", fc(5,[3,100,100,100,100],[(2,3),(3,4),(4,5)])),
       ("equal-routes", fc(4,[1,5,5,1],[(1,2),(1,3),(2,4),(3,4)])),
       ("long-way-beats-shortcut", fc(6,[1,2,2,2,2,1],[(1,6),(1,2),(2,3),(3,4),(4,5),(5,6)]))]
    for t in range(6):
        n=rng.randint(3,10); taste=[rng.randint(1,20) for _ in range(n)]
        E=[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(rng.randint(0,n*2))]
        T.append((f"random-small-{t+1}", fc(n,taste,E)))
    n=500; M=10**6
    E=[(i,i+1) for i in range(1,n)]
    while len(E)<5000: E.append(tuple(sorted(rng.sample(range(1,n+1),2))))
    T.append(("chain-plus-random-paths", fc(n,[rng.randint(1,M) for _ in range(n)],E)))
    E=[(i,i+1) for i in range(1,n)]; E.sort(reverse=True)
    T.append(("chain-listed-bottom-up", fc(n,[rng.randint(1,M) for _ in range(n)],E,shuffle=False)))
    R=[1]+sorted(rng.sample(range(2,n+1),249)); Rs=set(R); E=[]
    for i in range(1,len(R)): E.append((R[rng.randrange(i)],R[i]))
    U=[x for x in range(2,n+1) if x not in Rs]
    while len(E)<4000:
        a,b=sorted(rng.sample(U,2)); E.append((a,b))
    while len(E)<5000:
        a=rng.choice(U); b=rng.choice(R)
        if a<b: E.append((a,b))
    taste=[M if (i+1) not in Rs else rng.randint(1,100) for i in range(n)]
    T.append(("rich-stalls-unreachable", fc(n,taste,E)))
    T.append(("max-n-no-paths", fc(n,[rng.randint(1,M) for _ in range(n)],[])))
    E=[tuple(sorted(rng.sample(range(1,n+1),2))) for _ in range(700)]
    T.append(("random-sparse", fc(n,[rng.randint(1,M) for _ in range(n)],E)))
    taste=[rng.randint(1,10) for _ in range(n)]
    for i in range(240,260): taste[i]=M
    E=[(i,i+1) for i in range(1,n)]
    while len(E)<3000:
        a,b=sorted(rng.sample(range(1,n+1),2))
        if not (a<=260<b): E.append((a,b))
    E=[e for e in E if not (e[0]<=260 and e[1]>260)]+[(250,300),(255,400)]
    T.append(("best-trail-ends-mid-hill", fc(n,taste,E)))
    # greedy trap large: from each stall, a tasty dead-end vs a modest long road
    taste=[]; E=[]
    for i in range(1,n+1): taste.append(5)
    for i in range(1,n-1,2):
        E.append((i,i+2)); E.append((i,i+1)); taste[i]=1000   # stall i+1 is a tasty dead end
    T.append(("greedy-trap-large", fc(n,taste,E)))
    T.append(("all-max-taste-chain", fc(n,[M]*n,[(i,i+1) for i in range(1,n)])))
    E=[]
    while len(E)<5000: E.append(tuple(sorted(rng.sample(range(1,101),2))))
    E=uniq_pairs(E)[:4000]+[(rng.randint(1,100),b) for b in range(101,n+1)]
    T.append(("dense-top-of-hill", fc(n,[rng.randint(1,M) for _ in range(n)],E)))
    T.append(("stall-1-to-everyone", fc(n,[rng.randint(1,M) for _ in range(n)],[(1,b) for b in range(2,n+1)])))
    E=[]
    for L in range(0,n,50):
        lay=range(L+1,min(L+51,n+1))
        for a in lay:
            for b in rng.sample(range(L+51,min(L+101,n+1)),min(8,max(0,min(L+101,n+1)-(L+51)))): E.append((a,b))
    T.append(("layered-hillside", fc(n,[rng.randint(1,M) for _ in range(n)],E[:5000])))
    emit("C",S,T)

# ---------------- D: Lunch Bell ----------------
def fd(n, c, E, studs, shuffle=True):
    seen=set(); F=[]
    for u,v,t in E:
        if u!=v and (u,v) not in seen: seen.add((u,v)); F.append((u,v,t))
    if shuffle: rng.shuffle(F)
    return f"{n} {len(F)} {c} {len(studs)}\n" + "".join(f"{u} {v} {t}\n" for u,v,t in F) + " ".join(map(str,studs)) + "\n"
def in_tree(n, c, wmax):
    nodes=[x for x in range(1,n+1) if x!=c]; rng.shuffle(nodes); order=[c]+nodes; E=[]
    for i in range(1,n): E.append((order[i], order[rng.randrange(i)], rng.randint(1,wmax)))
    return E
def gen_D():
    S=[("sample1", fd(5,5,[(1,2,3),(2,5,4),(1,5,10),(3,1,2),(4,3,1),(5,4,1)],[1,3,4],False)),
       ("sample2", fd(3,2,[(1,2,5),(3,1,1),(3,2,7)],[2,3,3],False))]
    T=[("two-spots", fd(2,2,[(1,2,7)],[1])),
       ("everyone-already-there", fd(2,2,[(2,1,5)],[2,2,2])),
       ("canteen-corridors-lead-away", fd(4,1,[(1,2,1),(1,3,1),(1,4,1),(4,1,50),(2,4,3),(3,2,4)],[2,3,4])),
       ("more-corridors-but-faster", fd(5,5,[(1,5,100),(1,2,10),(2,3,10),(3,4,10),(4,5,10)],[1])),
       ("fewer-corridors-slower", fd(5,5,[(1,4,90),(4,5,5),(1,2,5),(2,3,5),(3,5,5)],[1,4])),
       ("max-not-sum", fd(4,4,[(1,4,6),(2,4,6),(3,4,6)],[1,2,3])),
       ("students-share-spots", fd(4,3,[(1,2,2),(2,3,2),(4,3,9),(4,1,1)],[1,1,4,4,2])),
       ("two-way-pair-and-one-way", fd(4,4,[(1,2,3),(2,1,3),(2,4,8),(4,3,1),(3,1,1)],[1,3])),
       ("student-at-canteen-and-far", fd(6,3,[(1,2,4),(2,3,4),(3,6,1),(6,5,1),(5,4,1),(4,1,1)],[3,4,5,6]))]
    for t in range(6):
        n=rng.randint(3,9); c=rng.randint(1,n); E=in_tree(n,c,20)
        for _ in range(rng.randint(0,2*n)):
            u,v=rng.sample(range(1,n+1),2); E.append((u,v,rng.randint(1,20)))
        T.append((f"random-small-{t+1}", fd(n,c,E,[rng.randint(1,n) for _ in range(rng.randint(1,6))])))
    n=10**4
    E=[(i,i+1,rng.randint(1,1000)) for i in range(1,n)]
    T.append(("long-road-to-canteen", fd(n,n,E,list(range(1,n)))))
    c=rng.randint(1,n); E=in_tree(n,c,1000)
    while len(E)<5*10**4:
        u,v=rng.sample(range(1,n+1),2); E.append((u,v,rng.randint(1,1000)))
    T.append(("random-campus", fd(n,c,E,rng.sample(range(1,n+1),10**4))))
    c=rng.randint(1,n); E=in_tree(n,c,1000)
    while len(E)<3*10**4:
        u,v=rng.sample(range(1,n+1),2); E.append((u,v,rng.randint(1,1000)))
    for v in [x for x in range(1,n+1) if x!=c]:
        E.append((c,v,1))
    T.append(("canteen-exits-are-shortcuts", fd(n,c,E[:5*10**4],rng.sample(range(1,n+1),5000))))
    R=C=100; idx=lambda i,j:i*C+j+1; E=[]
    for i in range(R):
        for j in range(C-1):
            E.append((idx(i,j),idx(i,j+1),rng.randint(1,50)) if i%2==0 else (idx(i,j+1),idx(i,j),rng.randint(1,50)))
    for j in range(C):
        for i in range(R-1):
            E.append((idx(i,j),idx(i+1,j),rng.randint(1,50)) if j%2==0 else (idx(i+1,j),idx(i,j),rng.randint(1,50)))
    cg=idx(50,51); rg=[[] for _ in range(n+1)]
    for u,v,t in E: rg[v].append(u)
    ok={cg}; q=[cg]
    while q:
        u=q.pop()
        for w in rg[u]:
            if w not in ok: ok.add(w); q.append(w)
    okl=sorted(ok)
    T.append(("one-way-street-grid", fd(n,cg,E,[rng.choice(okl) for _ in range(10**4)])))
    c=rng.randint(1,n); E=in_tree(n,c,1000)
    while len(E)<5*10**4:
        u,v=rng.sample(range(1,n+1),2); E.append((u,v,rng.randint(1,1000)))
    s=rng.choice([x for x in range(1,n+1) if x!=c])
    T.append(("all-students-one-spot", fd(n,c,E,[s]*10**4)))
    # hop-count trap: direct-ish heavy corridors vs light long routes
    c=1; E=[(v,v-1,1) for v in range(2,n+1)] + [(v,c,1000) for v in range(3,n+1)]
    T.append(("heavy-shortcuts-light-long-way", fd(n,c,E,list(range(2,1000))+[rng.randint(2,999) for _ in range(5000)])))
    E=[(i+1,i,1000) for i in range(1,n)]
    for _ in range(4*10**4):
        u,v=sorted(rng.sample(range(1,n+1),2)); E.append((v,u,1000))
    T.append(("max-weights-deep-canteen", fd(n,1,E,[n]*5000+rng.sample(range(1,n+1),5000))))
    c=n//2; E=[]
    for v in range(1,n+1):
        if v!=c: E.append((v,c,1000))
    while len(E)<5*10**4:
        u,v=rng.sample(range(1,n+1),2); E.append((u,v,rng.randint(1,300)))
    T.append(("direct-corridor-from-everywhere", fd(n,c,E,rng.sample(range(1,n+1),10**4))))
    c=rng.randint(1,n); E=in_tree(n,c,5)
    while len(E)<2*10**4:
        u,v=rng.sample(range(1,n+1),2); E.append((u,v,rng.randint(1,5)))
    T.append(("small-times-sparse", fd(n,c,E,rng.sample(range(1,n+1),8000))))
    emit("D",S,T)

shutil.rmtree(OUT, ignore_errors=True)
gen_A(); gen_B(); gen_C(); gen_D(); print("generated")
