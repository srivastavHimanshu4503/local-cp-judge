import sys
d=sys.stdin.read().split(); n,m,s=int(d[0]),int(d[1]),int(d[2]); E=[(int(d[3+2*i]),int(d[4+2*i])) for i in range(m)]
seen={s}; ch=True
while ch:
    ch=False
    for a,b in E:
        if b in seen and a not in seen: seen.add(a); ch=True
print(len(seen)-1)
