# a graph has a cycle iff edges > n - components; find first prefix where that happens
import sys
d=sys.stdin.read().split(); n,m=int(d[0]),int(d[1]); E=[(int(d[2+2*i]),int(d[3+2*i])) for i in range(m)]
def comps(k):
    g=[[] for _ in range(n+1)]
    for a,b in E[:k]: g[a].append(b); g[b].append(a)
    s=[0]*(n+1); c=0
    for i in range(1,n+1):
        if not s[i]:
            c+=1; st=[i]; s[i]=1
            while st:
                u=st.pop()
                for v in g[u]:
                    if not s[v]: s[v]=1; st.append(v)
    return c
for k in range(1,m+1):
    if k > n-comps(k): print(k); break
else: print(-1)
