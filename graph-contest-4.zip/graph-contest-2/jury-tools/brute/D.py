import sys
d=sys.stdin.read().split(); n,m,c,k=int(d[0]),int(d[1]),int(d[2]),int(d[3]); I=10**18
D=[[I]*(n+1) for _ in range(n+1)]
for i in range(n+1): D[i][i]=0
for i in range(m):
    u,v,t=int(d[4+3*i]),int(d[5+3*i]),int(d[6+3*i]); D[u][v]=min(D[u][v],t)
for w in range(1,n+1):
    for i in range(1,n+1):
        if D[i][w]==I: continue
        for j in range(1,n+1):
            if D[i][w]+D[w][j]<D[i][j]: D[i][j]=D[i][w]+D[w][j]
print(max(D[int(s)][c] for s in d[4+3*m:4+3*m+k]))
