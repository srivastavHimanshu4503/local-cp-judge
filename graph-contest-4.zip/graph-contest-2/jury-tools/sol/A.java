import java.util.*; import java.io.*;
public class A { public static void main(String[] x) throws IOException {
  StreamTokenizer st=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
  st.nextToken(); int n=(int)st.nval; st.nextToken(); int m=(int)st.nval; st.nextToken(); int s=(int)st.nval;
  List<List<Integer>> g=new ArrayList<>(); for(int i=0;i<=n;i++) g.add(new ArrayList<>());
  for(int i=0;i<m;i++){st.nextToken();int a=(int)st.nval;st.nextToken();int b=(int)st.nval;g.get(b).add(a);}
  boolean[] seen=new boolean[n+1]; seen[s]=true; ArrayDeque<Integer> q=new ArrayDeque<>(); q.add(s); int cnt=0;
  while(!q.isEmpty()){int u=q.poll(); for(int v:g.get(u)) if(!seen[v]){seen[v]=true;cnt++;q.add(v);}}
  System.out.println(cnt);
}}
