import sys
d = sys.stdin.buffer.read().split()
n, m = int(d[0]), int(d[1]); p = list(range(n + 1))
def f(x):
    while p[x] != x: p[x] = p[p[x]]; x = p[x]
    return x
for i in range(m):
    a, b = f(int(d[2 + 2*i])), f(int(d[3 + 2*i]))
    if a == b: print(i + 1); sys.exit()
    p[a] = b
print(-1)
