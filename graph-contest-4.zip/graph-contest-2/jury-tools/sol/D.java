import java.util.*; import java.io.*;
public class D { public static void main(String[] x) throws IOException {
  StreamTokenizer st=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
  st.nextToken(); int n=(int)st.nval; st.nextToken(); int m=(int)st.nval; st.nextToken(); int c=(int)st.nval; st.nextToken(); int k=(int)st.nval;
  List<List<int[]>> rg=new ArrayList<>(); for(int i=0;i<=n;i++) rg.add(new ArrayList<>());
  for(int i=0;i<m;i++){st.nextToken();int u=(int)st.nval;st.nextToken();int v=(int)st.nval;st.nextToken();int t=(int)st.nval;rg.get(v).add(new int[]{u,t});}
  int[] dist=new int[n+1]; Arrays.fill(dist,Integer.MAX_VALUE); dist[c]=0;
  PriorityQueue<int[]> pq=new PriorityQueue<>((a,b)->Integer.compare(a[0],b[0])); pq.add(new int[]{0,c});
  while(!pq.isEmpty()){int[] e=pq.poll(); int du=e[0],u=e[1]; if(du>dist[u]) continue;
    for(int[] w:rg.get(u)) if(du+w[1]<dist[w[0]]){dist[w[0]]=du+w[1]; pq.add(new int[]{dist[w[0]],w[0]});}}
  int ans=0; for(int i=0;i<k;i++){st.nextToken(); ans=Math.max(ans,dist[(int)st.nval]);}
  System.out.println(ans);
}}
