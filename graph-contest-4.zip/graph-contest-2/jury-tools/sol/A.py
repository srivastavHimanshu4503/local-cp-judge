import sys
from collections import deque
d = sys.stdin.buffer.read().split()
n, m, s = int(d[0]), int(d[1]), int(d[2])
g = [[] for _ in range(n + 1)]
for i in range(m):
    a, b = int(d[3 + 2*i]), int(d[4 + 2*i])
    g[b].append(a)                      # story flows from b to its follower a
seen = [False] * (n + 1); seen[s] = True; q = deque([s]); cnt = 0
while q:
    u = q.popleft()
    for v in g[u]:
        if not seen[v]: seen[v] = True; cnt += 1; q.append(v)
print(cnt)
