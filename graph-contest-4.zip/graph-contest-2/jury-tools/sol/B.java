import java.util.*; import java.io.*;
public class B { static int[] p; static int f(int x){while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x;}
 public static void main(String[] x) throws IOException {
  StreamTokenizer st=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
  st.nextToken(); int n=(int)st.nval; st.nextToken(); int m=(int)st.nval; p=new int[n+1]; for(int i=0;i<=n;i++) p[i]=i;
  for(int i=0;i<m;i++){st.nextToken();int a=f((int)st.nval);st.nextToken();int b=f((int)st.nval);
    if(a==b){System.out.println(i+1);return;} p[a]=b;}
  System.out.println(-1);
}}
