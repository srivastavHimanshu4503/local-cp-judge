import sys
d = sys.stdin.buffer.read().split()
n, m = int(d[0]), int(d[1]); taste = [0] + [int(x) for x in d[2:2 + n]]
out = [[] for _ in range(n + 1)]
for i in range(m):
    a, b = int(d[2 + n + 2*i]), int(d[3 + n + 2*i]); out[a].append(b)
NEG = -1; best = [NEG] * (n + 1); best[1] = taste[1]
for a in range(1, n + 1):
    if best[a] == NEG: continue
    for b in out[a]:
        if best[a] + taste[b] > best[b]: best[b] = best[a] + taste[b]
print(max(best))
