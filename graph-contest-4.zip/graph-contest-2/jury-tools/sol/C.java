import java.util.*; import java.io.*;
public class C { public static void main(String[] x) throws IOException {
  StreamTokenizer st=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
  st.nextToken(); int n=(int)st.nval; st.nextToken(); int m=(int)st.nval; int[] taste=new int[n+1];
  for(int i=1;i<=n;i++){st.nextToken(); taste[i]=(int)st.nval;}
  List<List<Integer>> out=new ArrayList<>(); for(int i=0;i<=n;i++) out.add(new ArrayList<>());
  for(int i=0;i<m;i++){st.nextToken();int a=(int)st.nval;st.nextToken();int b=(int)st.nval;out.get(a).add(b);}
  int[] best=new int[n+1]; Arrays.fill(best,-1); best[1]=taste[1]; int ans=0;
  for(int a=1;a<=n;a++){ if(best[a]<0) continue; ans=Math.max(ans,best[a]);
    for(int b:out.get(a)) best[b]=Math.max(best[b],best[a]+taste[b]); }
  System.out.println(ans);
}}
