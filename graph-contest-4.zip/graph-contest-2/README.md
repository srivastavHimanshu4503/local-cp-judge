# Graph Contest 2: DOMjudge packages

Import each problem zip separately (Jury > Problems > Import). Every package contains:

- `problem.html`: the statement (DOMjudge shows it as the problem text)
- `problem.yaml` and `domjudge-problem.ini`: name and a 2-second time limit
- `data/sample` and `data/secret`: test data (`.in` / `.ans`)
- `submissions/accepted`: Python and Java reference solutions that read stdin directly; DOMjudge judges them on import as a self-check (delete the folder if you don't want jury submissions)

`statements/` has the same four HTML statements for previewing or sharing.

| Package | Problem | Samples | Secret |
|---|---|---|---|
| A-story-reshares.zip | Story Reshares | 2 | 21 |
| B-loop-alert.zip | Loop Alert | 2 | 21 |
| C-fest-food-trail.zip | Fest Food Trail | 2 | 27 |
| D-lunch-bell.zip | Lunch Bell | 2 | 24 |

## Input format of the test files (for your harness)

All numbers are separated by single spaces or newlines. Every answer file is a single integer.

**A. Story Reshares**: `count_viewers(n, s, follows)`
```
n m s
a1 b1          (m lines, one follows pair each)
```

**B. Loop Alert**: `first_loop(n, roads)`
```
n m
a1 b1          (m lines, in build order; m may be 0)
```

**C. Fest Food Trail**: `best_trail(n, taste, paths)`
```
n m
taste1 taste2 ... tasten
a1 b1          (m lines; m may be 0)
```

**D. Lunch Bell**: `lunch_time(n, corridors, c, students)`
```
n m c k
u1 v1 t1       (m lines)
s1 s2 ... sk   (one line: the students' spots)
```

The statements show the function names above in Python (`count_viewers`) and Java (`countViewers`) style. If your templates use different names, edit the "What to implement" box in each `problem.html`.

## Verification performed

- Every input passes a strict validator (`jury-tools/gen/validate.py`) for the statement constraints, including the guarantees: no repeated pairs, `a < b` in C, and every student can reach the canteen in D.
- The Python reference's answers are matched exactly by an independent Java reference.
- Every small test is matched by brute force: fixed-point closure (A), edge/component counting per prefix (B), trying every trail (C), Floyd–Warshall (D).
- Each wrong approach in `jury-tools/wrong/` fails the secret data, and every one also fails a sample:
  - A: treating follows as two-way, reversing the direction, counting the poster, only counting direct followers.
  - B: "both ends already have roads", looking only for triangles, 0-based road numbers.
  - C: greedy tastiest-next, counting unreachable stalls, requiring the trail to end at stall n, processing paths in input order.
  - D: two-way corridors, Dijkstra from the canteen without reversing, sum instead of max, fewest corridors instead of fewest minutes.
- D's "one Dijkstra per student" approach times out: over 30 s in Python, and about 2.7 s, 4.7 s and 25 s in Java on three large tests. The reference takes about 0.1 s.

Regenerate everything with `python3 jury-tools/gen/generate.py` (fixed seed).
