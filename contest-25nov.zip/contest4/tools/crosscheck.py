"""Compare the .ans files with an independent checker on every test it can handle.

  python3 tools/crosscheck.py <problem-dir> [max_input_bytes]

generator/brute.py is called as:  brute.py <file.in> <file.ans>
It prints its own answer (compared with .ans), or exits with status 3 to skip a test it cannot handle,
or exits with status 4 after verifying the .ans file directly (for tests too large to solve by brute force).
"""
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
problem = ROOT / sys.argv[1]
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 20_000
solved = certified = skipped = 0
for t in sorted(problem.glob("data/*/*.in")):
    if t.stat().st_size > limit:
        skipped += 1
        continue
    ans = t.with_suffix(".ans")
    r = subprocess.run(["python3", str(problem / "generator/brute.py"), str(t), str(ans)], capture_output=True)
    if r.returncode == 3:
        skipped += 1
        continue
    if r.returncode == 4:
        certified += 1
        continue
    assert r.returncode == 0, f"checker crashed on {t}: {r.stderr.decode()[-400:]}"
    assert r.stdout.split() == ans.read_bytes().split(), f"MISMATCH on {t}"
    solved += 1
print(f"{problem.name}: independent checker agrees on {solved} tests solved by brute force"
      + (f", certified {certified} large answers" if certified else "")
      + (f", skipped {skipped}" if skipped else ""))
