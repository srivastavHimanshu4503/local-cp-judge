# Contest problem set

Four problems, A to D, ordered roughly from easiest to hardest.

## How it works

- For every problem you write **one function**, in Python or Java. The statement gives its exact name, parameters and return type.
- The code that reads the input and prints your answer is already provided. **Do not print anything yourself**: extra output makes your answer wrong.
- Each statement shows the exact input format and sample tests. To test your function, copy a sample input exactly as shown and paste it into the custom input box.
- Submissions are judged on hidden tests, including the largest inputs the constraints allow. The speed of your approach matters, not only its correctness.
- Each problem states its own time limit. Python solutions get three times the Java time limit.
