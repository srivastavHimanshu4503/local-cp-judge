"""Write the harness files (harness/harness.py, harness/Harness.java) of all four problems.

  python3 tools/make_harnesses.py
"""
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from harness_skeleton import write_harness  # noqa: E402

ROOT = pathlib.Path(__file__).resolve().parent.parent

write_harness(ROOT / "A-exam-halls", '''
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    sizes = [int(x) for x in data[2:2 + n]]
    capacities = [int(x) for x in data[2 + n:2 + n + m]]
    print(max_batches(sizes, capacities))
''', '''
int n = in.nextInt(), m = in.nextInt();
int[] sizes = new int[n];
for (int i = 0; i < n; i++) sizes[i] = in.nextInt();
int[] capacities = new int[m];
for (int j = 0; j < m; j++) capacities[j] = in.nextInt();
out.println(new Solution().maxBatches(sizes, capacities));
''')

write_harness(ROOT / "B-medical-certificates", '''
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    record = data[2].decode()
    print(longest_streak(record, k))
''', '''
int n = in.nextInt(), k = in.nextInt();
String record = in.next();
out.println(new Solution().longestStreak(record, k));
''')

write_harness(ROOT / "C-running-median", '''
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    values = [int(x) for x in data[1:1 + n]]
    print(" ".join(map(str, running_median(values))))
''', '''
int n = in.nextInt();
int[] values = new int[n];
for (int i = 0; i < n; i++) values[i] = in.nextInt();
int[] medians = new Solution().runningMedian(values);
StringBuilder sb = new StringBuilder();
for (int i = 0; i < medians.length; i++) {
    if (i > 0) sb.append(' ');
    sb.append(medians[i]);
}
out.println(sb);
''')

write_harness(ROOT / "D-damaged-board-queens", '''
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))
''', '''
int n = in.nextInt();
String[] board = new String[n];
for (int i = 0; i < n; i++) board[i] = in.next();
out.println(new Solution().countPlacements(board));
''')
print("harnesses written")
