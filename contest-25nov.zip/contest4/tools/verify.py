"""Verify a problem package: build .ans from the reference, then judge every jury submission.

  python3 tools/verify.py <problem-dir> [--make-ans] [--java-tl 2] [--py-factor 3] [--only substr]

* accepted/*            must pass every test within the time limit
* wrong_answer/*        must end with WRONG-ANSWER
* time_limit_exceeded/* must end with TIMELIMIT
Judging stops at the first failing test, like DOMjudge. Times are CPU seconds (user + sys).
Writes <problem-dir>/verification-report.txt.
"""
import argparse
import pathlib
import resource
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
BUILD = pathlib.Path("/home/claude/jbuild")
EXPECT = {"accepted": "CORRECT", "wrong_answer": "WRONG-ANSWER",
          "time_limit_exceeded": "TIMELIMIT", "run_time_error": "RUN-ERROR"}


def cpu_children() -> float:
    r = resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime + r.ru_stime


def compile_java(src: pathlib.Path) -> list:
    out = BUILD / src.parents[2].name / src.parent.name / src.stem
    out.mkdir(parents=True, exist_ok=True)
    subprocess.run(["javac", "-encoding", "UTF-8", "-d", str(out), str(src)],
                   check=True, stderr=subprocess.DEVNULL)
    return ["java", "-Xmx2048m", "-cp", str(out), "Main"]


def run(cmd, infile, kill_after):
    before = cpu_children()
    with open(infile, "rb") as f:
        p = subprocess.Popen(cmd, stdin=f, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = p.communicate(timeout=kill_after)
            killed = False
        except subprocess.TimeoutExpired:
            p.kill()
            out, err = p.communicate()
            killed = True
    return p.returncode, cpu_children() - before, out, err, killed


def tests(problem):
    return sorted((problem / "data/sample").glob("*.in")) + sorted((problem / "data/secret").glob("*.in"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("problem")
    ap.add_argument("--make-ans", action="store_true")
    ap.add_argument("--java-tl", type=float, default=2.0)
    ap.add_argument("--py-factor", type=float, default=3.0)
    ap.add_argument("--only", default=None)
    a = ap.parse_args()
    problem = (ROOT / a.problem).resolve()
    tl = {".java": a.java_tl, ".py": a.java_tl * a.py_factor}
    T = tests(problem)

    if a.make_ans:
        ref = problem / "submissions/accepted/ref.py"
        for t in T:
            rc, used, out, err, killed = run(["python3", str(ref)], t, 120)
            assert rc == 0 and not killed, (t, err.decode()[-800:])
            t.with_suffix(".ans").write_bytes(out)
        print(f"wrote {len(T)} .ans files from {ref.name}")

    lines = [f"Verification report for {problem.name}",
             f"Time limit: Java {tl['.java']:g}s, Python {tl['.py']:g}s (CPU). Tests: {len(T)}", ""]
    ok_all = True
    for sub in sorted((problem / "submissions").rglob("*")):
        if sub.suffix not in tl or (a.only and a.only not in str(sub)):
            continue
        expected = sub.parent.name
        cmd = compile_java(sub) if sub.suffix == ".java" else ["python3", str(sub)]
        limit = tl[sub.suffix]
        verdict, where, worst = "CORRECT", "", 0.0
        for t in T:
            rc, used, out, err, killed = run(cmd, t, kill_after=limit * 1.5 + 1.0)
            worst = max(worst, used)
            if killed or used > limit:
                verdict, where = "TIMELIMIT", t.stem
                break
            if rc != 0:
                verdict, where = "RUN-ERROR", t.stem
                break
            if out.split() != t.with_suffix(".ans").read_bytes().split():
                verdict, where = "WRONG-ANSWER", t.stem
                break
        good = verdict == EXPECT[expected]
        ok_all &= good
        detail = f"max CPU {worst:.2f}s" if verdict == "CORRECT" else f"first failure on {where}"
        lines.append(f"{'OK ' if good else 'BAD'} {expected + '/' + sub.name:<46} -> {verdict:<13} {detail}")
        print(lines[-1], flush=True)
    lines += ["", "ALL AS EXPECTED" if ok_all else "MISMATCHES FOUND"]
    (problem / "verification-report.txt").write_text("\n".join(lines) + "\n")
    print(lines[-1])
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
