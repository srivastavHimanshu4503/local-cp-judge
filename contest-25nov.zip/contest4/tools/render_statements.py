"""Render statement/problem.md -> statement/problem.html for every problem (DOMjudge-ready), plus copies
in statements/ and one combined booklet.

  python3 tools/render_statements.py

Each problem.html is a single self-contained page: inline CSS, no scripts, no external fonts or images,
and pure ASCII (every non-ASCII character is written as an HTML entity), because DOMjudge serves the
statement as text/html without declaring a character set. Needs pandoc.
"""
import pathlib
import re
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent.parent
CSS = (ROOT / "tools/statement/style.css").read_text()
PROBLEMS = sorted(p for p in ROOT.glob("[A-D]-*") if (p / "statement/problem.md").exists())


def md_to_fragment(md_path: pathlib.Path) -> str:
    html = subprocess.run(["pandoc", str(md_path), "-f", "markdown", "-t", "html5", "--no-highlight"],
                          capture_output=True, text=True, check=True).stdout
    # "<h1 ...>A. Factory Machines</h1>"  ->  large accent letter + title
    html = re.sub(r"(<h1[^>]*>)([A-D])\. ", r'\1<span class="letter">\2</span>', html, count=1)
    # keep each section (heading + content) together when printed
    chunks = re.split(r"(?=<h2)", html)
    return "".join(f'<section class="keep">{c}</section>' if c.startswith("<h2") else c for c in chunks)


def page(title: str, body: str) -> str:
    html = (f'<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
            f'<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            f"<title>{title}</title>\n<style>\n{CSS}</style>\n</head>\n<body>\n<main>\n{body}\n</main>\n</body>\n</html>\n")
    return html.encode("ascii", "xmlcharrefreplace").decode("ascii")


out = ROOT / "statements"
if out.exists():
    shutil.rmtree(out)
out.mkdir()
parts = [md_to_fragment(ROOT / "tools/statement/cover.md")]
for p in PROBLEMS:
    frag = md_to_fragment(p / "statement/problem.md")
    title = re.search(r"^# (.*)$", (p / "statement/problem.md").read_text(), re.M).group(1)
    html = page(title, frag)
    (p / "statement/problem.html").write_text(html)
    (out / f"{p.name}.html").write_text(html)
    parts.append(frag)
    print("rendered", p.name)

(out / "contest-problems.html").write_text(page("Contest problem set", '\n<div class="page-break"></div>\n'.join(parts)))
print("rendered booklet")
