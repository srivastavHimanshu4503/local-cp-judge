"""Assemble full programs from harness + function-only snippets.

For each problem directory:
  harness/harness.py, harness/Harness.java   the I/O code, with a {{STUDENT_CODE}} marker line
  stub/stub.py, stub/Stub.java               what students start from
  solutions/<verdict>/<name>.(py|java)       function-only jury solutions
produces:
  template/solution.py, template/Main.java   harness + stub      (what students see / download)
  submissions/<verdict>/<name>.(py|java)     harness + solution  (DOMjudge jury submissions)

Usage: python3 tools/build.py [problem-dir ...]
"""
import pathlib
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
MARK = {".py": "# {{STUDENT_CODE}}", ".java": "// {{STUDENT_CODE}}"}


def assemble(harness_text: str, snippet: str, ext: str) -> str:
    marker = MARK[ext]
    assert harness_text.count(marker) == 1, "harness must contain the marker exactly once"
    return harness_text.replace(marker, snippet.rstrip() + "\n")


def build(problem: pathlib.Path) -> None:
    harness = {
        ".py": (problem / "harness/harness.py").read_text(),
        ".java": (problem / "harness/Harness.java").read_text(),
    }
    tdir = problem / "template"
    tdir.mkdir(exist_ok=True)
    (tdir / "solution.py").write_text(assemble(harness[".py"], (problem / "stub/stub.py").read_text(), ".py"))
    (tdir / "Main.java").write_text(assemble(harness[".java"], (problem / "stub/Stub.java").read_text(), ".java"))

    out = problem / "submissions"
    if out.exists():
        shutil.rmtree(out)
    for src in sorted((problem / "solutions").rglob("*")):
        if src.suffix not in MARK:
            continue
        dst = out / src.relative_to(problem / "solutions")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(assemble(harness[src.suffix], src.read_text(), src.suffix))


if __name__ == "__main__":
    names = sys.argv[1:] or sorted(p.name for p in ROOT.iterdir() if (p / "harness").is_dir())
    for name in names:
        build(ROOT / name)
        print("built", name)
