"""Screenshot rendered HTML statements with headless Chromium, for visual review.

  python3 tools/screenshot.py out_dir file.html [file.html ...] [--width 900]
"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

args = sys.argv[1:]
width = 900
if "--width" in args:
    i = args.index("--width")
    width = int(args[i + 1])
    del args[i:i + 2]
out_dir = pathlib.Path(args[0])
out_dir.mkdir(parents=True, exist_ok=True)
with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": width, "height": 800})
    for f in args[1:]:
        path = pathlib.Path(f).resolve()
        page.goto(path.as_uri())
        shot = out_dir / f"{path.parent.parent.name if path.name == 'problem.html' else path.stem}-{width}.png"
        page.screenshot(path=str(shot), full_page=True)
        print(shot)
    browser.close()
