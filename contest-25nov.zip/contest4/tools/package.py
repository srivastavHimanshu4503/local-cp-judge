"""Build DOMjudge problem zips and per-problem TESTS.md catalogs.

  python3 tools/package.py
Output: dist/domjudge/<problem>.zip (import these into DOMjudge) and <problem>/TESTS.md

The HTML statement goes in twice: problem_statement/problem.html (where current DOMjudge looks first)
and problem.html at the zip root (where older DOMjudge versions look). No PDF is included, because
DOMjudge would prefer a PDF over the HTML.
"""
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
DIST = ROOT / "dist/domjudge"
DIST.mkdir(parents=True, exist_ok=True)


def short(ans: pathlib.Path) -> str:
    vals = ans.read_text().split()
    if len(vals) == 1:
        return vals[0] if len(vals[0]) <= 40 else f"{vals[0][:30]}... ({len(vals[0])} chars)"
    head = " ".join(vals[:4])
    return f"{len(vals)} numbers: {head}{' ...' if len(vals) > 4 else ''}"


for p in sorted(ROOT.glob("[A-D]-*")):
    rows = ["| Test | What it checks | Expected output |", "|---|---|---|"]
    for kind in ("sample", "secret"):
        for t in sorted((p / "data" / kind).glob("*.in")):
            desc = t.with_suffix(".desc").read_text().strip()
            rows.append(f"| `{kind}/{t.stem}` | {desc} | `{short(t.with_suffix('.ans'))}` |")
    title = (p / "problem.yaml").read_text().splitlines()[0].split(": ", 1)[1]
    (p / "TESTS.md").write_text(f"# Tests for {p.name[0]}. {title}\n\n" + "\n".join(rows) + "\n")

    out = DIST / f"{p.name}.zip"
    statement = p / "statement/problem.html"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in ("problem.yaml", "domjudge-problem.ini"):
            z.write(p / f, f)
        z.write(statement, "problem_statement/problem.html")
        z.write(statement, "problem.html")
        for f in sorted((p / "data").rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(p).as_posix())
        for f in sorted((p / "submissions").rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(p).as_posix())
    print(f"{out.name}: {out.stat().st_size / 1e6:.1f} MB")
