"""Write a problem's harness files from one shared skeleton.

  from harness_skeleton import write_harness
  write_harness(problem_dir, py_main_body, java_run_body, java_extra_reader_methods="")

py_main_body:   the body of _main() (reads sys.stdin, calls the student's function, prints)
java_run_body:  the body of Main.run() (uses FastReader `in`, calls new Solution()..., prints via `out`)
"""
import pathlib
import textwrap

PY = '''from __future__ import annotations

import sys
import threading

# {{STUDENT_CODE}}


# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
__BODY__


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
'''

JAVA = '''import java.io.*;
import java.util.*;

// {{STUDENT_CODE}}


// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
__BODY__
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }

    String next() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = read(); }
        return sb.toString();
    }
}
'''


def write_harness(problem_dir, py_body: str, java_body: str) -> None:
    d = pathlib.Path(problem_dir) / "harness"
    d.mkdir(parents=True, exist_ok=True)
    py_body = textwrap.indent(textwrap.dedent(py_body).strip("\n"), "    ") + "\n"
    java_body = textwrap.indent(textwrap.dedent(java_body).strip("\n"), " " * 8)
    (d / "harness.py").write_text(PY.replace("__BODY__\n", py_body))
    (d / "Harness.java").write_text(JAVA.replace("__BODY__", java_body))
