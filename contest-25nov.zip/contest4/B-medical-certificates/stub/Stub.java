// ======================== WRITE YOUR CODE HERE ========================
class Solution {
    public int longestStreak(String record, int k) {
        // record: n characters; record.charAt(i) is 'P' (present) or 'A' (absent) on day i
        // k:      the number of medical certificates; each one excuses a single 'A'
        // return: the length of the longest run of consecutive days with no unexcused absence
        return 0;
    }
}
