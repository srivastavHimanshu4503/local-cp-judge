# ======================== WRITE YOUR CODE HERE ========================
def longest_streak(record: str, k: int) -> int:
    # record: n characters; record[i] is 'P' (present) or 'A' (absent) on day i
    # k:      the number of medical certificates; each one excuses a single 'A'
    # return: the length of the longest run of consecutive days with no unexcused absence
    return 0
