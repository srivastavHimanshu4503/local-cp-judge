# The window only ever grows or slides by one: when it holds too many absences, the left end moves
# exactly one step with the right end. Its length never drops below the best seen so far.
def longest_streak(record: str, k: int) -> int:
    left = absent = 0
    for day in record:
        if day == 'A':
            absent += 1
        if absent > k:
            if record[left] == 'A':
                absent -= 1
            left += 1
    return len(record) - left
