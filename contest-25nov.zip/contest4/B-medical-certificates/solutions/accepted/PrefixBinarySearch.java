// Prefix counts of absences; for each right end, binary-search the leftmost start that has at most
// k absences in between. O(n log n).
class Solution {
    public int longestStreak(String record, int k) {
        int n = record.length();
        int[] pre = new int[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + (record.charAt(i) == 'A' ? 1 : 0);
        int best = 0;
        for (int right = 1; right <= n; right++) {
            int lo = 0, hi = right;                  // smallest start with pre[right] - pre[start] <= k
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (pre[right] - pre[mid] <= k) hi = mid; else lo = mid + 1;
            }
            best = Math.max(best, right - lo);
        }
        return best;
    }
}
