# No window loop: list the positions of the absences. The best run excuses k consecutive absences,
# so it stretches from just after absence i-1 to just before absence i+k.
def longest_streak(record: str, k: int) -> int:
    pos = [-1] + [i for i, day in enumerate(record) if day == 'A'] + [len(record)]
    absences = len(pos) - 2
    if k >= absences:
        return len(record)
    return max(pos[i + k + 1] - pos[i] - 1 for i in range(absences - k + 1))
