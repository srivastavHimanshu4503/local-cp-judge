class Solution {
    public int longestStreak(String record, int k) {
        int best = 0, left = 0, absent = 0;
        for (int right = 0; right < record.length(); right++) {
            if (record.charAt(right) == 'A') absent++;
            while (absent > k) {
                if (record.charAt(left) == 'A') absent--;
                left++;
            }
            best = Math.max(best, right - left + 1);
        }
        return best;
    }
}
