// Correct window, but measures its length as right - left instead of right - left + 1.
class Solution {
    public int longestStreak(String record, int k) {
        int best = 0, left = 0, absent = 0;
        for (int right = 0; right < record.length(); right++) {
            if (record.charAt(right) == 'A') absent++;
            while (absent > k) {
                if (record.charAt(left) == 'A') absent--;
                left++;
            }
            best = Math.max(best, right - left);
        }
        return best;
    }
}
