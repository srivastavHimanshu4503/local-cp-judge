# Correct window, but reports only the PRESENT days in it: excused days should count too.
def longest_streak(record: str, k: int) -> int:
    best = left = absent = 0
    for right, day in enumerate(record):
        if day == 'A':
            absent += 1
        while absent > k:
            if record[left] == 'A':
                absent -= 1
            left += 1
        best = max(best, right - left + 1 - absent)
    return best
