# Uses the certificates on the FIRST k absences, then finds the longest run.
def longest_streak(record: str, k: int) -> int:
    days = list(record)
    for i, day in enumerate(days):
        if k == 0:
            break
        if day == 'A':
            days[i] = 'P'
            k -= 1
    return max(len(run) for run in "".join(days).split('A'))
