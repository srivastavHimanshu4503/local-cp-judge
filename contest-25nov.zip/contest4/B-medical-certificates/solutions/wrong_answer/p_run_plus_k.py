# Longest run of P's, plus k. Wrong: the excused absences may not sit next to that run.
def longest_streak(record: str, k: int) -> int:
    longest = max(len(run) for run in record.split('A'))
    return min(len(record), longest + k)
