# Tries every starting day and extends to the right until a (k+1)-th absence: O(n^2).
def longest_streak(record: str, k: int) -> int:
    n = len(record)
    best = 0
    for i in range(n):
        absent = 0
        j = i
        while j < n:
            if record[j] == 'A':
                absent += 1
                if absent > k:
                    break
            j += 1
        best = max(best, j - i)
    return best
