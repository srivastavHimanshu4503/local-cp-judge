// Tries every starting day and extends to the right until a (k+1)-th absence: O(n^2).
class Solution {
    public int longestStreak(String record, int k) {
        int n = record.length(), best = 0;
        for (int i = 0; i < n; i++) {
            int absent = 0, j = i;
            while (j < n) {
                if (record.charAt(j) == 'A' && ++absent > k) break;
                j++;
            }
            best = Math.max(best, j - i);
        }
        return best;
    }
}
