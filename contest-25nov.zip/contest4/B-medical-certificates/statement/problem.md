# B. Medical Certificates

*Time limit: 2 seconds for Java, 6 seconds for Python. Memory limit: 1024 MB.*

A student's attendance record covers *n* consecutive days. Each day is either `P` (present) or `A` (absent).

The student has *k* medical certificates. Each certificate **excuses one absence**, and each absence needs its own certificate.

A **run** is a block of consecutive days. Using at most *k* certificates, what is the length of the **longest run in which every absence is excused**? Excused days count towards the length of the run.

## What you write

You only write **one function**. The code that reads the input and prints the answer is already provided.

**Python**

```python
def longest_streak(record: str, k: int) -> int:
```

**Java**

```java
class Solution {
    public int longestStreak(String record, int k) { ... }
}
```

- `record` has *n* characters; character *i* is `P` or `A`.
- Return the length of the longest run in which every absence is excused. If no such run exists, which happens when every day is absent and *k* = 0, return 0.

## Input format

- The first line contains two integers *n* and *k*.
- The second line contains the record: a string of *n* characters, each `P` or `A`.

## Output format

One integer: the length of the longest run.

## Constraints

- 1 ≤ *n* ≤ 200 000
- 0 ≤ *k* ≤ *n*
- The record contains only the letters `P` and `A`.

## Sample 1

**Input**

```text
11 2
PAPPAPAAPPP
```

**Output**

```text
6
```

**Explanation.** Number the days from 1 to 11. The absences are on days 2, 5, 7 and 8.

- Excusing the absences on days 2 and 5 makes days 1 to 6 a run of 6 days.
- Excusing days 7 and 8 instead makes days 6 to 11 a run of 6 days.
- Every block of 7 consecutive days contains at least three absences, so no run of 7 is possible with two certificates.

## Sample 2

**Input**

```text
11 0
PAPPAPAAPPP
```

**Output**

```text
3
```

**Explanation.** With no certificates, the answer is the longest block of present days: days 9 to 11.

> **Testing your code:** copy a sample input exactly as shown above and paste it into the custom input box.
