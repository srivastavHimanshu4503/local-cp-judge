from __future__ import annotations

import sys
import threading

# The window only ever grows or slides by one: when it holds too many absences, the left end moves
# exactly one step with the right end. Its length never drops below the best seen so far.
def longest_streak(record: str, k: int) -> int:
    left = absent = 0
    for day in record:
        if day == 'A':
            absent += 1
        if absent > k:
            if record[left] == 'A':
                absent -= 1
            left += 1
    return len(record) - left



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    record = data[2].decode()
    print(longest_streak(record, k))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
