from __future__ import annotations

import sys
import threading

# Sliding window: grow on the right; while the window holds more than k absences, shrink on the left.
def longest_streak(record: str, k: int) -> int:
    best = left = absent = 0
    for right, day in enumerate(record):
        if day == 'A':
            absent += 1
        while absent > k:
            if record[left] == 'A':
                absent -= 1
            left += 1
        best = max(best, right - left + 1)
    return best



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    record = data[2].decode()
    print(longest_streak(record, k))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
