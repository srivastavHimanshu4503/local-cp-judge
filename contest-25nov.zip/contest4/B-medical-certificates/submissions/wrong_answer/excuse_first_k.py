from __future__ import annotations

import sys
import threading

# Uses the certificates on the FIRST k absences, then finds the longest run.
def longest_streak(record: str, k: int) -> int:
    days = list(record)
    for i, day in enumerate(days):
        if k == 0:
            break
        if day == 'A':
            days[i] = 'P'
            k -= 1
    return max(len(run) for run in "".join(days).split('A'))



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    record = data[2].decode()
    print(longest_streak(record, k))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
