from __future__ import annotations

import sys
import threading

# Tries every starting day and extends to the right until a (k+1)-th absence: O(n^2).
def longest_streak(record: str, k: int) -> int:
    n = len(record)
    best = 0
    for i in range(n):
        absent = 0
        j = i
        while j < n:
            if record[j] == 'A':
                absent += 1
                if absent > k:
                    break
            j += 1
        best = max(best, j - i)
    return best



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    record = data[2].decode()
    print(longest_streak(record, k))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
