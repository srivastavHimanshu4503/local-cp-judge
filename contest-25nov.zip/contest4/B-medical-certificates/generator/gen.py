"""Generate sample + secret inputs for Problem B (Medical Certificates). Deterministic."""
import pathlib
import random
import shutil

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAXN = 200_000
rng = random.Random(20261126)


def write(kind, name, record, k, desc):
    assert 1 <= len(record) <= MAXN and 0 <= k <= len(record) and set(record) <= set("PA")
    d = ROOT / "data" / kind
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.in").write_text(f"{len(record)} {k}\n{record}\n")
    (d / f"{name}.desc").write_text(desc + "\n")


def rand(n, absent_prob):
    return "".join("A" if rng.random() < absent_prob else "P" for _ in range(n))


def main():
    shutil.rmtree(ROOT / "data", ignore_errors=True)
    write("sample", "1", "PAPPAPAAPPP", 2, "Sample 1: two certificates")
    write("sample", "2", "PAPPAPAAPPP", 0, "Sample 2: the same record with no certificates")

    S = "secret"
    write(S, "01-one-present-day", "P", 0, "n=1, present")
    write(S, "02-one-absent-day", "A", 0, "n=1, absent, no certificate: answer 0")
    write(S, "03-one-absent-excused", "A", 1, "n=1, absent, one certificate")
    write(S, "04-all-absent-k0", "AAAAA", 0, "every day absent and no certificates: answer 0")
    write(S, "05-all-absent-k2", "AAAAA", 2, "every day absent, two certificates")
    write(S, "06-all-present", "PPPPPPP", 0, "every day present")
    write(S, "07-enough-certificates", "APAPPAP", 3, "enough certificates for every absence: answer n")
    write(S, "08-absent-at-both-ends", "APPPPPA", 1, "absences only on the first and last day")
    write(S, "09-alternating", "PAPAPAPAP", 2, "alternating present and absent")
    write(S, "10-excuse-later-absences", "PAPPAPPPPP", 1,
          "using the certificate on the first absence gives 5; excusing the second gives 8")
    write(S, "11-small-random", rand(30, 0.4), 4, "30 days, 40% absent, k=4")
    write(S, "12-medium-random", rand(5000, 0.3), 200, "5000 days, 30% absent, k=200")

    write(S, "13-max-all-present", "P" * MAXN, 0, "2e5 present days (kills trying every start: each scans to the end)")
    r = rand(MAXN, 0.01)
    write(S, "14-max-k-covers-all", r, r.count("A"), "1% absent and exactly enough certificates: answer n")
    write(S, "15-max-half-absent", rand(MAXN, 0.5), 1000, "50% absent, k=1000")
    write(S, "16-max-alternating", "PA" * (MAXN // 2), 100_000, "PAPA... with k=1e5")
    write(S, "17-max-all-absent-k0", "A" * MAXN, 0, "2e5 absent days, no certificates: answer 0")
    write(S, "18-max-all-absent-half", "A" * MAXN, MAXN // 2, "2e5 absent days, k=1e5")
    write(S, "19-max-absent-ends", "A" + "P" * (MAXN - 2) + "A", 1, "absent only on the first and last day, k=1")
    blocks = []
    while sum(map(len, blocks)) < MAXN - 2000:
        blocks.append("P" * rng.randint(1, 2000))
    r = "A".join(blocks)
    write(S, "20-max-long-runs", r[:MAXN], 3, "long present runs separated by single absences, k=3")
    write(S, "21-max-mostly-absent", rand(MAXN, 0.9), 50, "90% absent, k=50")
    write(S, "22-max-k-equals-n", rand(MAXN, 0.5), MAXN, "k=n: answer n")


if __name__ == "__main__":
    main()
