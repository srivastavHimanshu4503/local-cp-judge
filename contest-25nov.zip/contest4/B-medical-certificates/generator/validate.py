"""Strict input validator for Problem B. Usage: python3 validate.py file.in [...]"""
import re
import sys

INT = re.compile(rb"0|[1-9][0-9]*")


def check(path):
    raw = open(path, "rb").read()
    assert raw.endswith(b"\n"), "missing final newline"
    lines = raw[:-1].split(b"\n")
    assert len(lines) == 2, "expected exactly 2 lines"
    head = lines[0].split(b" ")
    assert len(head) == 2 and all(INT.fullmatch(t) for t in head), "bad first line"
    n, k = map(int, head)
    assert 1 <= n <= 200_000 and 0 <= k <= n
    assert len(lines[1]) == n and re.fullmatch(rb"[PA]+", lines[1]), "record must be n letters P/A"


for p in sys.argv[1:]:
    check(p)
print(f"validated {len(sys.argv) - 1} files")
