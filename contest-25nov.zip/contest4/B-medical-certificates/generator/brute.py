"""Independent checker for Problem B: tries every (start, end) pair. Small inputs only."""
import sys

d = open(sys.argv[1]).read().split()
n, k, record = int(d[0]), int(d[1]), d[2]
if n > 2500:
    sys.exit(3)
best = 0
for i in range(n):
    absent = 0
    for j in range(i, n):
        absent += record[j] == "A"
        if absent <= k:
            best = max(best, j - i + 1)
print(best)
