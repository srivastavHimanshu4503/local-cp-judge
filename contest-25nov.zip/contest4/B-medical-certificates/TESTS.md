# Tests for B. Medical Certificates

| Test | What it checks | Expected output |
|---|---|---|
| `sample/1` | Sample 1: two certificates | `6` |
| `sample/2` | Sample 2: the same record with no certificates | `3` |
| `secret/01-one-present-day` | n=1, present | `1` |
| `secret/02-one-absent-day` | n=1, absent, no certificate: answer 0 | `0` |
| `secret/03-one-absent-excused` | n=1, absent, one certificate | `1` |
| `secret/04-all-absent-k0` | every day absent and no certificates: answer 0 | `0` |
| `secret/05-all-absent-k2` | every day absent, two certificates | `2` |
| `secret/06-all-present` | every day present | `7` |
| `secret/07-enough-certificates` | enough certificates for every absence: answer n | `7` |
| `secret/08-absent-at-both-ends` | absences only on the first and last day | `6` |
| `secret/09-alternating` | alternating present and absent | `5` |
| `secret/10-excuse-later-absences` | using the certificate on the first absence gives 5; excusing the second gives 8 | `8` |
| `secret/11-small-random` | 30 days, 40% absent, k=4 | `12` |
| `secret/12-medium-random` | 5000 days, 30% absent, k=200 | `770` |
| `secret/13-max-all-present` | 2e5 present days (kills trying every start: each scans to the end) | `200000` |
| `secret/14-max-k-covers-all` | 1% absent and exactly enough certificates: answer n | `200000` |
| `secret/15-max-half-absent` | 50% absent, k=1000 | `2164` |
| `secret/16-max-alternating` | PAPA... with k=1e5 | `200000` |
| `secret/17-max-all-absent-k0` | 2e5 absent days, no certificates: answer 0 | `0` |
| `secret/18-max-all-absent-half` | 2e5 absent days, k=1e5 | `100000` |
| `secret/19-max-absent-ends` | absent only on the first and last day, k=1 | `199999` |
| `secret/20-max-long-runs` | long present runs separated by single absences, k=3 | `6356` |
| `secret/21-max-mostly-absent` | 90% absent, k=50 | `68` |
| `secret/22-max-k-equals-n` | k=n: answer n | `200000` |
