# C. Running Median

*Time limit: 2 seconds for Java, 6 seconds for Python. Memory limit: 1024 MB.*

The canteen records its profit at the end of every day; a loss is recorded as a negative number. After each day, the manager wants the **median** of all the values recorded so far.

The median of a list is its middle value once the list is sorted. When the list has an even number of values, there are two middle values: take the **lower** one. In other words, if the *i* values so far are sorted as *v*<sub>1</sub> ≤ *v*<sub>2</sub> ≤ … ≤ *v<sub>i</sub>*, the median is *v*<sub>⌈*i*/2⌉</sub>.

## What you write

You only write **one function**. The code that reads the input and prints the answer is already provided.

**Python**

```python
def running_median(values: list[int]) -> list[int]:
```

**Java**

```java
class Solution {
    public int[] runningMedian(int[] values) { ... }
}
```

- `values` contains the *n* daily values in the order they were recorded.
- Return a list (Java: an array) of *n* numbers. Element *i* is the median of `values[0]`, …, `values[i]`.

## Input format

- The first line contains one integer *n*.
- The second line contains *n* integers separated by single spaces: the daily values.

## Output format

One line with *n* integers separated by single spaces: the median after each day.

## Constraints

- 1 ≤ *n* ≤ 500 000
- −2 000 000 000 ≤ each value ≤ 2 000 000 000 (every value fits in a Java `int`)

## Sample 1

**Input**

```text
5
40 10 70 30 50
```

**Output**

```text
40 10 40 30 40
```

**Explanation.**

| Day | Values so far, sorted | Median |
|---|---|---|
| 1 | 40 | 40 |
| 2 | 10, 40 | 10 (the lower of the two middle values) |
| 3 | 10, 40, 70 | 40 |
| 4 | 10, 30, 40, 70 | 30 (the lower of 30 and 40) |
| 5 | 10, 30, 40, 50, 70 | 40 |

## Sample 2

**Input**

```text
3
-5 -20 3
```

**Output**

```text
-5 -20 -5
```

**Explanation.** After day 2 the sorted values are −20, −5, and the lower middle value is −20. After day 3 they are −20, −5, 3, with median −5.

> **Testing your code:** copy a sample input exactly as shown above and paste it into the custom input box.
