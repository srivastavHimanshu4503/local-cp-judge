// No heaps: compress the values, keep a Fenwick tree of counts, and after each insertion find the
// ((i + 2) / 2)-th smallest value with a binary-lifting walk. O(n log n).
class Solution {
    public int[] runningMedian(int[] values) {
        int n = values.length;
        int[] sorted = values.clone();
        Arrays.sort(sorted);
        int m = 0;
        for (int i = 0; i < n; i++) if (i == 0 || sorted[i] != sorted[i - 1]) sorted[m++] = sorted[i];
        int[] tree = new int[m + 1];
        int log = 1;
        while ((1 << log) <= m) log++;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int pos = Arrays.binarySearch(sorted, 0, m, values[i]) + 1;
            for (int p = pos; p <= m; p += p & -p) tree[p]++;
            int want = (i + 2) / 2, idx = 0;              // the want-th smallest (lower median)
            for (int step = 1 << log; step > 0; step >>= 1) {
                int next = idx + step;
                if (next <= m && tree[next] < want) { idx = next; want -= tree[next]; }
            }
            out[i] = sorted[idx];
        }
        return out;
    }
}
