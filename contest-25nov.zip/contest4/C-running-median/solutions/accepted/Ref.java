class Solution {
    public int[] runningMedian(int[] values) {
        PriorityQueue<Integer> low = new PriorityQueue<>(Collections.reverseOrder());   // smaller half
        PriorityQueue<Integer> high = new PriorityQueue<>();                             // larger half
        int[] out = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            int x = values[i];
            if (!low.isEmpty() && x > low.peek()) high.add(x); else low.add(x);
            if (low.size() > high.size() + 1) high.add(low.poll());
            else if (high.size() > low.size()) low.add(high.poll());
            out[i] = low.peek();
        }
        return out;
    }
}
