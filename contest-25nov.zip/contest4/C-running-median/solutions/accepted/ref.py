# Two heaps: `low` is a max-heap (stored negated) of the smaller half, `high` a min-heap of the
# larger half. Keep len(low) == len(high) or len(low) == len(high) + 1; the median is the top of low.
import heapq


def running_median(values: list[int]) -> list[int]:
    low, high = [], []
    out = []
    for x in values:
        if low and x > -low[0]:
            heapq.heappush(high, x)
        else:
            heapq.heappush(low, -x)
        if len(low) > len(high) + 1:
            heapq.heappush(high, -heapq.heappop(low))
        elif len(high) > len(low):
            heapq.heappush(low, -heapq.heappop(high))
        out.append(-low[0])
    return out
