# Another common two-heap style: always pass the new value through low into high, then move one
# value back if high became bigger. No comparison with the tops is needed.
import heapq


def running_median(values: list[int]) -> list[int]:
    low, high = [], []
    out = []
    for x in values:
        heapq.heappush(high, -heapq.heappushpop(low, -x))
        if len(high) > len(low):
            heapq.heappush(low, -heapq.heappop(high))
        out.append(-low[0])
    return out
