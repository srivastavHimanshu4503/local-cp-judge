// Builds the max-heap with the comparator (a, b) -> b - a. Values go up to 2*10^9 in size, so b - a
// can reach 4*10^9, which overflows int: the heap then orders some pairs the wrong way round.
class Solution {
    public int[] runningMedian(int[] values) {
        PriorityQueue<Integer> low = new PriorityQueue<>((a, b) -> b - a);
        PriorityQueue<Integer> high = new PriorityQueue<>((a, b) -> a - b);
        int[] out = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            int x = values[i];
            if (!low.isEmpty() && x > low.peek()) high.add(x); else low.add(x);
            if (low.size() > high.size() + 1) high.add(low.poll());
            else if (high.size() > low.size()) low.add(high.poll());
            out[i] = low.peek();
        }
        return out;
    }
}
