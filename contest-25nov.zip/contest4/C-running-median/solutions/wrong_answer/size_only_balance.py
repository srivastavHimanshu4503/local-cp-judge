# Puts each value into whichever heap is smaller, without comparing it with the tops, so the two
# halves are not really "smaller" and "larger" any more.
import heapq


def running_median(values: list[int]) -> list[int]:
    low, high = [], []
    out = []
    for x in values:
        if len(low) <= len(high):
            heapq.heappush(low, -x)
        else:
            heapq.heappush(high, x)
        out.append(-low[0])
    return out
