# Two heaps, but lets the UPPER half hold the extra element, so even counts report the upper middle.
import heapq


def running_median(values: list[int]) -> list[int]:
    low, high = [], []
    out = []
    for x in values:
        if high and x < high[0]:
            heapq.heappush(low, -x)
        else:
            heapq.heappush(high, x)
        if len(high) > len(low) + 1:
            heapq.heappush(low, -heapq.heappop(high))
        elif len(low) > len(high):
            heapq.heappush(high, -heapq.heappop(low))
        out.append(high[0])
    return out
