# Keeps a sorted list with bisect.insort. Each insert shifts up to i elements: O(n^2) data movement.
# Fast at 2*10^5 values (2-4 s), far too slow at 5*10^5.
from bisect import insort


def running_median(values: list[int]) -> list[int]:
    s = []
    out = []
    for i, x in enumerate(values):
        insort(s, x)
        out.append(s[i // 2])
    return out
