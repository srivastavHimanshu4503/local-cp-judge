# Sorts everything seen so far after every new value: O(n^2 log n).
def running_median(values: list[int]) -> list[int]:
    out = []
    for i in range(len(values)):
        s = sorted(values[:i + 1])
        out.append(s[i // 2])
    return out
