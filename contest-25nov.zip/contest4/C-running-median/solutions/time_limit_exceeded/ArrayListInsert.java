// Keeps a sorted ArrayList: binary search, then add(index, x). Each insert shifts up to i elements.
class Solution {
    public int[] runningMedian(int[] values) {
        ArrayList<Integer> s = new ArrayList<>();
        int[] out = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            int x = values[i], lo = 0, hi = s.size();
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (s.get(mid) < x) lo = mid + 1; else hi = mid;
            }
            s.add(lo, x);
            out[i] = s.get(i / 2);
        }
        return out;
    }
}
