// Sorts everything seen so far after every new value: O(n^2 log n).
class Solution {
    public int[] runningMedian(int[] values) {
        int[] out = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            int[] s = Arrays.copyOf(values, i + 1);
            Arrays.sort(s);
            out[i] = s[i / 2];
        }
        return out;
    }
}
