import java.io.*;
import java.util.*;

// No heaps: compress the values, keep a Fenwick tree of counts, and after each insertion find the
// ((i + 2) / 2)-th smallest value with a binary-lifting walk. O(n log n).
class Solution {
    public int[] runningMedian(int[] values) {
        int n = values.length;
        int[] sorted = values.clone();
        Arrays.sort(sorted);
        int m = 0;
        for (int i = 0; i < n; i++) if (i == 0 || sorted[i] != sorted[i - 1]) sorted[m++] = sorted[i];
        int[] tree = new int[m + 1];
        int log = 1;
        while ((1 << log) <= m) log++;
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int pos = Arrays.binarySearch(sorted, 0, m, values[i]) + 1;
            for (int p = pos; p <= m; p += p & -p) tree[p]++;
            int want = (i + 2) / 2, idx = 0;              // the want-th smallest (lower median)
            for (int step = 1 << log; step > 0; step >>= 1) {
                int next = idx + step;
                if (next <= m && tree[next] < want) { idx = next; want -= tree[next]; }
            }
            out[i] = sorted[idx];
        }
        return out;
    }
}



// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        int n = in.nextInt();
        int[] values = new int[n];
        for (int i = 0; i < n; i++) values[i] = in.nextInt();
        int[] medians = new Solution().runningMedian(values);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < medians.length; i++) {
            if (i > 0) sb.append(' ');
            sb.append(medians[i]);
        }
        out.println(sb);
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }

    String next() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = read(); }
        return sb.toString();
    }
}
