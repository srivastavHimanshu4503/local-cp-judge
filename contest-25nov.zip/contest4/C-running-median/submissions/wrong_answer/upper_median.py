from __future__ import annotations

import sys
import threading

# Two heaps, but lets the UPPER half hold the extra element, so even counts report the upper middle.
import heapq


def running_median(values: list[int]) -> list[int]:
    low, high = [], []
    out = []
    for x in values:
        if high and x < high[0]:
            heapq.heappush(low, -x)
        else:
            heapq.heappush(high, x)
        if len(high) > len(low) + 1:
            heapq.heappush(low, -heapq.heappop(high))
        elif len(low) > len(high):
            heapq.heappush(high, -heapq.heappop(low))
        out.append(high[0])
    return out



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    values = [int(x) for x in data[1:1 + n]]
    print(" ".join(map(str, running_median(values))))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
