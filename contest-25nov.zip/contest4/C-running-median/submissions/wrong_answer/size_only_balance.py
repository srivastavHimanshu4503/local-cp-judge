from __future__ import annotations

import sys
import threading

# Puts each value into whichever heap is smaller, without comparing it with the tops, so the two
# halves are not really "smaller" and "larger" any more.
import heapq


def running_median(values: list[int]) -> list[int]:
    low, high = [], []
    out = []
    for x in values:
        if len(low) <= len(high):
            heapq.heappush(low, -x)
        else:
            heapq.heappush(high, x)
        out.append(-low[0])
    return out



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    values = [int(x) for x in data[1:1 + n]]
    print(" ".join(map(str, running_median(values))))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
