import java.io.*;
import java.util.*;

// Builds the max-heap with the comparator (a, b) -> b - a. Values go up to 2*10^9 in size, so b - a
// can reach 4*10^9, which overflows int: the heap then orders some pairs the wrong way round.
class Solution {
    public int[] runningMedian(int[] values) {
        PriorityQueue<Integer> low = new PriorityQueue<>((a, b) -> b - a);
        PriorityQueue<Integer> high = new PriorityQueue<>((a, b) -> a - b);
        int[] out = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            int x = values[i];
            if (!low.isEmpty() && x > low.peek()) high.add(x); else low.add(x);
            if (low.size() > high.size() + 1) high.add(low.poll());
            else if (high.size() > low.size()) low.add(high.poll());
            out[i] = low.peek();
        }
        return out;
    }
}



// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        int n = in.nextInt();
        int[] values = new int[n];
        for (int i = 0; i < n; i++) values[i] = in.nextInt();
        int[] medians = new Solution().runningMedian(values);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < medians.length; i++) {
            if (i > 0) sb.append(' ');
            sb.append(medians[i]);
        }
        out.println(sb);
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }

    String next() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = read(); }
        return sb.toString();
    }
}
