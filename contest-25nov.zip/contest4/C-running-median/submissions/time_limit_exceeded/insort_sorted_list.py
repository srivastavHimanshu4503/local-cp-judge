from __future__ import annotations

import sys
import threading

# Keeps a sorted list with bisect.insort. Each insert shifts up to i elements: O(n^2) data movement.
# Fast at 2*10^5 values (2-4 s), far too slow at 5*10^5.
from bisect import insort


def running_median(values: list[int]) -> list[int]:
    s = []
    out = []
    for i, x in enumerate(values):
        insort(s, x)
        out.append(s[i // 2])
    return out



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    values = [int(x) for x in data[1:1 + n]]
    print(" ".join(map(str, running_median(values))))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
