# ======================== WRITE YOUR CODE HERE ========================
def running_median(values: list[int]) -> list[int]:
    # values: the n daily values, in the order they arrive (negative means a loss)
    # return: a list of n numbers; element i is the median of values[0..i]
    #         (for an even count, the LOWER of the two middle values)
    return []
