// ======================== WRITE YOUR CODE HERE ========================
class Solution {
    public int[] runningMedian(int[] values) {
        // values: the n daily values, in the order they arrive (negative means a loss)
        // return: an array of n numbers; element i is the median of values[0..i]
        //         (for an even count, the LOWER of the two middle values)
        return new int[values.length];
    }
}
