"""Strict input validator for Problem C. Usage: python3 validate.py file.in [...]"""
import re
import sys

INT = re.compile(rb"-?(0|[1-9][0-9]*)")


def check(path):
    raw = open(path, "rb").read()
    assert raw.endswith(b"\n"), "missing final newline"
    lines = raw[:-1].split(b"\n")
    assert len(lines) == 2, "expected exactly 2 lines"
    assert re.fullmatch(rb"[1-9][0-9]*", lines[0]), "bad n"
    n = int(lines[0])
    assert 1 <= n <= 500_000
    toks = lines[1].split(b" ")
    assert len(toks) == n, "wrong number of values"
    for t in toks:
        assert INT.fullmatch(t) and t != b"-0", f"bad token {t[:20]!r}"
        assert -2 * 10**9 <= int(t) <= 2 * 10**9


for p in sys.argv[1:]:
    check(p)
print(f"validated {len(sys.argv) - 1} files")
