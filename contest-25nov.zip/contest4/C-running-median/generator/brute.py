"""Independent checker for Problem C: sorts every prefix from scratch. Small inputs only."""
import sys

d = open(sys.argv[1]).read().split()
n = int(d[0])
if n > 5000:
    sys.exit(3)
v = list(map(int, d[1:1 + n]))
print(" ".join(str(sorted(v[:i + 1])[i // 2]) for i in range(n)))
