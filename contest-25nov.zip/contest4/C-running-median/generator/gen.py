"""Generate sample + secret inputs for Problem C (Running Median). Deterministic."""
import pathlib
import random
import shutil

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAXN, V = 500_000, 2 * 10**9
rng = random.Random(20261127)


def write(kind, name, values, desc):
    assert 1 <= len(values) <= MAXN and all(-V <= x <= V for x in values)
    d = ROOT / "data" / kind
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.in").write_text(f"{len(values)}\n{' '.join(map(str, values))}\n")
    (d / f"{name}.desc").write_text(desc + "\n")


def rand(n, lo=-V, hi=V):
    return [rng.randint(lo, hi) for _ in range(n)]


def main():
    shutil.rmtree(ROOT / "data", ignore_errors=True)
    write("sample", "1", [40, 10, 70, 30, 50], "Sample 1: after an even number of days, the lower middle value")
    write("sample", "2", [-5, -20, 3], "Sample 2: losses are negative")

    S = "secret"
    write(S, "01-one-day", [7], "a single day")
    write(S, "02-two-days", [9, 4], "two days: the lower value")
    write(S, "03-all-equal", [5] * 6, "every value equal")
    write(S, "04-increasing", list(range(1, 11)), "strictly increasing")
    write(S, "05-decreasing", list(range(10, 0, -1)), "strictly decreasing")
    write(S, "06-duplicates-near-median", [3, 3, 1, 3, 5, 3, 3, 2, 3], "many copies of the median value")
    write(S, "07-extremes", [V, -V, V, -V, 0, V, -V, -V, V], "values at -2*10^9 and 2*10^9 (catches a max-heap comparator b - a that overflows)")
    write(S, "08-small-random", rand(40, -50, 50), "40 values in -50..50")
    write(S, "09-medium-random", rand(5000), "5000 random values")

    write(S, "10-max-random", rand(MAXN), "5e5 random values in -2*10^9..2*10^9 (kills re-sorting and sorted-list insertion)")
    write(S, "11-max-decreasing", [V - 3 * i for i in range(MAXN)], "5e5 decreasing values: every new value goes to the front")
    write(S, "12-max-increasing", [-V + 3 * i for i in range(MAXN)], "5e5 increasing values")
    zig = []
    for i in range(MAXN // 2):
        zig += [V - i, -V + i]
    write(S, "13-max-zigzag", zig, "alternating high and low values that slowly converge")
    write(S, "14-max-few-values", rand(MAXN, -3, 3), "5e5 values in -3..3 (heavy duplicates)")
    write(S, "15-max-all-equal", [-123456789] * MAXN, "5e5 copies of one negative value")
    write(S, "16-max-extremes", [rng.choice([-V, V, -V + 1, V - 1, 0]) for _ in range(MAXN)],
          "only values near -2*10^9, 0 and 2*10^9")


if __name__ == "__main__":
    main()
