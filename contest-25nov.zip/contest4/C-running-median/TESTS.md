# Tests for C. Running Median

| Test | What it checks | Expected output |
|---|---|---|
| `sample/1` | Sample 1: after an even number of days, the lower middle value | `5 numbers: 40 10 40 30 ...` |
| `sample/2` | Sample 2: losses are negative | `3 numbers: -5 -20 -5` |
| `secret/01-one-day` | a single day | `7` |
| `secret/02-two-days` | two days: the lower value | `2 numbers: 9 4` |
| `secret/03-all-equal` | every value equal | `6 numbers: 5 5 5 5 ...` |
| `secret/04-increasing` | strictly increasing | `10 numbers: 1 1 2 2 ...` |
| `secret/05-decreasing` | strictly decreasing | `10 numbers: 10 9 9 8 ...` |
| `secret/06-duplicates-near-median` | many copies of the median value | `9 numbers: 3 3 3 3 ...` |
| `secret/07-extremes` | values at -2*10^9 and 2*10^9 (catches a max-heap comparator b - a that overflows) | `9 numbers: 2000000000 -2000000000 2000000000 -2000000000 ...` |
| `secret/08-small-random` | 40 values in -50..50 | `40 numbers: -46 -46 -17 -17 ...` |
| `secret/09-medium-random` | 5000 random values | `5000 numbers: 259521793 -1865451954 43222465 43222465 ...` |
| `secret/10-max-random` | 5e5 random values in -2*10^9..2*10^9 (kills re-sorting and sorted-list insertion) | `500000 numbers: -1315224223 -1315224223 -809153483 -809153483 ...` |
| `secret/11-max-decreasing` | 5e5 decreasing values: every new value goes to the front | `500000 numbers: 2000000000 1999999997 1999999997 1999999994 ...` |
| `secret/12-max-increasing` | 5e5 increasing values | `500000 numbers: -2000000000 -2000000000 -1999999997 -1999999997 ...` |
| `secret/13-max-zigzag` | alternating high and low values that slowly converge | `500000 numbers: 2000000000 -2000000000 1999999999 -1999999999 ...` |
| `secret/14-max-few-values` | 5e5 values in -3..3 (heavy duplicates) | `500000 numbers: 1 -2 0 -2 ...` |
| `secret/15-max-all-equal` | 5e5 copies of one negative value | `500000 numbers: -123456789 -123456789 -123456789 -123456789 ...` |
| `secret/16-max-extremes` | only values near -2*10^9, 0 and 2*10^9 | `500000 numbers: 0 -1999999999 -1999999999 -1999999999 ...` |
