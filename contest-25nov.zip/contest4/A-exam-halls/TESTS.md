# Tests for A. Exam Halls

| Test | What it checks | Expected output |
|---|---|---|
| `sample/1` | Sample 1: every batch can be seated if halls are chosen well | `3` |
| `sample/2` | Sample 2: more batches than halls | `1` |
| `secret/01-one-exact-fit` | one batch, one hall of exactly its size (a hall as big as the batch fits) | `1` |
| `secret/02-one-too-small` | one batch, the only hall is one seat short | `0` |
| `secret/03-all-equal` | every batch and hall has the same size: 4 halls, so 4 batches | `4` |
| `secret/04-nothing-fits` | every hall is smaller than every batch | `0` |
| `secret/05-everything-fits` | every hall fits every batch | `3` |
| `secret/06-skip-small-halls` | the smallest halls must be skipped (same-index pairing gets 0) | `3` |
| `secret/07-big-halls-wasted` | the big halls must go to the big batches | `3` |
| `secret/08-small-random` | 12 batches, 10 halls, sizes 1..30 | `10` |
| `secret/09-medium-random` | 3000 batches, 2500 halls | `2489` |
| `secret/10-max-random` | 2e5 batches and 2e5 halls, random sizes (kills O(n*m)) | `199601` |
| `secret/11-max-exact-copies` | the halls are exactly the batch sizes, shuffled: every batch fits a hall exactly | `200000` |
| `secret/12-max-one-seat-short` | each hall is one seat smaller than some batch | `199998` |
| `secret/13-max-many-halls` | 1000 batches, 2e5 halls | `1000` |
| `secret/14-max-many-batches` | 2e5 batches, 1000 halls | `1000` |
| `secret/15-max-few-values` | sizes and capacities only 1..5 (heavy duplicates) | `199544` |
| `secret/16-max-all-fit` | every hall fits every batch | `200000` |
| `secret/17-max-none-fit` | no hall fits any batch | `0` |
| `secret/18-max-sorted-inputs` | batches ascending, halls descending | `199565` |
| `secret/19-max-values` | all batches 10^9; half the halls 10^9, half one seat short | `100000` |
