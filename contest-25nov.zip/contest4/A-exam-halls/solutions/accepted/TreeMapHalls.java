// For each batch (smallest first), take the smallest free hall that fits, using a TreeMap as a multiset.
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        TreeMap<Integer, Integer> free = new TreeMap<>();
        for (int c : capacities) free.merge(c, 1, Integer::sum);
        int[] s = sizes.clone();
        Arrays.sort(s);
        int seated = 0;
        for (int b : s) {
            Integer hall = free.ceilingKey(b);
            if (hall == null) break;                 // larger batches will not fit either
            if (free.merge(hall, -1, Integer::sum) == 0) free.remove(hall);
            seated++;
        }
        return seated;
    }
}
