# Sort both. Walk through the halls from smallest to largest; a hall that fits the smallest
# waiting batch is given to it, a hall that is too small for it is too small for every batch.
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    s = sorted(sizes)
    seated = 0
    for c in sorted(capacities):
        if seated < len(s) and c >= s[seated]:
            seated += 1
    return seated
