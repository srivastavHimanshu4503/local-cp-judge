# Mirror image: the largest batch tries the largest hall; if it does not fit there, it fits nowhere.
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    s = sorted(sizes, reverse=True)
    c = sorted(capacities, reverse=True)
    j = 0
    for b in s:
        if j < len(c) and c[j] >= b:
            j += 1
    return j
