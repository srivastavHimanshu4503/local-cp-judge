# For each batch (smallest first), binary-search the smallest free hall that fits and delete it from
# a sorted Python list. Each delete shifts the rest of the list: O(n * m) element moves on paper, but
# the shifting is a fast C memmove (about 5 s of the 12 s Python limit). Accepted on purpose.
from bisect import bisect_left


def max_batches(sizes: list[int], capacities: list[int]) -> int:
    halls = sorted(capacities)
    seated = 0
    for b in sorted(sizes):
        i = bisect_left(halls, b)
        if i == len(halls):
            break
        del halls[i]
        seated += 1
    return seated
