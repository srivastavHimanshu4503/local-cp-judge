// For each batch (smallest first), binary-search the smallest free hall that fits in a sorted
// ArrayList and remove it. Each remove shifts the rest of the list: O(n * m) element moves on paper,
// but System.arraycopy is fast (about 2.3 s of the 4 s Java limit). Accepted on purpose.
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        int[] c = capacities.clone();
        Arrays.sort(c);
        ArrayList<Integer> halls = new ArrayList<>();
        for (int x : c) halls.add(x);
        int[] s = sizes.clone();
        Arrays.sort(s);
        int seated = 0;
        for (int b : s) {
            int lo = 0, hi = halls.size();
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (halls.get(mid) < b) lo = mid + 1; else hi = mid;
            }
            if (lo == halls.size()) break;
            halls.remove(lo);
            seated++;
        }
        return seated;
    }
}
