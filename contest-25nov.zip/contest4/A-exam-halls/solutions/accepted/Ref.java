class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        int[] s = sizes.clone(), c = capacities.clone();
        Arrays.sort(s);
        Arrays.sort(c);
        int seated = 0;
        for (int cap : c)
            if (seated < s.length && cap >= s[seated]) seated++;
        return seated;
    }
}
