# Gives the biggest halls to the smallest batches, wasting big halls on small groups.
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    s, c = sorted(sizes), sorted(capacities, reverse=True)
    return sum(1 for i in range(min(len(s), len(c))) if c[i] >= s[i])
