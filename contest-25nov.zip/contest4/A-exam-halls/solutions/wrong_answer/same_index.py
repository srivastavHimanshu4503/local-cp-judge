# Pairs the i-th smallest batch with the i-th smallest hall and never skips a hall that is too small.
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    s, c = sorted(sizes), sorted(capacities)
    return sum(1 for i in range(min(len(s), len(c))) if c[i] >= s[i])
