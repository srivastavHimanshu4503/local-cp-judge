// Takes batches in input order and gives each the FIRST free hall that fits (not the smallest).
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        boolean[] used = new boolean[capacities.length];
        int seated = 0;
        for (int b : sizes)
            for (int j = 0; j < capacities.length; j++)
                if (!used[j] && capacities[j] >= b) { used[j] = true; seated++; break; }
        return seated;
    }
}
