// For each batch (smallest first), scans every hall for the smallest free one that fits: O(n * m).
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        int[] s = sizes.clone();
        Arrays.sort(s);
        boolean[] used = new boolean[capacities.length];
        int seated = 0;
        for (int b : s) {
            int best = -1;
            for (int j = 0; j < capacities.length; j++)
                if (!used[j] && capacities[j] >= b && (best == -1 || capacities[j] < capacities[best])) best = j;
            if (best != -1) { used[best] = true; seated++; }
        }
        return seated;
    }
}
