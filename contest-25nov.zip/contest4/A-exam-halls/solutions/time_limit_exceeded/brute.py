# For each batch (smallest first), scans every hall for the smallest free one that fits: O(n * m).
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    used = [False] * len(capacities)
    seated = 0
    for b in sorted(sizes):
        best = -1
        for j, c in enumerate(capacities):
            if not used[j] and c >= b and (best == -1 or c < capacities[best]):
                best = j
        if best != -1:
            used[best] = True
            seated += 1
    return seated
