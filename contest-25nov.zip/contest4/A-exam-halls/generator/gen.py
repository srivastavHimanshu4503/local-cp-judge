"""Generate sample + secret inputs for Problem A (Exam Halls). Deterministic."""
import pathlib
import random
import shutil

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAXN, V = 200_000, 10**9
rng = random.Random(20261125)


def write(kind, name, sizes, caps, desc):
    assert 1 <= len(sizes) <= MAXN and 1 <= len(caps) <= MAXN
    assert all(1 <= x <= V for x in sizes) and all(1 <= x <= V for x in caps)
    d = ROOT / "data" / kind
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.in").write_text(f"{len(sizes)} {len(caps)}\n{' '.join(map(str, sizes))}\n{' '.join(map(str, caps))}\n")
    (d / f"{name}.desc").write_text(desc + "\n")


def rand(n, lo=1, hi=V):
    return [rng.randint(lo, hi) for _ in range(n)]


def main():
    shutil.rmtree(ROOT / "data", ignore_errors=True)
    write("sample", "1", [30, 60, 45], [50, 25, 40, 70], "Sample 1: every batch can be seated if halls are chosen well")
    write("sample", "2", [40, 10, 30, 20], [35], "Sample 2: more batches than halls")

    S = "secret"
    write(S, "01-one-exact-fit", [50], [50], "one batch, one hall of exactly its size (a hall as big as the batch fits)")
    write(S, "02-one-too-small", [50], [49], "one batch, the only hall is one seat short")
    write(S, "03-all-equal", [7] * 6, [7] * 4, "every batch and hall has the same size: 4 halls, so 4 batches")
    write(S, "04-nothing-fits", [100, 200, 300], [10, 20, 30, 99], "every hall is smaller than every batch")
    write(S, "05-everything-fits", [1, 2, 3], [100, 200, 300, 400, 500], "every hall fits every batch")
    write(S, "06-skip-small-halls", [10, 20, 30], [5, 6, 7, 10, 20, 30], "the smallest halls must be skipped (same-index pairing gets 0)")
    write(S, "07-big-halls-wasted", [5, 50, 60], [55, 65, 6], "the big halls must go to the big batches")
    write(S, "08-small-random", rand(12, 1, 30), rand(10, 1, 30), "12 batches, 10 halls, sizes 1..30")
    write(S, "09-medium-random", rand(3000, 1, 10**6), rand(2500, 1, 10**6), "3000 batches, 2500 halls")

    write(S, "10-max-random", rand(MAXN), rand(MAXN), "2e5 batches and 2e5 halls, random sizes (kills O(n*m))")
    s = rand(MAXN); c = s[:]; rng.shuffle(c)
    write(S, "11-max-exact-copies", s, c, "the halls are exactly the batch sizes, shuffled: every batch fits a hall exactly")
    s = rand(MAXN, 2, V); c = [x - 1 for x in s]; rng.shuffle(c)
    write(S, "12-max-one-seat-short", s, c, "each hall is one seat smaller than some batch")
    write(S, "13-max-many-halls", rand(1000), rand(MAXN), "1000 batches, 2e5 halls")
    write(S, "14-max-many-batches", rand(MAXN), rand(1000), "2e5 batches, 1000 halls")
    write(S, "15-max-few-values", rand(MAXN, 1, 5), rand(MAXN, 1, 5), "sizes and capacities only 1..5 (heavy duplicates)")
    write(S, "16-max-all-fit", rand(MAXN, 1, 1000), rand(MAXN, 10**8, V), "every hall fits every batch")
    write(S, "17-max-none-fit", rand(MAXN, 10**8, V), rand(MAXN, 1, 1000), "no hall fits any batch")
    write(S, "18-max-sorted-inputs", sorted(rand(MAXN)), sorted(rand(MAXN), reverse=True), "batches ascending, halls descending")
    write(S, "19-max-values", [V] * MAXN, [V] * (MAXN // 2) + [V - 1] * (MAXN // 2), "all batches 10^9; half the halls 10^9, half one seat short")


if __name__ == "__main__":
    main()
