"""Independent checker for Problem A: maximum bipartite matching (augmenting paths), no greedy.
Small inputs only (exits with status 3 otherwise)."""
import sys

d = open(sys.argv[1]).read().split()
n, m = int(d[0]), int(d[1])
if n * m > 4_000_000:
    sys.exit(3)
sizes = list(map(int, d[2:2 + n]))
caps = list(map(int, d[2 + n:2 + n + m]))
hall_of = [-1] * m                      # which batch each hall is given to


def augment(b, seen):
    for h in range(m):
        if caps[h] >= sizes[b] and not seen[h]:
            seen[h] = True
            if hall_of[h] == -1 or augment(hall_of[h], seen):
                hall_of[h] = b
                return True
    return False


sys.setrecursionlimit(10000)
print(sum(augment(b, [False] * m) for b in range(n)))
