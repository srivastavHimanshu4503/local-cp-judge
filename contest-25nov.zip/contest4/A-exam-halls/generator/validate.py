"""Strict input validator for Problem A. Usage: python3 validate.py file.in [...]"""
import re
import sys

INT = re.compile(rb"[1-9][0-9]*")


def nums(line, k):
    toks = line.split(b" ")
    assert len(toks) == k and all(INT.fullmatch(t) for t in toks), f"bad line {line[:40]!r}"
    return [int(t) for t in toks]


def check(path):
    raw = open(path, "rb").read()
    assert raw.endswith(b"\n"), "missing final newline"
    lines = raw[:-1].split(b"\n")
    assert len(lines) == 3, "expected exactly 3 lines"
    n, m = nums(lines[0], 2)
    assert 1 <= n <= 200_000 and 1 <= m <= 200_000
    assert all(1 <= x <= 10**9 for x in nums(lines[1], n))
    assert all(1 <= x <= 10**9 for x in nums(lines[2], m))


for p in sys.argv[1:]:
    check(p)
print(f"validated {len(sys.argv) - 1} files")
