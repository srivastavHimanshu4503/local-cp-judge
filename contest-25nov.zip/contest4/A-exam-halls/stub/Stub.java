// ======================== WRITE YOUR CODE HERE ========================
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        // sizes:      sizes[i] is the number of students in batch i
        // capacities: capacities[j] is the number of seats in hall j
        // return:     the largest number of batches that can each get their own hall that fits them
        return 0;
    }
}
