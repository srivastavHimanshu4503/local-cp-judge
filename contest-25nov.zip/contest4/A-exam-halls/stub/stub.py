# ======================== WRITE YOUR CODE HERE ========================
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    # sizes:      sizes[i] is the number of students in batch i
    # capacities: capacities[j] is the number of seats in hall j
    # return:     the largest number of batches that can each get their own hall that fits them
    return 0
