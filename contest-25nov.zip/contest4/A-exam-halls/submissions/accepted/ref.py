from __future__ import annotations

import sys
import threading

# Sort both. Walk through the halls from smallest to largest; a hall that fits the smallest
# waiting batch is given to it, a hall that is too small for it is too small for every batch.
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    s = sorted(sizes)
    seated = 0
    for c in sorted(capacities):
        if seated < len(s) and c >= s[seated]:
            seated += 1
    return seated



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    sizes = [int(x) for x in data[2:2 + n]]
    capacities = [int(x) for x in data[2 + n:2 + n + m]]
    print(max_batches(sizes, capacities))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
