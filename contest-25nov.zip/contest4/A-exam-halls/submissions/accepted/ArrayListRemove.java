import java.io.*;
import java.util.*;

// For each batch (smallest first), binary-search the smallest free hall that fits in a sorted
// ArrayList and remove it. Each remove shifts the rest of the list: O(n * m) element moves on paper,
// but System.arraycopy is fast (about 2.3 s of the 4 s Java limit). Accepted on purpose.
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) {
        int[] c = capacities.clone();
        Arrays.sort(c);
        ArrayList<Integer> halls = new ArrayList<>();
        for (int x : c) halls.add(x);
        int[] s = sizes.clone();
        Arrays.sort(s);
        int seated = 0;
        for (int b : s) {
            int lo = 0, hi = halls.size();
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (halls.get(mid) < b) lo = mid + 1; else hi = mid;
            }
            if (lo == halls.size()) break;
            halls.remove(lo);
            seated++;
        }
        return seated;
    }
}



// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        int n = in.nextInt(), m = in.nextInt();
        int[] sizes = new int[n];
        for (int i = 0; i < n; i++) sizes[i] = in.nextInt();
        int[] capacities = new int[m];
        for (int j = 0; j < m; j++) capacities[j] = in.nextInt();
        out.println(new Solution().maxBatches(sizes, capacities));
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }

    String next() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = read(); }
        return sb.toString();
    }
}
