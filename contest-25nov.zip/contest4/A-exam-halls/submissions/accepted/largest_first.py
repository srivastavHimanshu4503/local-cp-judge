from __future__ import annotations

import sys
import threading

# Mirror image: the largest batch tries the largest hall; if it does not fit there, it fits nowhere.
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    s = sorted(sizes, reverse=True)
    c = sorted(capacities, reverse=True)
    j = 0
    for b in s:
        if j < len(c) and c[j] >= b:
            j += 1
    return j



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    sizes = [int(x) for x in data[2:2 + n]]
    capacities = [int(x) for x in data[2 + n:2 + n + m]]
    print(max_batches(sizes, capacities))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
