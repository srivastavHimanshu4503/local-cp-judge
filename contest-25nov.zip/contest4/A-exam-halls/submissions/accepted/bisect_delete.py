from __future__ import annotations

import sys
import threading

# For each batch (smallest first), binary-search the smallest free hall that fits and delete it from
# a sorted Python list. Each delete shifts the rest of the list: O(n * m) element moves on paper, but
# the shifting is a fast C memmove (about 5 s of the 12 s Python limit). Accepted on purpose.
from bisect import bisect_left


def max_batches(sizes: list[int], capacities: list[int]) -> int:
    halls = sorted(capacities)
    seated = 0
    for b in sorted(sizes):
        i = bisect_left(halls, b)
        if i == len(halls):
            break
        del halls[i]
        seated += 1
    return seated



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    sizes = [int(x) for x in data[2:2 + n]]
    capacities = [int(x) for x in data[2 + n:2 + n + m]]
    print(max_batches(sizes, capacities))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
