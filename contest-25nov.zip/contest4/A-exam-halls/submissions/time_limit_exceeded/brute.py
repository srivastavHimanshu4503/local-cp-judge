from __future__ import annotations

import sys
import threading

# For each batch (smallest first), scans every hall for the smallest free one that fits: O(n * m).
def max_batches(sizes: list[int], capacities: list[int]) -> int:
    used = [False] * len(capacities)
    seated = 0
    for b in sorted(sizes):
        best = -1
        for j, c in enumerate(capacities):
            if not used[j] and c >= b and (best == -1 or c < capacities[best]):
                best = j
        if best != -1:
            used[best] = True
            seated += 1
    return seated



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    sizes = [int(x) for x in data[2:2 + n]]
    capacities = [int(x) for x in data[2 + n:2 + n + m]]
    print(max_batches(sizes, capacities))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
