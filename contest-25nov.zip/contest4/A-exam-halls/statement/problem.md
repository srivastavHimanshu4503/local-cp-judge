# A. Exam Halls

*Time limit: 4 seconds for Java, 12 seconds for Python. Memory limit: 1024 MB.*

The exam cell has to seat *n* batches of students in *m* exam halls.

- Batch *i* has *s<sub>i</sub>* students, and hall *j* has *c<sub>j</sub>* seats.
- A hall can host **at most one** batch, and a batch needs a whole hall to itself.
- A batch **fits** in a hall if the hall has at least as many seats as the batch has students. A hall with exactly as many seats as students is fine.

What is the **largest number of batches** that can each be given a hall they fit in?

## What you write

You only write **one function**. The code that reads the input and prints the answer is already provided.

**Python**

```python
def max_batches(sizes: list[int], capacities: list[int]) -> int:
```

**Java**

```java
class Solution {
    public int maxBatches(int[] sizes, int[] capacities) { ... }
}
```

- `sizes` contains the *n* batch sizes and `capacities` contains the *m* hall capacities, both in input order.
- Return the largest number of batches that can be seated.

## Input format

- The first line contains two integers *n* and *m*.
- The second line contains *n* integers *s*<sub>1</sub>, …, *s<sub>n</sub>*: the batch sizes.
- The third line contains *m* integers *c*<sub>1</sub>, …, *c<sub>m</sub>*: the hall capacities.

## Output format

One integer: the largest number of batches that can be seated.

## Constraints

- 1 ≤ *n* ≤ 200 000
- 1 ≤ *m* ≤ 200 000
- 1 ≤ *s<sub>i</sub>*, *c<sub>j</sub>* ≤ 1 000 000 000

## Sample 1

**Input**

```text
3 4
30 60 45
50 25 40 70
```

**Output**

```text
3
```

**Explanation.** Put the batch of 30 in the hall of 40, the batch of 45 in the hall of 50, and the batch of 60 in the hall of 70. The hall of 25 is too small for every batch and stays empty.

Careless choices seat fewer batches. For example, giving the batch of 30 the hall of 50 leaves only the halls of 25 and 40 for the batch of 45, and neither is big enough.

## Sample 2

**Input**

```text
4 1
40 10 30 20
35
```

**Output**

```text
1
```

**Explanation.** There is only one hall, so at most one batch can be seated. The hall of 35 fits the batch of 10, 20 or 30.

> **Testing your code:** copy a sample input exactly as shown above and paste it into the custom input box.
