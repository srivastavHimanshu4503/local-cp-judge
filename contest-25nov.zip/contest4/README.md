# Contest package: four problems

| | Problem | Topic | Python function | Java method | Time limit (Java / Python) | Secret tests |
|---|---|---|---|---|---|---|
| A | Exam Halls | greedy | `max_batches(sizes, capacities)` | `int maxBatches(int[] sizes, int[] capacities)` | 4 s / 12 s | 19 |
| B | Medical Certificates | sliding window | `longest_streak(record, k)` | `int longestStreak(String record, int k)` | 2 s / 6 s | 22 |
| C | Running Median | heaps | `running_median(values)` | `int[] runningMedian(int[] values)` | 2 s / 6 s | 16 |
| D | Queens on a Damaged Board | backtracking | `count_placements(board)` | `int countPlacements(String[] board)` | 3 s / 9 s | 22 |

The memory limit is 1024 MB for every problem.

## Importing into DOMjudge

1. Import the four zips (Jury → Problems → Import). Each holds the metadata, the HTML statement (as `problem_statement/problem.html` and as `problem.html` at the zip root), all tests and the jury submissions.
2. **Set the Python 3 language time factor to 3.** The statements promise Python three times the Java limit.
3. **Judge the imported jury submissions on your own server.** Every `accepted/` submission should get CORRECT and every other one the verdict its folder names. The tightest margins are A's `bisect_delete.py` (5.0 s of 12 s) and `ArrayListRemove.java` (2.3 s of 4 s), and D's `check_each_queen.py` (4.0 s of 9 s).

The HTML statements are also in `statements/` for uploading by hand. They are pure ASCII with inline CSS and no scripts or external resources, so they render correctly whatever character set DOMjudge declares.

## Design notes

**A. Exam Halls.** The intended solution sorts both lists and walks through the halls from smallest to largest, seating the smallest waiting batch whenever the hall fits it. Sample 1 alone rules out three tempting wrong greedies:

- pairing the i-th smallest batch with the i-th smallest hall gives 0;
- giving the biggest halls to the smallest batches gives 2;
- first-fit in input order gives 2.

Test 01 catches `>` used instead of `≥`. The time limit is deliberately generous. Binary-searching a sorted list and deleting each used hall is O(n·m) element moves on paper, but in practice it takes 5 s in Python and 2.3 s in Java, so I let it pass comfortably rather than leave it on the edge. The true O(n·m) brute force still needs about 4×10¹⁰ steps.

**B. Medical Certificates.** Sample 1 catches "longest run of P's plus k" (5) and counting only present days in the window (4). Test 10 catches spending the certificates on the first absences. Test 13 (2×10⁵ present days) makes "try every start" scan to the end every time.

**C. Running Median.** Values go up to ±2×10⁹, which still fits in an `int`. The range is chosen so that a Java max-heap built with `(a, b) -> b - a` overflows and orders the heap wrongly (caught on test 07). With ±10⁹, `b − a` never exceeds 2×10⁹ and the trap would not fire. n goes up to 5×10⁵ because a sorted Python list with `insort` passes at 2×10⁵ but takes far too long at 5×10⁵; the same applies to Java's `ArrayList.add(index, x)`. Sample 1 catches the upper median, the average of the two middle values, and filling the heaps by size without comparing against their tops.

**D. Queens on a Damaged Board.** Damaged squares cannot hold a queen but do not stop attacks. The statement says so in bold, and sample 2 shows a placement that is invalid only because of this rule, which catches the "walls" misreading. n = 12 is what kills the brute force that tries every column permutation: in Java it passes at n = 11 (2.5 s) but takes 25 s at n = 12. Both pruned styles pass in both languages, whether they use column and diagonal sets or bitmasks, or check each earlier queen one by one.

## Verification

- `.ans` files come from the Python reference and are confirmed by every other accepted solution in both languages.
- `generator/brute.py` independently recomputes every test it can handle:

  | Problem | Independent check | Coverage |
  |---|---|---|
  | A | maximum bipartite matching (augmenting paths, no greedy) | all tests up to n·m = 4×10⁶ |
  | B | every (start, end) pair | all tests up to n = 2500 |
  | C | sorting every prefix | all tests up to n = 5000 |
  | D | every column permutation | every board up to n = 10 |

  For D, the empty 11 × 11 and 12 × 12 boards are also certified against the known N-Queens counts (2680 and 14 200). The remaining large tests are confirmed by independent accepted algorithms:
  - A: sweep, largest-first, TreeMap and list-delete;
  - B: window, positions of absences and prefix sums with binary search;
  - C: two heaps in two styles and a Fenwick tree;
  - D: sets, bitmasks and per-queen checks.
- `generator/validate.py` checks every input strictly.
- The statement samples are byte-identical to `data/sample`, and both student templates run cleanly on them.

| | Submission | Verdict | Detail |
|---|---|---|---|
| A | `accepted/ref.py`, `largest_first.py`, `bisect_delete.py` | CORRECT | 0.20 s, 0.19 s, 4.99 s |
| A | `accepted/Ref.java`, `TreeMapHalls.java`, `ArrayListRemove.java` | CORRECT | 0.39 s, 0.64 s, 2.29 s |
| A | `time_limit_exceeded/brute.py`, `Brute.java` | TIMELIMIT | 10-max-random |
| A | `wrong_answer/same_index.py`, `biggest_hall_to_smallest_batch.py`, `FirstFitInputOrder.java` | WRONG-ANSWER | sample 1 |
| A | `wrong_answer/StrictlyGreater.java` | WRONG-ANSWER | 01-one-exact-fit |
| B | `accepted/ref.py`, `never_shrinks.py`, `absence_positions.py` | CORRECT | at most 0.05 s |
| B | `accepted/Ref.java`, `PrefixBinarySearch.java` | CORRECT | 0.09 s, 0.11 s |
| B | `time_limit_exceeded/brute.py`, `Brute.java` | TIMELIMIT | 13-max-all-present |
| B | `wrong_answer/p_run_plus_k.py`, `present_days_only.py`, `OffByOneLength.java` | WRONG-ANSWER | sample 1 |
| B | `wrong_answer/excuse_first_k.py` | WRONG-ANSWER | 10-excuse-later-absences |
| C | `accepted/ref.py`, `push_through.py` | CORRECT | 0.59 s, 0.58 s |
| C | `accepted/Ref.java`, `FenwickOffline.java` | CORRECT | 0.57 s, 0.58 s |
| C | `time_limit_exceeded/resort_every_day.py`, `insort_sorted_list.py`, `SortEveryDay.java`, `ArrayListInsert.java` | TIMELIMIT | 10-max-random |
| C | `wrong_answer/upper_median.py`, `average_of_middles.py`, `size_only_balance.py` | WRONG-ANSWER | sample 1 |
| C | `wrong_answer/ComparatorOverflow.java` | WRONG-ANSWER | 07-extremes |
| D | `accepted/ref.py`, `bitmask.py`, `check_each_queen.py` | CORRECT | 1.48 s, 0.28 s, 4.03 s |
| D | `accepted/Ref.java`, `CheckEachQueen.java` | CORRECT | 0.20 s, 0.25 s |
| D | `time_limit_exceeded/every_permutation.py` | TIMELIMIT | 13-n11-random |
| D | `time_limit_exceeded/EveryPermutation.java` | TIMELIMIT | 14-n12-empty |
| D | `wrong_answer/ignores_blocked.py`, `one_diagonal.py` | WRONG-ANSWER | sample 1 |
| D | `wrong_answer/blocks_stop_attacks.py` | WRONG-ANSWER | sample 2 |

## What is in each problem folder

| Path | What it is |
|---|---|
| `statement/problem.md` | Statement source; `problem.html` is rendered from it. |
| `harness/` | The I/O code. The student's function goes at the `{{STUDENT_CODE}}` marker. Generated by `tools/make_harnesses.py`. |
| `stub/`, `template/` | The starting function alone, and harness + stub as one runnable file. |
| `solutions/` | Function-only jury solutions by expected verdict. |
| `submissions/` | The same assembled into full programs (DOMjudge jury submissions). |
| `generator/` | `gen.py` (deterministic tests), `validate.py`, `brute.py` (independent checker). |
| `data/` | Tests: `.in`, `.ans`, `.desc`. |
| `TESTS.md`, `verification-report.txt` | Catalog of every test, and the result of judging every jury submission. |

## Regenerating everything

```bash
python3 tools/make_harnesses.py                       # harness/ for all four problems
python3 tools/build.py                                # template/ and submissions/
python3 A-exam-halls/generator/gen.py                 # (and B, C, D) inputs; seeds are fixed
python3 A-exam-halls/generator/validate.py A-exam-halls/data/*/*.in
python3 tools/verify.py A-exam-halls --make-ans --java-tl 4    # B, C: 2; D: 3
python3 tools/crosscheck.py A-exam-halls 100000
python3 tools/render_statements.py                    # HTML statements
python3 tools/package.py                              # DOMjudge zips + TESTS.md
```

Requirements: Python 3.9+, a JDK, and `pandoc`. `tools/screenshot.py` (optional) needs Playwright.
