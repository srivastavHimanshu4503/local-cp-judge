from __future__ import annotations

import sys
import threading

# Treats blocked squares as walls: two queens on the same column or diagonal are allowed if a
# blocked square lies between them. The statement says queens attack straight across blocked squares.
def count_placements(board: list[str]) -> int:
    n = len(board)
    queens = []

    def wall_between(r1, c1, r2, c2):
        dr = 1 if r2 > r1 else -1
        dc = (c2 > c1) - (c2 < c1)
        r, c = r1 + dr, c1 + dc
        while (r, c) != (r2, c2):
            if board[r][c] == '#':
                return True
            r, c = r + dr, c + dc
        return False

    def safe(r, c):
        for qr, qc in enumerate(queens):
            if (qc == c or abs(qc - c) == r - qr) and not wall_between(qr, qc, r, c):
                return False
        return True

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '.' and safe(r, c):
                queens.append(c)
                ways += place(r + 1)
                queens.pop()
        return ways

    return place(0)



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
