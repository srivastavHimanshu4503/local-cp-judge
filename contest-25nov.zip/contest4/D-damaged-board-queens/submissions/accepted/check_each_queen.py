from __future__ import annotations

import sys
import threading

# Row by row, checking a new square against every queen already placed (O(n) per check).
# Slower than sets or bitmasks, but still a pruned search, so it is meant to pass.
def count_placements(board: list[str]) -> int:
    n = len(board)
    queens = []                                  # queens[r] = column of the queen in row r

    def safe(r, c):
        for qr, qc in enumerate(queens):
            if qc == c or abs(qc - c) == r - qr:
                return False
        return True

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '.' and safe(r, c):
                queens.append(c)
                ways += place(r + 1)
                queens.pop()
        return ways

    return place(0)



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
