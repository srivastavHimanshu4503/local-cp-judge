from __future__ import annotations

import sys
import threading

# Row by row: n queens on n rows means exactly one queen per row. Try every usable, unattacked
# square in the current row; remember used columns and both diagonals in sets.
def count_placements(board: list[str]) -> int:
    n = len(board)
    cols, diag, anti = set(), set(), set()

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '#' or c in cols or r - c in diag or r + c in anti:
                continue
            cols.add(c); diag.add(r - c); anti.add(r + c)
            ways += place(r + 1)
            cols.remove(c); diag.remove(r - c); anti.remove(r + c)
        return ways

    return place(0)



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
