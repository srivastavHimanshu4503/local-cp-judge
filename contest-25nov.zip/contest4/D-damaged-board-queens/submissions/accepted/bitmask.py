from __future__ import annotations

import sys
import threading

# Same search with bitmasks: bit c of `cols` is set if column c is taken; the diagonal masks are
# shifted by one each row, so they always describe the squares attacked in the current row.
def count_placements(board: list[str]) -> int:
    n = len(board)
    full = (1 << n) - 1
    usable = [sum(1 << c for c in range(n) if row[c] == '.') for row in board]

    def place(r, cols, left, right):
        if r == n:
            return 1
        ways = 0
        free = usable[r] & ~(cols | left | right) & full
        while free:
            bit = free & -free
            free ^= bit
            ways += place(r + 1, cols | bit, (left | bit) << 1, (right | bit) >> 1)
        return ways

    return place(0, 0, 0, 0)



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
