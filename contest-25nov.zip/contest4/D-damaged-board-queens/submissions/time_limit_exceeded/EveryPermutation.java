import java.io.*;
import java.util.*;

// Generates every permutation of columns (one queen per row and column) and checks it only at the end.
class Solution {
    int n, ways;
    String[] board;
    int[] p;
    boolean[] used;

    void build(int r) {
        if (r == n) {
            boolean[] d = new boolean[2 * n], a = new boolean[2 * n];
            for (int i = 0; i < n; i++) {
                if (board[i].charAt(p[i]) == '#' || d[i - p[i] + n] || a[i + p[i]]) return;
                d[i - p[i] + n] = a[i + p[i]] = true;
            }
            ways++;
            return;
        }
        for (int c = 0; c < n; c++)
            if (!used[c]) { used[c] = true; p[r] = c; build(r + 1); used[c] = false; }
    }

    public int countPlacements(String[] board) {
        this.board = board;
        n = board.length;
        p = new int[n];
        used = new boolean[n];
        build(0);
        return ways;
    }
}



// ===================== DO NOT EDIT BELOW THIS LINE =====================

class Main {
    public static void main(String[] args) throws Exception {
        // Run in a thread with a large stack so deep recursion does not crash.
        final Throwable[] error = new Throwable[1];
        Thread worker = new Thread(null, () -> {
            try {
                run();
            } catch (Throwable e) {
                error[0] = e;
            }
        }, "solver", 1L << 28);
        worker.start();
        worker.join();
        if (error[0] != null) {
            error[0].printStackTrace();
            System.exit(1);
        }
    }

    private static void run() throws IOException {
        FastReader in = new FastReader(System.in);
        PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        int n = in.nextInt();
        String[] board = new String[n];
        for (int i = 0; i < n; i++) board[i] = in.next();
        out.println(new Solution().countPlacements(board));
        out.flush();
    }
}

class FastReader {
    private final InputStream in;
    private final byte[] buf = new byte[1 << 16];
    private int len = 0, ptr = 0;

    FastReader(InputStream in) { this.in = in; }

    private int read() throws IOException {
        if (ptr == len) {
            len = in.read(buf, 0, buf.length);
            ptr = 0;
            if (len <= 0) return -1;
        }
        return buf[ptr++];
    }

    int nextInt() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        boolean neg = false;
        if (c == '-') { neg = true; c = read(); }
        int r = 0;
        while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
        return neg ? -r : r;
    }

    String next() throws IOException {
        int c = read();
        while (c != -1 && c <= ' ') c = read();
        StringBuilder sb = new StringBuilder();
        while (c > ' ') { sb.append((char) c); c = read(); }
        return sb.toString();
    }
}
