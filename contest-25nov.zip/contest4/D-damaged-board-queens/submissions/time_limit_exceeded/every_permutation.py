from __future__ import annotations

import sys
import threading

# Generates every arrangement with one queen per row and per column (all n! permutations) and
# checks each one only at the end: no pruning.
from itertools import permutations


def count_placements(board: list[str]) -> int:
    n = len(board)
    ways = 0
    for p in permutations(range(n)):
        if all(board[r][p[r]] == '.' for r in range(n)) \
                and len({r - p[r] for r in range(n)}) == n and len({r + p[r] for r in range(n)}) == n:
            ways += 1
    return ways



# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
