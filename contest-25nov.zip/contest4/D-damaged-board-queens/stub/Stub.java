// ======================== WRITE YOUR CODE HERE ========================
class Solution {
    public int countPlacements(String[] board) {
        // board:  n strings of length n; board[r].charAt(c) is '.' (usable) or '#' (blocked)
        // return: the number of ways to place n queens on usable squares so that no two attack each other
        return 0;
    }
}
