"""Generate sample + secret inputs for Problem D (Queens on a Damaged Board). Deterministic."""
import pathlib
import random
import shutil

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAXN = 12
rng = random.Random(20261128)


def write(kind, name, board, desc):
    n = len(board)
    assert 1 <= n <= MAXN and all(len(row) == n and set(row) <= set(".#") for row in board)
    d = ROOT / "data" / kind
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.in").write_text(f"{n}\n" + "\n".join(board) + "\n")
    (d / f"{name}.desc").write_text(desc + "\n")


def empty(n):
    return [["."] * n for _ in range(n)]


def rows(grid):
    return ["".join(r) for r in grid]


def random_board(n, density):
    return rows([["#" if rng.random() < density else "." for _ in range(n)] for _ in range(n)])


def main():
    shutil.rmtree(ROOT / "data", ignore_errors=True)
    write("sample", "1", [".#..", "....", "....", "...."], "Sample 1: one blocked square removes one of the two 4x4 placements")
    write("sample", "2", [".#..", "#...", "....", "...."], "Sample 2: no placement left; a blocked square between two queens does not protect them")

    S = "secret"
    write(S, "01-n1-usable", ["."], "1x1 usable square: one placement")
    write(S, "02-n1-blocked", ["#"], "1x1 blocked square: zero")
    write(S, "03-n2-empty", ["..", ".."], "2x2: no placement exists")
    write(S, "04-n3-empty", ["...", "...", "..."], "3x3: no placement exists")
    write(S, "05-n4-empty", ["...."] * 4, "4x4 with no blocked squares: 2")
    write(S, "06-n8-empty", ["........"] * 8, "8x8 with no blocked squares: 92")
    g = empty(8)
    for r, c in [(0, 3), (2, 5), (3, 1), (5, 6), (6, 2), (7, 0)]:
        g[r][c] = "#"
    write(S, "07-n8-scattered", rows(g), "8x8 with six blocked squares")
    g = empty(6); g[3] = ["#"] * 6
    write(S, "08-blocked-row", rows(g), "a fully blocked row: zero")
    g = empty(6)
    for r in range(6):
        g[r][4] = "#"
    write(S, "09-blocked-column", rows(g), "a fully blocked column: zero")
    g = empty(5); g[1][2] = "#"
    write(S, "10-n5-attack-across-block", rows(g),
          "5x5 with one blocked square: treating it as a wall wrongly allows extra placements")
    g = empty(6)
    for r, c in [(1, 1), (2, 2), (3, 3), (4, 4), (2, 0), (0, 3)]:
        g[r][c] = "#"
    write(S, "11-n6-walls-on-diagonal", rows(g), "blocked squares sitting between possible queens on a diagonal")
    write(S, "12-n10-random", random_board(10, 0.10), "10x10, about 10% blocked")
    write(S, "13-n11-random", random_board(11, 0.05), "11x11, about 5% blocked")

    write(S, "14-n12-empty", ["." * 12] * 12, "12x12 with no blocked squares: the largest search (14200 placements)")
    g = empty(12); g[5][7] = "#"
    write(S, "15-n12-one-block", rows(g), "12x12 with one blocked square")
    write(S, "16-n12-light", random_board(12, 0.08), "12x12, about 8% blocked")
    write(S, "17-n12-medium", random_board(12, 0.20), "12x12, about 20% blocked")
    write(S, "18-n12-heavy", random_board(12, 0.40), "12x12, about 40% blocked")
    g = empty(12)
    for i in range(12):
        g[i][i] = "#"
    write(S, "19-n12-main-diagonal", rows(g), "12x12 with the main diagonal blocked")
    g = empty(12)
    for i in range(12):
        g[0][i] = g[11][i] = g[i][0] = g[i][11] = "#" if i % 3 == 0 else "."
    write(S, "20-n12-border-pattern", rows(g), "12x12 with every third border square blocked")
    g = empty(12)
    for r in range(4, 8):
        for c in range(4, 8):
            g[r][c] = "#"
    write(S, "21-n12-centre-hole", rows(g), "12x12 with the central 4x4 block blocked")
    g = empty(12)
    for r in range(12):
        g[r][(5 * r + 3) % 12] = "#"
    write(S, "22-n12-scattered-one-per-row", rows(g), "12x12 with one blocked square in every row and column")


if __name__ == "__main__":
    main()
