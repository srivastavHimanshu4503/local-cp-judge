"""Strict input validator for Problem D. Usage: python3 validate.py file.in [...]"""
import re
import sys


def check(path):
    raw = open(path, "rb").read()
    assert raw.endswith(b"\n"), "missing final newline"
    lines = raw[:-1].split(b"\n")
    assert re.fullmatch(rb"[1-9][0-9]*", lines[0]), "bad n"
    n = int(lines[0])
    assert 1 <= n <= 12 and len(lines) == 1 + n, "wrong number of rows"
    for row in lines[1:]:
        assert len(row) == n and re.fullmatch(rb"[.#]+", row), "bad row"


for p in sys.argv[1:]:
    check(p)
print(f"validated {len(sys.argv) - 1} files")
