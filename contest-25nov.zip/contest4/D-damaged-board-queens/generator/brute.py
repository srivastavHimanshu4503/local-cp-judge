"""Independent checker for Problem D.

* n <= 10: tries every permutation of columns (one queen per row and column) and checks it fully.
* empty boards with n = 11 or 12: certifies the .ans against the known N-Queens counts (2680, 14200).
* otherwise exits with status 3 (skipped).
"""
import sys
from itertools import permutations

d = open(sys.argv[1]).read().split()
n = int(d[0])
board = d[1:1 + n]
if n <= 10:
    ways = 0
    for p in permutations(range(n)):
        if all(board[r][p[r]] == "." for r in range(n)) \
                and all(abs(p[a] - p[b]) != b - a for a in range(n) for b in range(a + 1, n)):
            ways += 1
    print(ways)
elif all(row == "." * n for row in board):
    known = {11: 2680, 12: 14200}
    assert int(open(sys.argv[2]).read()) == known[n], "empty-board count differs from the known value"
    sys.exit(4)
else:
    sys.exit(3)
