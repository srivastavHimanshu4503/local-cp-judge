// Generates every permutation of columns (one queen per row and column) and checks it only at the end.
class Solution {
    int n, ways;
    String[] board;
    int[] p;
    boolean[] used;

    void build(int r) {
        if (r == n) {
            boolean[] d = new boolean[2 * n], a = new boolean[2 * n];
            for (int i = 0; i < n; i++) {
                if (board[i].charAt(p[i]) == '#' || d[i - p[i] + n] || a[i + p[i]]) return;
                d[i - p[i] + n] = a[i + p[i]] = true;
            }
            ways++;
            return;
        }
        for (int c = 0; c < n; c++)
            if (!used[c]) { used[c] = true; p[r] = c; build(r + 1); used[c] = false; }
    }

    public int countPlacements(String[] board) {
        this.board = board;
        n = board.length;
        p = new int[n];
        used = new boolean[n];
        build(0);
        return ways;
    }
}
