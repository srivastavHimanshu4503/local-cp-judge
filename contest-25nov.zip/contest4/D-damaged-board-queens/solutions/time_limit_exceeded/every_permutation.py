# Generates every arrangement with one queen per row and per column (all n! permutations) and
# checks each one only at the end: no pruning.
from itertools import permutations


def count_placements(board: list[str]) -> int:
    n = len(board)
    ways = 0
    for p in permutations(range(n)):
        if all(board[r][p[r]] == '.' for r in range(n)) \
                and len({r - p[r] for r in range(n)}) == n and len({r + p[r] for r in range(n)}) == n:
            ways += 1
    return ways
