# Treats blocked squares as walls: two queens on the same column or diagonal are allowed if a
# blocked square lies between them. The statement says queens attack straight across blocked squares.
def count_placements(board: list[str]) -> int:
    n = len(board)
    queens = []

    def wall_between(r1, c1, r2, c2):
        dr = 1 if r2 > r1 else -1
        dc = (c2 > c1) - (c2 < c1)
        r, c = r1 + dr, c1 + dc
        while (r, c) != (r2, c2):
            if board[r][c] == '#':
                return True
            r, c = r + dr, c + dc
        return False

    def safe(r, c):
        for qr, qc in enumerate(queens):
            if (qc == c or abs(qc - c) == r - qr) and not wall_between(qr, qc, r, c):
                return False
        return True

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '.' and safe(r, c):
                queens.append(c)
                ways += place(r + 1)
                queens.pop()
        return ways

    return place(0)
