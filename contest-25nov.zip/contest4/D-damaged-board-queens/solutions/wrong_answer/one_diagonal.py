# Checks columns and the r - c diagonals, but forgets the r + c diagonals.
def count_placements(board: list[str]) -> int:
    n = len(board)
    cols, diag = set(), set()

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '#' or c in cols or r - c in diag:
                continue
            cols.add(c); diag.add(r - c)
            ways += place(r + 1)
            cols.remove(c); diag.remove(r - c)
        return ways

    return place(0)
