// Row by row, checking a new square against every queen already placed (O(n) per check).
class Solution {
    int n;
    String[] board;
    int[] queens;

    boolean safe(int r, int c) {
        for (int qr = 0; qr < r; qr++)
            if (queens[qr] == c || Math.abs(queens[qr] - c) == r - qr) return false;
        return true;
    }

    int place(int r) {
        if (r == n) return 1;
        int ways = 0;
        for (int c = 0; c < n; c++)
            if (board[r].charAt(c) == '.' && safe(r, c)) {
                queens[r] = c;
                ways += place(r + 1);
            }
        return ways;
    }

    public int countPlacements(String[] board) {
        this.board = board;
        n = board.length;
        queens = new int[n];
        return place(0);
    }
}
