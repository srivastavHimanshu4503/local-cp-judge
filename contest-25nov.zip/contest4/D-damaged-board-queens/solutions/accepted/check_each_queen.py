# Row by row, checking a new square against every queen already placed (O(n) per check).
# Slower than sets or bitmasks, but still a pruned search, so it is meant to pass.
def count_placements(board: list[str]) -> int:
    n = len(board)
    queens = []                                  # queens[r] = column of the queen in row r

    def safe(r, c):
        for qr, qc in enumerate(queens):
            if qc == c or abs(qc - c) == r - qr:
                return False
        return True

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '.' and safe(r, c):
                queens.append(c)
                ways += place(r + 1)
                queens.pop()
        return ways

    return place(0)
