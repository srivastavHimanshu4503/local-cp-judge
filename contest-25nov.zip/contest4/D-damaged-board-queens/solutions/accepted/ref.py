# Row by row: n queens on n rows means exactly one queen per row. Try every usable, unattacked
# square in the current row; remember used columns and both diagonals in sets.
def count_placements(board: list[str]) -> int:
    n = len(board)
    cols, diag, anti = set(), set(), set()

    def place(r):
        if r == n:
            return 1
        ways = 0
        for c in range(n):
            if board[r][c] == '#' or c in cols or r - c in diag or r + c in anti:
                continue
            cols.add(c); diag.add(r - c); anti.add(r + c)
            ways += place(r + 1)
            cols.remove(c); diag.remove(r - c); anti.remove(r + c)
        return ways

    return place(0)
