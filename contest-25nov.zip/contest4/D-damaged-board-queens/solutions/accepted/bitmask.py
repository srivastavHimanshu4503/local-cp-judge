# Same search with bitmasks: bit c of `cols` is set if column c is taken; the diagonal masks are
# shifted by one each row, so they always describe the squares attacked in the current row.
def count_placements(board: list[str]) -> int:
    n = len(board)
    full = (1 << n) - 1
    usable = [sum(1 << c for c in range(n) if row[c] == '.') for row in board]

    def place(r, cols, left, right):
        if r == n:
            return 1
        ways = 0
        free = usable[r] & ~(cols | left | right) & full
        while free:
            bit = free & -free
            free ^= bit
            ways += place(r + 1, cols | bit, (left | bit) << 1, (right | bit) >> 1)
        return ways

    return place(0, 0, 0, 0)
