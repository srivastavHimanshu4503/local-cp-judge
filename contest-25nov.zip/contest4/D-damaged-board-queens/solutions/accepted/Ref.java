class Solution {
    int n;
    String[] board;
    boolean[] col, diag, anti;

    int place(int r) {
        if (r == n) return 1;
        int ways = 0;
        for (int c = 0; c < n; c++) {
            if (board[r].charAt(c) == '#' || col[c] || diag[r - c + n - 1] || anti[r + c]) continue;
            col[c] = diag[r - c + n - 1] = anti[r + c] = true;
            ways += place(r + 1);
            col[c] = diag[r - c + n - 1] = anti[r + c] = false;
        }
        return ways;
    }

    public int countPlacements(String[] board) {
        this.board = board;
        n = board.length;
        col = new boolean[n];
        diag = new boolean[2 * n - 1];
        anti = new boolean[2 * n - 1];
        return place(0);
    }
}
