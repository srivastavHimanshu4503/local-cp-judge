# Tests for D. Queens on a Damaged Board

| Test | What it checks | Expected output |
|---|---|---|
| `sample/1` | Sample 1: one blocked square removes one of the two 4x4 placements | `1` |
| `sample/2` | Sample 2: no placement left; a blocked square between two queens does not protect them | `0` |
| `secret/01-n1-usable` | 1x1 usable square: one placement | `1` |
| `secret/02-n1-blocked` | 1x1 blocked square: zero | `0` |
| `secret/03-n2-empty` | 2x2: no placement exists | `0` |
| `secret/04-n3-empty` | 3x3: no placement exists | `0` |
| `secret/05-n4-empty` | 4x4 with no blocked squares: 2 | `2` |
| `secret/06-n8-empty` | 8x8 with no blocked squares: 92 | `92` |
| `secret/07-n8-scattered` | 8x8 with six blocked squares | `45` |
| `secret/08-blocked-row` | a fully blocked row: zero | `0` |
| `secret/09-blocked-column` | a fully blocked column: zero | `0` |
| `secret/10-n5-attack-across-block` | 5x5 with one blocked square: treating it as a wall wrongly allows extra placements | `8` |
| `secret/11-n6-walls-on-diagonal` | blocked squares sitting between possible queens on a diagonal | `2` |
| `secret/12-n10-random` | 10x10, about 10% blocked | `138` |
| `secret/13-n11-random` | 11x11, about 5% blocked | `1725` |
| `secret/14-n12-empty` | 12x12 with no blocked squares: the largest search (14200 placements) | `14200` |
| `secret/15-n12-one-block` | 12x12 with one blocked square | `13260` |
| `secret/16-n12-light` | 12x12, about 8% blocked | `4294` |
| `secret/17-n12-medium` | 12x12, about 20% blocked | `1222` |
| `secret/18-n12-heavy` | 12x12, about 40% blocked | `47` |
| `secret/19-n12-main-diagonal` | 12x12 with the main diagonal blocked | `2760` |
| `secret/20-n12-border-pattern` | 12x12 with every third border square blocked | `3024` |
| `secret/21-n12-centre-hole` | 12x12 with the central 4x4 block blocked | `2028` |
| `secret/22-n12-scattered-one-per-row` | 12x12 with one blocked square in every row and column | `4210` |
