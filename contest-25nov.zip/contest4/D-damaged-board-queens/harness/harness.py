from __future__ import annotations

import sys
import threading

# {{STUDENT_CODE}}


# ===================== DO NOT EDIT BELOW THIS LINE =====================

def _main() -> None:
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    board = [data[1 + i].decode() for i in range(n)]
    print(count_placements(board))


def _run() -> None:
    # Run in a thread with a large stack so deep recursion does not crash.
    sys.setrecursionlimit(1 << 20)
    threading.stack_size(1 << 29)
    failed = []

    def target() -> None:
        try:
            _main()
        except BaseException:
            import traceback
            traceback.print_exc()
            failed.append(True)

    worker = threading.Thread(target=target)
    worker.start()
    worker.join()
    sys.stdout.flush()
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    _run()
