# D. Queens on a Damaged Board

*Time limit: 3 seconds for Java, 9 seconds for Python. Memory limit: 1024 MB.*

You have an *n* × *n* chessboard. Some of its squares are damaged (`#`); the rest are usable (`.`).

Count the ways to place ***n* queens** on usable squares so that **no two queens attack each other**.

- Two queens attack each other if they are in the same row, the same column, or on the same diagonal (in either direction).
- A queen may not stand on a damaged square, but **damaged squares do not stop attacks**. Two queens in the same column or on the same diagonal attack each other even if damaged squares lie between them.
- Two placements are different if some square has a queen in one of them and not in the other.

## What you write

You only write **one function**. The code that reads the input and prints the answer is already provided.

**Python**

```python
def count_placements(board: list[str]) -> int:
```

**Java**

```java
class Solution {
    public int countPlacements(String[] board) { ... }
}
```

- `board` contains *n* strings of length *n*. `board[r][c]` (Java: `board[r].charAt(c)`) is the square in row *r*, column *c*: `.` if usable, `#` if damaged.
- Return the number of placements.

## Input format

- The first line contains one integer *n*.
- Each of the next *n* lines contains a string of *n* characters, each `.` or `#`: one row of the board, from top to bottom.

## Output format

One integer: the number of placements.

## Constraints

- 1 ≤ *n* ≤ 12

## Sample 1

**Input**

```text
4
.#..
....
....
....
```

**Output**

```text
1
```

**Explanation.** On an undamaged 4 × 4 board there are exactly two placements. Listing the column of the queen in rows 1, 2, 3 and 4, they are (2, 4, 1, 3) and (3, 1, 4, 2). The first one needs the damaged square in row 1, column 2, so only the second one remains.

## Sample 2

**Input**

```text
4
.#..
#...
....
....
```

**Output**

```text
0
```

**Explanation.** The first placement above is still ruled out by the damaged square in row 1, column 2, and the second needs the damaged square in row 2, column 1. So neither placement remains.

Queens in columns (1, 4, 1, 3) of rows 1 to 4 would avoid both damaged squares. But the queens in rows 1 and 3 share column 1, and the damaged square between them does not protect them, so this is not a valid placement.

> **Testing your code:** copy a sample input exactly as shown above and paste it into the custom input box.
