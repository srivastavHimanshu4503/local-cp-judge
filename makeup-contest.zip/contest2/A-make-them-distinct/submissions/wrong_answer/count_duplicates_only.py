import sys

# ---------------- your code starts here ----------------
# Bug: fixes each group of equal values separately, ignoring that raised values can collide with later ones.
from collections import Counter


def solve(n, a):
    return sum(c * (c - 1) // 2 for c in Counter(a).values())
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
