import sys

# ---------------- your code starts here ----------------
# Bug: assumes the final values must be consecutive, starting from the minimum.
def solve(n, a):
    a.sort()
    return sum(max(0, a[0] + i - a[i]) for i in range(n))
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
