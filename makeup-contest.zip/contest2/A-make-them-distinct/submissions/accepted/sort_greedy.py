import sys

# ---------------- your code starts here ----------------
def solve(n, a):
    a.sort()
    moves = 0
    prev = 0  # all values are >= 1
    for x in a:
        target = max(x, prev + 1)
        moves += target - x
        prev = target
    return moves
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
