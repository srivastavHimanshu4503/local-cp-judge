import sys

# ---------------- your code starts here ----------------
# Correct but O(answer): bump each value until it is free.
def solve(n, a):
    used = set()
    moves = 0
    for x in a:
        while x in used:
            x += 1
            moves += 1
        used.add(x)
    return moves
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
