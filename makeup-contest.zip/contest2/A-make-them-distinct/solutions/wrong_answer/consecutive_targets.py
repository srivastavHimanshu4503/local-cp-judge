# Bug: assumes the final values must be consecutive, starting from the minimum.
def solve(n, a):
    a.sort()
    return sum(max(0, a[0] + i - a[i]) for i in range(n))
