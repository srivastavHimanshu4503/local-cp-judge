    // Bug: keeps the total in an int.
    static long solve(int n, int[] a) {
        Arrays.sort(a);
        int moves = 0, prev = 0;
        for (int x : a) {
            int target = Math.max(x, prev + 1);
            moves += target - x;
            prev = target;
        }
        return moves;
    }
