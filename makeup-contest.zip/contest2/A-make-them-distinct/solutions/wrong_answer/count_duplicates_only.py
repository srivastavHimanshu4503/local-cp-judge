# Bug: fixes each group of equal values separately, ignoring that raised values can collide with later ones.
from collections import Counter


def solve(n, a):
    return sum(c * (c - 1) // 2 for c in Counter(a).values())
