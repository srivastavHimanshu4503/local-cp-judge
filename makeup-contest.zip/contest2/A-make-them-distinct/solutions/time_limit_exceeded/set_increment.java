    // Correct but O(answer): bump each value until it is free.
    static long solve(int n, int[] a) {
        HashSet<Long> used = new HashSet<>();
        long moves = 0;
        for (int v : a) {
            long x = v;
            while (used.contains(x)) { x++; moves++; }
            used.add(x);
        }
        return moves;
    }
