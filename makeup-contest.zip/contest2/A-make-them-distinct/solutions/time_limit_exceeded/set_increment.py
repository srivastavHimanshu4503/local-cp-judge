# Correct but O(answer): bump each value until it is free.
def solve(n, a):
    used = set()
    moves = 0
    for x in a:
        while x in used:
            x += 1
            moves += 1
        used.add(x)
    return moves
