def solve(n, a):
    a.sort()
    moves = 0
    prev = 0  # all values are >= 1
    for x in a:
        target = max(x, prev + 1)
        moves += target - x
        prev = target
    return moves
