    static long solve(int n, int[] a) {
        Arrays.sort(a);
        long moves = 0, prev = 0;
        for (int x : a) {
            long target = Math.max(x, prev + 1);
            moves += target - x;
            prev = target;
        }
        return moves;
    }
