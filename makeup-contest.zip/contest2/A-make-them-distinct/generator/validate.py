"""Strict input validator for Problem A. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+\n\d+( \d+)*\n", data), "bad format"
lines = data.split("\n")
n = int(lines[0])
assert 1 <= n <= 200_000, "n out of range"
a = list(map(int, lines[1].split()))
assert len(a) == n, "wrong count"
assert all(1 <= x <= 10**9 for x in a), "value out of range"
print("OK")
