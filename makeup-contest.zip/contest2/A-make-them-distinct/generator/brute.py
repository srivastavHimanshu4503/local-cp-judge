"""Independent checker for small tests: exhaustive search over every assignment of distinct
final values (each element may take any free value >= its original). Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n = int(data[0])
a = [int(x) for x in data[1:1 + n]]
assert n <= 10 and max(a) <= 20, "too big for brute"
top = max(a) + n
best = [None]


def go(i, used, cost):
    if best[0] is not None and cost >= best[0]:
        return
    if i == n:
        best[0] = cost
        return
    for v in range(a[i], top + 1):
        if v not in used:
            used.add(v)
            go(i + 1, used, cost + v - a[i])
            used.remove(v)


go(0, set(), 0)
print(best[0])
