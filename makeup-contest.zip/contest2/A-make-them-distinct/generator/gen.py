"""Deterministic test generator for Problem A (Make Them Distinct). Usage: python3 gen.py <problem_dir>"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXN = 200_000
MAXV = 10**9

SAMPLES = [
    ("5\n3 1 3 2 1\n", "Statement example 1: duplicates push into each other, answer 5"),
    ("4\n10 1 10 1\n", "Statement example 2: two separate groups, final values need not be consecutive"),
    ("4\n2 2 2 2\n", "Statement example 3: all equal, 0 + 1 + 2 + 3 = 6"),
]


def fmt(a):
    return f"{len(a)}\n" + " ".join(map(str, a)) + "\n"


def secret_tests():
    rng = random.Random(20261024)
    t = []
    t.append((fmt([7]), "n = 1: answer 0"))
    t.append((fmt([MAXV, MAXV]), "two copies of 10^9: one becomes 10^9 + 1"))
    t.append((fmt([5, 4, 3, 2, 1]), "already distinct, reverse sorted: answer 0"))
    for i in range(6):
        n = rng.randint(2, 9)
        t.append((fmt([rng.randint(1, 8) for _ in range(n)]), f"small random #{i + 1} (n = {n}, values <= 8)"))
    a = rng.sample(range(1, MAXV + 1), MAXN)
    t.append((fmt(a), "max n, all distinct already: answer 0"))
    t.append((fmt([MAXV] * MAXN), "max n, all equal to 10^9: answer n(n-1)/2 = 19999900000 (needs long)"))
    t.append((fmt([1] * MAXN), "max n, all equal to 1"))
    a = [rng.randint(1, 1000) for _ in range(MAXN)]
    t.append((fmt(a), "max n, values in 1..1000: one huge cascade"))
    a = sorted(rng.randint(1, 50_000) for _ in range(MAXN))
    t.append((fmt(a), "max n, values in 1..50000, sorted"))
    a = sorted((rng.randint(1, 50_000) for _ in range(MAXN)), reverse=True)
    t.append((fmt(a), "max n, values in 1..50000, reverse sorted"))
    a = [rng.randint(1, MAXV) for _ in range(MAXN)]
    t.append((fmt(a), "max n, random values up to 10^9 (few duplicates)"))
    # groups of duplicates spaced so that raised values run into the next group
    a = []
    base = 1
    while len(a) < MAXN:
        c = rng.randint(2, 60)
        a += [base] * c
        base += rng.randint(1, c)
    a = a[:MAXN]
    rng.shuffle(a)
    t.append((fmt(a), "max n, duplicate groups close enough that raised values collide with later groups"))
    # groups far apart (example 2 scaled up)
    a = []
    for g in range(1000):
        a += [g * 10**6 + 1] * 200
    rng.shuffle(a)
    t.append((fmt(a), "1000 groups of 200 equal values, far apart: each group costs 19900"))
    a = [MAXV - rng.randint(0, 100) for _ in range(MAXN)]
    t.append((fmt(a), "max n, values in [10^9 - 100, 10^9]: final values go far above 10^9"))
    a = [rng.choice([1, MAXV]) for _ in range(MAXN)]
    t.append((fmt(a), "max n, only the values 1 and 10^9"))
    a = [rng.randint(1, MAXN) for _ in range(MAXN)]
    t.append((fmt(a), "max n, values in 1..n"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
