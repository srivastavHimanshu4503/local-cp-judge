# Problem A — Make Them Distinct: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 5 | Statement example 1: duplicates push into each other, answer 5 | `5` |
| sample/02 | n = 4 | Statement example 2: two separate groups, final values need not be consecutive | `2` |
| sample/03 | n = 4 | Statement example 3: all equal, 0 + 1 + 2 + 3 = 6 | `6` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1 | n = 1: answer 0 | `0` |
| secret/02 | n = 2 | two copies of 10^9: one becomes 10^9 + 1 | `1` |
| secret/03 | n = 5 | already distinct, reverse sorted: answer 0 | `0` |
| secret/04 | n = 4 | small random #1 (n = 4, values <= 8) | `0` |
| secret/05 | n = 2 | small random #2 (n = 2, values <= 8) | `0` |
| secret/06 | n = 7 | small random #3 (n = 7, values <= 8) | `5` |
| secret/07 | n = 6 | small random #4 (n = 6, values <= 8) | `2` |
| secret/08 | n = 2 | small random #5 (n = 2, values <= 8) | `0` |
| secret/09 | n = 4 | small random #6 (n = 4, values <= 8) | `0` |
| secret/10 | n = 200000 | max n, all distinct already: answer 0 | `0` |
| secret/11 | n = 200000 | max n, all equal to 10^9: answer n(n-1)/2 = 19999900000 (needs long) | `19999900000` |
| secret/12 | n = 200000 | max n, all equal to 1 | `19999900000` |
| secret/13 | n = 200000 | max n, values in 1..1000: one huge cascade | `19899976354` |
| secret/14 | n = 200000 | max n, values in 1..50000, sorted | `14996332344` |
| secret/15 | n = 200000 | max n, values in 1..50000, reverse sorted | `14984125334` |
| secret/16 | n = 200000 | max n, random values up to 10^9 (few duplicates) | `10` |
| secret/17 | n = 200000 | max n, duplicate groups close enough that raised values collide with later groups | `9608879538` |
| secret/18 | n = 200000 | 1000 groups of 200 equal values, far apart: each group costs 19900 | `19900000` |
| secret/19 | n = 200000 | max n, values in [10^9 - 100, 10^9]: final values go far above 10^9 | `19989901044` |
| secret/20 | n = 200000 | max n, only the values 1 and 10^9 | `9999909604` |
| secret/21 | n = 200000 | max n, values in 1..n | `30919035` |
