import sys

# ---------------- your code starts here ----------------
def solve(n, a):
    # return the minimum number of moves
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]
    sys.stdout.write(f"{solve(n, a)}\n")


main()
