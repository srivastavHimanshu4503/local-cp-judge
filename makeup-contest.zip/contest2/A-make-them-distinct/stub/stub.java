    // return the minimum number of moves
    static long solve(int n, int[] a) {
        return 0;
    }
