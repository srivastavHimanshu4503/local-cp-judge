def solve(n, a):
    # return the minimum number of moves
    return 0
