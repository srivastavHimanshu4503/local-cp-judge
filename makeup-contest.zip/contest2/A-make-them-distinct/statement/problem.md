---
title: "Problem A — Make Them Distinct"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

You are given **n** integers. In one move, you may choose any element and **increase** it by 1. Elements can never be decreased.

Find the minimum number of moves needed to make all elements **distinct**.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// return the minimum number of moves
static long solve(int n, int[] a)
```

```python
# Python
# return the minimum number of moves
def solve(n, a):
```

> **Note:** The answer can be larger than 2 × 10^10^, which does not fit in a Java `int`. Use `long`.

## Input

- The first line has one integer **n**.
- The second line has **n** integers a~1~, a~2~, …, a~n~, separated by spaces.

## Output

Print one integer: the minimum number of moves.

## Constraints

- 1 ≤ n ≤ 200 000
- 1 ≤ a~i~ ≤ 10^9^

## Example 1

Input:

```
5
3 1 3 2 1
```

Output:

```
5
```

**Explanation:** Sorted, the numbers are 1, 1, 2, 3, 3. Go left to right. Each number must end up bigger than the one before it:

| Original | Must be at least | Becomes | Moves |
|:---:|:---:|:---:|:---:|
| 1 | — | 1 | 0 |
| 1 | 2 | 2 | 1 |
| 2 | 3 | 3 | 1 |
| 3 | 4 | 4 | 1 |
| 3 | 5 | 5 | 2 |

The final values are 1, 2, 3, 4, 5, and the total is 0 + 1 + 1 + 1 + 2 = **5**.

## Example 2

Input:

```
4
10 1 10 1
```

Output:

```
2
```

**Explanation:** One of the 1s becomes 2 (1 move), and one of the 10s becomes 11 (1 move). The final values are 1, 2, 10 and 11, so the total is **2**. The two groups are far apart, so they don't affect each other.

## Example 3

Input:

```
4
2 2 2 2
```

Output:

```
6
```

**Explanation:** The four 2s must become 2, 3, 4 and 5. That takes 0 + 1 + 2 + 3 = **6** moves.
