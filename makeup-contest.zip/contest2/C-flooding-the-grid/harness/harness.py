import sys

# ---------------- your code starts here ----------------
{{STUDENT_CODE}}
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, m = int(data[0]), int(data[1])
    grid = [data[2 + i].decode() for i in range(n)]
    sys.stdout.write(f"{solve(n, m, grid)}\n")


main()
