---
title: "Problem C — Flooding the Grid"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

You are given a grid with **n** rows and **m** columns. Each cell is one of:

- `W`: water (there is exactly one such cell),
- `.`: dry land,
- `#`: a wall.

Every minute, water spreads from each wet cell to its neighbouring land cells: up, down, left and right, but not diagonally. Water never enters a wall.

Find the number of minutes until every land cell is wet. If some land cell can never get wet, print **−1**. If the grid has no land cells at all, the answer is **0**.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// grid[i].charAt(j) is the cell in row i, column j
// return the number of minutes, or -1
static int solve(int n, int m, String[] grid)
```

```python
# Python
# grid[i][j] is the cell in row i, column j
# return the number of minutes, or -1
def solve(n, m, grid):
```

## Input

- The first line has two integers **n** and **m**, separated by a space.
- Each of the next **n** lines has a string of exactly **m** characters, each `W`, `.` or `#`.

## Output

Print one integer: the number of minutes until every land cell is wet, or **−1**.

## Constraints

- 1 ≤ n, m ≤ 1000
- The grid has exactly one `W`.

## Example 1

Input:

```
3 4
W...
.#..
....
```

Output:

```
5
```

**Explanation:** This grid shows the minute at which each cell becomes wet:

```text
0 1 2 3
1 # 3 4
2 3 4 5
```

The last land cell, in the bottom-right corner, gets wet at minute **5**.

## Example 2

Input:

```
2 3
W#.
.#.
```

Output:

```
-1
```

**Explanation:** The wall in the middle column cuts the grid in two. Water reaches the cell below the `W` after 1 minute, but the two land cells in the right column can never get wet. So the answer is **−1**.

## Example 3

Input:

```
3 3
W..
##.
...
```

Output:

```
6
```

**Explanation:** The wall blocks the direct way down, so the water has to go around it:

```text
0 1 2
# # 3
6 5 4
```

The bottom-left cell is only two rows below the `W`, but it gets wet at minute **6**.
