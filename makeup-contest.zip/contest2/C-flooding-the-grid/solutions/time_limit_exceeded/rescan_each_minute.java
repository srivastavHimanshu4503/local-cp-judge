    // Correct but O(n*m*answer): every minute, scan the whole grid for cells next to water.
    static int solve(int n, int m, String[] grid) {
        char[][] g = new char[n][];
        for (int i = 0; i < n; i++) g[i] = grid[i].toCharArray();
        int minutes = 0;
        int[] buf = new int[n * m];
        while (true) {
            int cnt = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (g[i][j] == '.' && ((i > 0 && g[i - 1][j] == 'W') || (i < n - 1 && g[i + 1][j] == 'W')
                            || (j > 0 && g[i][j - 1] == 'W') || (j < m - 1 && g[i][j + 1] == 'W')))
                        buf[cnt++] = i * m + j;
            if (cnt == 0) break;
            for (int t = 0; t < cnt; t++) g[buf[t] / m][buf[t] % m] = 'W';
            minutes++;
        }
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                if (g[i][j] == '.') return -1;
        return minutes;
    }
