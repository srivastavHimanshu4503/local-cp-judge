# Correct but O(n*m*answer): every minute, scan the whole grid for cells next to water.
def solve(n, m, grid):
    g = [list(r) for r in grid]
    minutes = 0
    while True:
        new = []
        for i in range(n):
            for j in range(m):
                if g[i][j] == '.' and ((i > 0 and g[i - 1][j] == 'W') or (i < n - 1 and g[i + 1][j] == 'W')
                                       or (j > 0 and g[i][j - 1] == 'W') or (j < m - 1 and g[i][j + 1] == 'W')):
                    new.append((i, j))
        if not new:
            break
        for i, j in new:
            g[i][j] = 'W'
        minutes += 1
    if any('.' in row for row in g):
        return -1
    return minutes
