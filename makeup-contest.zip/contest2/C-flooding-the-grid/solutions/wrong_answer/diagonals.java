    // Bug: water also spreads diagonally (8 neighbours).
    static int solve(int n, int m, String[] grid) {
        int[][] dist = new int[n][m];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++) {
                dist[i][j] = -1;
                if (grid[i].charAt(j) == 'W') { dist[i][j] = 0; q.add(new int[]{i, j}); }
            }
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++) {
                    int x = c[0] + dx, y = c[1] + dy;
                    if (x >= 0 && x < n && y >= 0 && y < m && grid[x].charAt(y) == '.' && dist[x][y] == -1) {
                        dist[x][y] = dist[c[0]][c[1]] + 1;
                        q.add(new int[]{x, y});
                    }
                }
        }
        int best = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                if (grid[i].charAt(j) == '.') {
                    if (dist[i][j] == -1) return -1;
                    best = Math.max(best, dist[i][j]);
                }
        return best;
    }
