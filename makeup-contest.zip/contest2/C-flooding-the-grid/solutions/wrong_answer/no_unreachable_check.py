# Bug: never checks for land the water cannot reach.
from collections import deque


def solve(n, m, grid):
    dist = [[-1] * m for _ in range(n)]
    q = deque()
    for i in range(n):
        for j in range(m):
            if grid[i][j] == 'W':
                dist[i][j] = 0
                q.append((i, j))
    best = 0
    while q:
        i, j = q.popleft()
        best = max(best, dist[i][j])
        for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            x, y = i + di, j + dj
            if 0 <= x < n and 0 <= y < m and grid[x][y] == '.' and dist[x][y] == -1:
                dist[x][y] = dist[i][j] + 1
                q.append((x, y))
    return best
