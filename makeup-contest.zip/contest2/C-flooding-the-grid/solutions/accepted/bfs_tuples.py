# The way most students will write it: 2D dist list, (row, col) tuples, direction list.
from collections import deque


def solve(n, m, grid):
    dist = [[-1] * m for _ in range(n)]
    q = deque()
    for i in range(n):
        for j in range(m):
            if grid[i][j] == 'W':
                dist[i][j] = 0
                q.append((i, j))
    while q:
        i, j = q.popleft()
        for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            x, y = i + di, j + dj
            if 0 <= x < n and 0 <= y < m and grid[x][y] == '.' and dist[x][y] == -1:
                dist[x][y] = dist[i][j] + 1
                q.append((x, y))
    best = 0
    for i in range(n):
        for j in range(m):
            if grid[i][j] == '.':
                if dist[i][j] == -1:
                    return -1
                best = max(best, dist[i][j])
    return best
