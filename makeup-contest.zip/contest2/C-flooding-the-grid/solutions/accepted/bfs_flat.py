from collections import deque


def solve(n, m, grid):
    g = "".join(grid)
    dist = [-1] * (n * m)
    start = g.index('W')
    dist[start] = 0
    q = deque([start])
    while q:
        u = q.popleft()
        i, j = divmod(u, m)
        d = dist[u] + 1
        if i > 0 and g[u - m] == '.' and dist[u - m] < 0:
            dist[u - m] = d; q.append(u - m)
        if i < n - 1 and g[u + m] == '.' and dist[u + m] < 0:
            dist[u + m] = d; q.append(u + m)
        if j > 0 and g[u - 1] == '.' and dist[u - 1] < 0:
            dist[u - 1] = d; q.append(u - 1)
        if j < m - 1 and g[u + 1] == '.' and dist[u + 1] < 0:
            dist[u + 1] = d; q.append(u + 1)
    best = 0
    for u in range(n * m):
        if g[u] == '.':
            if dist[u] < 0:
                return -1
            if dist[u] > best:
                best = dist[u]
    return best
