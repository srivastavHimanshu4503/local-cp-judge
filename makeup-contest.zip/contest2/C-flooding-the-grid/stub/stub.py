def solve(n, m, grid):
    # grid[i][j] is the cell in row i, column j
    # return the number of minutes, or -1
    return 0
