    // grid[i].charAt(j) is the cell in row i, column j
    // return the number of minutes, or -1
    static int solve(int n, int m, String[] grid) {
        return 0;
    }
