import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    static int solve(int n, int m, String[] grid) {
        int[][] dist = new int[n][m];
        ArrayDeque<int[]> q = new ArrayDeque<>();
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++) {
                dist[i][j] = -1;
                if (grid[i].charAt(j) == 'W') { dist[i][j] = 0; q.add(new int[]{i, j}); }
            }
        int[] di = {1, -1, 0, 0}, dj = {0, 0, 1, -1};
        while (!q.isEmpty()) {
            int[] c = q.poll();
            for (int d = 0; d < 4; d++) {
                int x = c[0] + di[d], y = c[1] + dj[d];
                if (x >= 0 && x < n && y >= 0 && y < m && grid[x].charAt(y) == '.' && dist[x][y] == -1) {
                    dist[x][y] = dist[c[0]][c[1]] + 1;
                    q.add(new int[]{x, y});
                }
            }
        }
        int best = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                if (grid[i].charAt(j) == '.') {
                    if (dist[i][j] == -1) return -1;
                    best = Math.max(best, dist[i][j]);
                }
        return best;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        String[] grid = new String[n];
        for (int i = 0; i < n; i++) grid[i] = in.next();
        System.out.println(solve(n, m, grid));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
