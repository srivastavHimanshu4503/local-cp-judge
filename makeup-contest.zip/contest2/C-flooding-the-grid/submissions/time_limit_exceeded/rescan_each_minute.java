import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // Correct but O(n*m*answer): every minute, scan the whole grid for cells next to water.
    static int solve(int n, int m, String[] grid) {
        char[][] g = new char[n][];
        for (int i = 0; i < n; i++) g[i] = grid[i].toCharArray();
        int minutes = 0;
        int[] buf = new int[n * m];
        while (true) {
            int cnt = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (g[i][j] == '.' && ((i > 0 && g[i - 1][j] == 'W') || (i < n - 1 && g[i + 1][j] == 'W')
                            || (j > 0 && g[i][j - 1] == 'W') || (j < m - 1 && g[i][j + 1] == 'W')))
                        buf[cnt++] = i * m + j;
            if (cnt == 0) break;
            for (int t = 0; t < cnt; t++) g[buf[t] / m][buf[t] % m] = 'W';
            minutes++;
        }
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                if (g[i][j] == '.') return -1;
        return minutes;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        String[] grid = new String[n];
        for (int i = 0; i < n; i++) grid[i] = in.next();
        System.out.println(solve(n, m, grid));
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
