# Problem C — Flooding the Grid: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | 3 x 4 | Statement example 1: single source, last cell wet at minute 5 | `5` |
| sample/02 | 2 x 3 | Statement example 2: right column unreachable, -1 | `-1` |
| sample/03 | 3 x 3 | Statement example 3: water goes around the wall, answer 6 | `6` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | 1 x 1 | 1 x 1 grid, only the water cell: answer 0 | `0` |
| secret/02 | 2 x 4 | no land cells at all: answer 0 | `0` |
| secret/03 | 1 x 1000 | 1 x 1000, W at the left end: answer 999 | `999` |
| secret/04 | 1 x 1000 | 1 x 1000, W in the middle: answer 500 | `500` |
| secret/05 | 1000 x 1 | 1000 x 1 column, W at row 301: answer 699 | `699` |
| secret/06 | 1 x 5 | single row, wall blocks the right part: -1 | `-1` |
| secret/07 | 1 x 7 | small random #1 (1 x 7) | `3` |
| secret/08 | 3 x 6 | small random #2 (3 x 6) | `6` |
| secret/09 | 2 x 3 | small random #3 (2 x 3) | `2` |
| secret/10 | 3 x 3 | small random #4 (3 x 3) | `3` |
| secret/11 | 1 x 2 | small random #5 (1 x 2) | `1` |
| secret/12 | 1000 x 1000 | 1000 x 1000 open grid, W in the top-left corner: answer 1998 | `1998` |
| secret/13 | 1000 x 1000 | 1000 x 1000 open grid, W at (501, 501): answer 1000 | `1000` |
| secret/14 | 1000 x 1000 | 1000 x 1000 snake maze, W at the start: path of about 500000 cells (rescanning every minute times out) | `500499` |
| secret/15 | 1000 x 1000 | snake maze whose last row is sealed, with one land cell inside it: -1 | `-1` |
| secret/16 | 1000 x 1000 | a full wall across row 601 splits the grid: -1 | `-1` |
| secret/17 | 1000 x 1000 | 1000 x 1000 random, 10% walls, unreachable land turned into walls | `1169` |
| secret/18 | 1000 x 1000 | 1000 x 1000 random, 30% walls, unreachable land turned into walls | `1286` |
| secret/19 | 1000 x 1000 | 1000 x 1000 random, 38% walls, unreachable land turned into walls | `1315` |
| secret/20 | 1000 x 1000 | 1000 x 1000 random, 30% walls, some land sealed off: -1 | `-1` |
| secret/21 | 1000 x 1000 | 1000 x 1000 open grid with one land cell boxed in by 4 walls: -1 | `-1` |
| secret/22 | 1000 x 1000 | 1000 x 1000 mostly walls with a random-walk corridor carved from the W | `2172` |
| secret/23 | 2 x 1000 | 2 x 1000, W in the bottom-right: answer 1000 | `1000` |
