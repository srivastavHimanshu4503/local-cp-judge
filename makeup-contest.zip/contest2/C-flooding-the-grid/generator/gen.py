"""Deterministic test generator for Problem C (Flooding the Grid). Usage: python3 gen.py <problem_dir>"""
import os
import random
import sys
from collections import deque

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

N = 1000

SAMPLES = [
    ("3 4\nW...\n.#..\n....\n", "Statement example 1: single source, last cell wet at minute 5"),
    ("2 3\nW#.\n.#.\n", "Statement example 2: right column unreachable, -1"),
    ("3 3\nW..\n##.\n...\n", "Statement example 3: water goes around the wall, answer 6"),
]


def fmt(g):
    return f"{len(g)} {len(g[0])}\n" + "".join(r + "\n" for r in g)


def place_w(rng, g, cell=None):
    """Put the single W on a land cell (given or random)."""
    g = [list(r) for r in g]
    if cell is None:
        land = [(i, j) for i in range(len(g)) for j in range(len(g[0])) if g[i][j] == "."]
        cell = rng.choice(land)
    g[cell[0]][cell[1]] = "W"
    return ["".join(r) for r in g]


def fill_unreachable(g):
    """Turn every land cell the W cannot reach into a wall, so the answer is not -1."""
    n, m = len(g), len(g[0])
    flat = list("".join(g))
    s = flat.index("W")
    seen = bytearray(n * m)
    seen[s] = 1
    q = deque([s])
    while q:
        u = q.popleft()
        i, j = divmod(u, m)
        for v, ok in ((u - m, i > 0), (u + m, i < n - 1), (u - 1, j > 0), (u + 1, j < m - 1)):
            if ok and not seen[v] and flat[v] == ".":
                seen[v] = 1
                q.append(v)
    for u in range(n * m):
        if flat[u] == "." and not seen[u]:
            flat[u] = "#"
    return ["".join(flat[i * m:(i + 1) * m]) for i in range(n)]


def random_grid(rng, n, m, p_wall):
    return ["".join("#" if rng.random() < p_wall else "." for _ in range(m)) for _ in range(n)]


def snake(n, m):
    """Even rows open, odd rows walls with a single gap alternating between the right and left end."""
    g = []
    for i in range(n):
        if i % 2 == 0:
            g.append("." * m)
        else:
            row = ["#"] * m
            row[m - 1 if (i // 2) % 2 == 0 else 0] = "."
            g.append("".join(row))
    return g


def secret_tests():
    rng = random.Random(20261026)
    t = []
    t.append((fmt(["W"]), "1 x 1 grid, only the water cell: answer 0"))
    t.append((fmt(["W###", "####"]), "no land cells at all: answer 0"))
    t.append((fmt(["W" + "." * (N - 1)]), "1 x 1000, W at the left end: answer 999"))
    t.append((fmt(["." * 500 + "W" + "." * 499]), "1 x 1000, W in the middle: answer 500"))
    t.append((fmt(["."] * 300 + ["W"] + ["."] * 699), "1000 x 1 column, W at row 301: answer 699"))
    t.append((fmt(["W.#.."]), "single row, wall blocks the right part: -1"))
    for i in range(5):
        n, m = rng.randint(1, 7), rng.randint(1, 7)
        if n * m < 2:
            n, m = 2, 3
        g = place_w(rng, random_grid(rng, n, m, 0.25) if rng.random() < 0.5 else ["." * m] * n,
                    (rng.randrange(n), rng.randrange(m)))
        t.append((fmt(g), f"small random #{i + 1} ({n} x {m})"))
    t.append((fmt(place_w(rng, ["." * N] * N, (0, 0))), "1000 x 1000 open grid, W in the top-left corner: answer 1998"))
    t.append((fmt(place_w(rng, ["." * N] * N, (500, 500))), "1000 x 1000 open grid, W at (501, 501): answer 1000"))
    t.append((fmt(place_w(rng, snake(N, N), (0, 0))),
              "1000 x 1000 snake maze, W at the start: path of about 500000 cells (rescanning every minute times out)"))
    g = [list(r) for r in snake(N, N)]
    g[N - 2] = list("#" * N)          # seal the last row off completely ...
    g[N - 1] = list("#" * N)
    g[N - 1][N // 2] = "."            # ... except one lonely land cell
    g = place_w(rng, ["".join(r) for r in g], (0, 0))
    t.append((fmt(g), "snake maze whose last row is sealed, with one land cell inside it: -1"))
    g = ["." * N for _ in range(N)]
    g = [list(r) for r in g]
    for j in range(N):
        g[600][j] = "#"
    g = place_w(rng, ["".join(r) for r in g], (0, 0))
    t.append((fmt(g), "a full wall across row 601 splits the grid: -1"))
    for p in (0.1, 0.3, 0.38):
        g = place_w(rng, random_grid(rng, N, N, p))
        t.append((fmt(fill_unreachable(g)), f"1000 x 1000 random, {int(p * 100)}% walls, unreachable land turned into walls"))
    g = place_w(rng, random_grid(rng, N, N, 0.3))
    t.append((fmt(g), "1000 x 1000 random, 30% walls, some land sealed off: -1"))
    # a single sealed cell far from W
    g = [list("." * N) for _ in range(N)]
    for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        g[700 + di][900 + dj] = "#"
    g = place_w(rng, ["".join(r) for r in g], (5, 5))
    t.append((fmt(g), "1000 x 1000 open grid with one land cell boxed in by 4 walls: -1"))
    # mostly walls, a thin random corridor
    g = [list("#" * N) for _ in range(N)]
    i = j = 0
    g[0][0] = "."
    for _ in range(300_000):
        di, dj = rng.choice(((0, 1), (1, 0), (0, -1), (-1, 0), (0, 1), (1, 0)))
        if 0 <= i + di < N and 0 <= j + dj < N:
            i, j = i + di, j + dj
            g[i][j] = "."
    g = place_w(rng, ["".join(r) for r in g], (0, 0))
    t.append((fmt(g), "1000 x 1000 mostly walls with a random-walk corridor carved from the W"))
    g = place_w(rng, random_grid(rng, 2, N, 0.0), (1, N - 1))
    t.append((fmt(g), "2 x 1000, W in the bottom-right: answer 1000"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
