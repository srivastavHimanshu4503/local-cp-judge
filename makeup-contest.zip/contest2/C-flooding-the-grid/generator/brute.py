"""Independent checker for small grids: simulate minute by minute. Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, m = int(data[0]), int(data[1])
assert n * m <= 2000, "too big for brute"
g = [list(r) for r in data[2:2 + n]]
t = 0
while True:
    new = [(i, j) for i in range(n) for j in range(m) if g[i][j] == "."
           and any(0 <= i + a < n and 0 <= j + b < m and g[i + a][j + b] == "W"
                   for a, b in ((1, 0), (-1, 0), (0, 1), (0, -1)))]
    if not new:
        break
    for i, j in new:
        g[i][j] = "W"
    t += 1
print(-1 if any("." in r for r in g) else t)
