"""Strict input validator for Problem C. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+ \d+\n([W.#]+\n)+", data), "bad format"
lines = data.split("\n")[:-1]
n, m = map(int, lines[0].split())
assert 1 <= n <= 1000 and 1 <= m <= 1000, "size out of range"
assert len(lines) == n + 1, "wrong number of rows"
assert all(len(r) == m for r in lines[1:]), "row of wrong length"
assert sum(r.count("W") for r in lines[1:]) == 1, "need exactly one W"
print("OK")
