"""Deterministic test generator for Problem D (How Far Can You Go?). Usage: python3 gen.py <problem_dir>"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXN = 200_000
MAXQ = 200_000
MAXA = 10**9
MAXB = 10**15

SAMPLES = [
    ("5 4\n3 1 4 1 5\n1 8\n2 10\n3 3\n4 100\n", "Statement example 1: stop before the budget is exceeded, 0, and end of array"),
    ("3 3\n2 2 2\n1 6\n1 5\n3 2\n", "Statement example 2: a total exactly equal to b is allowed"),
    ("1 2\n7\n1 7\n1 6\n", "Statement example 3: single element"),
]


def fmt(a, qs):
    return f"{len(a)} {len(qs)}\n" + " ".join(map(str, a)) + "\n" + "".join(f"{l} {b}\n" for l, b in qs)


def prefix(a):
    P = [0]
    for x in a:
        P.append(P[-1] + x)
    return P


def secret_tests():
    rng = random.Random(20261027)
    t = []
    t.append((fmt([1], [(1, 1), (1, MAXB)]), "n = 1, a = 1: both answers 1"))
    t.append((fmt([MAXA], [(1, MAXA - 1), (1, MAXA), (1, MAXB)]), "n = 1, a = 10^9: answers 0, 1, 1"))
    for i in range(6):
        n = rng.randint(1, 10)
        a = [rng.randint(1, 6) for _ in range(n)]
        qs = [(rng.randint(1, n), rng.randint(1, 30)) for _ in range(rng.randint(1, 10))]
        t.append((fmt(a, qs), f"small random #{i + 1} (n = {n})"))

    a = [rng.randint(1, MAXA) for _ in range(MAXN)]
    qs = [(rng.randint(1, 100), MAXB) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "max n and q, every query starts near the beginning with budget 10^15 (walking is O(n*q))"))

    a = [MAXA] * MAXN
    qs = [(rng.randint(1, MAXN), rng.randint(1, MAXB)) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "max n and q, all elements 10^9 (prefix sums need long)"))

    a = [rng.randint(1, MAXA) for _ in range(MAXN)]
    qs = [(MAXN, rng.randint(1, 2 * MAXA)) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "every query starts at position n"))

    a = [rng.randint(10**6, MAXA) for _ in range(MAXN)]
    qs = [(rng.randint(1, MAXN), rng.randint(1, 10**6 - 1)) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "every budget is smaller than every element: all answers 0"))

    a = [rng.randint(1, MAXA) for _ in range(MAXN)]
    P = prefix(a)
    qs = []
    for _ in range(MAXQ):
        l = rng.randint(1, MAXN)
        r = rng.randint(l, MAXN)
        qs.append((l, P[r] - P[l - 1]))
    t.append((fmt(a, qs), "budgets land exactly on a prefix sum (the total may equal b)"))

    qs = []
    for _ in range(MAXQ):
        l = rng.randint(1, MAXN)
        r = rng.randint(l, MAXN)
        qs.append((l, P[r] - P[l - 1] - 1 if P[r] - P[l - 1] > 1 else 1))
    t.append((fmt(a, qs), "budgets one less than a prefix sum"))

    a = [7] * MAXN
    qs = [(rng.randint(1, MAXN), rng.randint(1, 10**7)) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "all elements equal to 7"))

    a = [rng.randint(1, 10) for _ in range(MAXN)]
    qs = [(rng.randint(1, MAXN), rng.randint(1, 2 * 10**6)) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "small elements, medium budgets: long walks"))

    a = [rng.randint(1, MAXA) for _ in range(MAXN)]
    qs = [(rng.randint(1, MAXN), rng.choice([rng.randint(1, MAXA), rng.randint(1, 10**12), MAXB])) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "max n and q random, mixed small, medium and huge budgets"))

    a = [rng.choice([1, MAXA]) for _ in range(MAXN)]
    qs = [(rng.randint(1, MAXN), rng.randint(1, 5 * MAXA)) for _ in range(MAXQ)]
    t.append((fmt(a, qs), "elements are 1 or 10^9: short and long stretches"))

    a = [rng.randint(1, MAXA) for _ in range(MAXN)]
    qs = [(1, MAXB)] * MAXQ
    t.append((fmt(a, qs), "every query is (1, 10^15): answer n every time"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
