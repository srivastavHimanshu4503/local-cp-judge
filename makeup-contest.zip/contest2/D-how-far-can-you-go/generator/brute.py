"""Independent checker for small tests: walk element by element. Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, q = int(data[0]), int(data[1])
assert n * q <= 2_000_000, "too big for brute"
a = [int(x) for x in data[2:2 + n]]
out = []
for j in range(q):
    l, b = int(data[2 + n + 2 * j]), int(data[3 + n + 2 * j])
    i, tot = l - 1, 0
    while i < n and tot + a[i] <= b:
        tot += a[i]
        i += 1
    out.append(i - (l - 1))
print("\n".join(map(str, out)))
