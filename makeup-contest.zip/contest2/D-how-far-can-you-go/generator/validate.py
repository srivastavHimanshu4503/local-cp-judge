"""Strict input validator for Problem D. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
assert re.fullmatch(r"\d+ \d+\n\d+( \d+)*\n(\d+ \d+\n)+", data), "bad format"
lines = data.split("\n")[:-1]
n, q = map(int, lines[0].split())
assert 1 <= n <= 200_000 and 1 <= q <= 200_000, "n or q out of range"
a = list(map(int, lines[1].split()))
assert len(a) == n and all(1 <= x <= 10**9 for x in a), "bad array"
assert len(lines) == q + 2, "wrong number of queries"
for ln in lines[2:]:
    l, b = map(int, ln.split())
    assert 1 <= l <= n and 1 <= b <= 10**15, f"bad query {l} {b}"
print("OK")
