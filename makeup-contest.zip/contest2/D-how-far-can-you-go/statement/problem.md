---
title: "Problem D — How Far Can You Go?"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

You are given an array of **n** positive integers and **q** queries. Each query has a starting position **l** and a budget **b**.

For a query, start at position l. Take a~l~, then a~l+1~, then a~l+2~, and so on, in order, as long as the total taken stays **at most b**. Stop at the first element that would push the total over b, or at the end of the array.

For each query, print how many elements you take.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// l[j], b[j] describe query j (positions are 1-based)
// return an array of q answers
static int[] solve(int n, int[] a, int q, int[] l, long[] b)
```

```python
# Python
# l[j], b[j] describe query j (positions are 1-based)
# return a list of q answers
def solve(n, a, q, l, b):
```

> **Note:** Budgets go up to 10^15^, and sums of elements go up to 2 × 10^14^. Neither fits in a Java `int`. Use `long`.

## Input

- The first line has two integers **n** and **q**, separated by a space.
- The second line has **n** integers a~1~, a~2~, …, a~n~, separated by spaces.
- Each of the next **q** lines has two integers **l** and **b**, separated by a space.

## Output

Print **q** lines. Line *j* holds the answer to query *j*.

## Constraints

- 1 ≤ n, q ≤ 200 000
- 1 ≤ a~i~ ≤ 10^9^
- 1 ≤ l ≤ n
- 1 ≤ b ≤ 10^15^

## Example 1

Input:

```
5 4
3 1 4 1 5
1 8
2 10
3 3
4 100
```

Output:

```
3
3
0
2
```

**Explanation:**

- **Query (1, 8):** Take 3 (total 3), 1 (total 4), 4 (total 8). The next element, 1, would make the total 9, which is over 8. You take **3** elements.
- **Query (2, 10):** Take 1 (total 1), 4 (total 5), 1 (total 6). The next element, 5, would make the total 11, which is over 10. You take **3** elements.
- **Query (3, 3):** The first element, 4, is already over the budget of 3. You take **0** elements.
- **Query (4, 100):** Take 1 (total 1), then 5 (total 6). The array ends there, so you take **2** elements.

## Example 2

Input:

```
3 3
2 2 2
1 6
1 5
3 2
```

Output:

```
3
2
1
```

**Explanation:**

- **Query (1, 6):** 2 + 2 + 2 = 6, which is exactly the budget. A total equal to b is allowed, so you take **3** elements.
- **Query (1, 5):** 2 + 2 = 4. Adding the third 2 would make 6, which is over 5. You take **2** elements.
- **Query (3, 2):** You start at the last element. 2 ≤ 2, and then the array ends. You take **1** element.

## Example 3

Input:

```
1 2
7
1 7
1 6
```

Output:

```
1
0
```

**Explanation:** There is a single element, 7. With budget 7, you can take it, so the answer is **1**. With budget 6, you can't, so the answer is **0**.
