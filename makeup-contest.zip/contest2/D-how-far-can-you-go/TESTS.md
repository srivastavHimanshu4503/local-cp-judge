# Problem D — How Far Can You Go?: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 5, q = 4 | Statement example 1: stop before the budget is exceeded, 0, and end of array | `3
3
0
2` |
| sample/02 | n = 3, q = 3 | Statement example 2: a total exactly equal to b is allowed | `3
2
1` |
| sample/03 | n = 1, q = 2 | Statement example 3: single element | `1
0` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1, q = 2 | n = 1, a = 1: both answers 1 | `1
1` |
| secret/02 | n = 1, q = 3 | n = 1, a = 10^9: answers 0, 1, 1 | `0
1
1` |
| secret/03 | n = 3, q = 10 | small random #1 (n = 3) | `3
3
1
2
2
2
1
3
2
1` |
| secret/04 | n = 5, q = 7 | small random #2 (n = 5) | `3
3
1
5
5
4
3` |
| secret/05 | n = 5, q = 5 | small random #3 (n = 5) | `1
3
2
1
1` |
| secret/06 | n = 2, q = 10 | small random #4 (n = 2) | `1
1
1
1
0
2
1
2
2
1` |
| secret/07 | n = 1, q = 3 | small random #5 (n = 1) | `1
1
1` |
| secret/08 | n = 10, q = 6 | small random #6 (n = 10) | `3
4
5
3
2
3` |
| secret/09 | n = 200000, q = 200000 | max n and q, every query starts near the beginning with budget 10^15 (walking is O(n*q)) | `199944
199967
199905
199993
199911
19…` |
| secret/10 | n = 200000, q = 200000 | max n and q, all elements 10^9 (prefix sums need long) | `73942
161941
87885
22286
113500
1273
…` |
| secret/11 | n = 200000, q = 200000 | every query starts at position n | `0
1
1
1
0
1
1
1
1
1
1
1
1
0
1
0
1
0
1…` |
| secret/12 | n = 200000, q = 200000 | every budget is smaller than every element: all answers 0 | `0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0…` |
| secret/13 | n = 200000, q = 200000 | budgets land exactly on a prefix sum (the total may equal b) | `11387
10296
18446
34766
116393
3678
6…` |
| secret/14 | n = 200000, q = 200000 | budgets one less than a prefix sum | `4056
53681
89971
88484
2197
1137
7540…` |
| secret/15 | n = 200000, q = 200000 | all elements equal to 7 | `35996
179999
181415
133
18062
120892
…` |
| secret/16 | n = 200000, q = 200000 | small elements, medium budgets: long walks | `12951
130902
115281
34346
159030
5824…` |
| secret/17 | n = 200000, q = 200000 | max n and q random, mixed small, medium and huge budgets | `0
879
117145
1
1
1304
1275
20389
656
…` |
| secret/18 | n = 200000, q = 200000 | elements are 1 or 10^9: short and long stretches | `4
5
3
2
9
4
5
9
3
12
0
4
3
15
4
6
7
0…` |
| secret/19 | n = 200000, q = 200000 | every query is (1, 10^15): answer n every time | `200000
200000
200000
200000
200000
20…` |
