    static int[] solve(int n, int[] a, int q, int[] l, long[] b) {
        long[] P = new long[n + 1];
        for (int i = 0; i < n; i++) P[i + 1] = P[i] + a[i];
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int start = l[j] - 1;
            long limit = P[start] + b[j];
            int lo = start, hi = n;  // P[lo] <= limit always; find the largest such index
            while (lo < hi) {
                int mid = (lo + hi + 1) / 2;
                if (P[mid] <= limit) lo = mid;
                else hi = mid - 1;
            }
            res[j] = lo - start;
        }
        return res;
    }
