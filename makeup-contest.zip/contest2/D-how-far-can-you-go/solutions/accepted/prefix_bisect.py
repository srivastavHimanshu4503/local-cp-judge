from bisect import bisect_right


def solve(n, a, q, l, b):
    P = [0] * (n + 1)
    for i in range(n):
        P[i + 1] = P[i] + a[i]
    res = []
    for j in range(q):
        start = l[j] - 1
        r = bisect_right(P, P[start] + b[j]) - 1  # largest r with P[r] <= P[start] + b
        res.append(r - start)
    return res
