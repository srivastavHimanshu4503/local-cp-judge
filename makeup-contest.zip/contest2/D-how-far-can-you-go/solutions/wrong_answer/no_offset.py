# Bug: searches for P[r] <= b, forgetting the elements before l.
from bisect import bisect_right


def solve(n, a, q, l, b):
    P = [0] * (n + 1)
    for i in range(n):
        P[i + 1] = P[i] + a[i]
    return [max(0, bisect_right(P, b[j]) - 1 - (l[j] - 1)) for j in range(q)]
