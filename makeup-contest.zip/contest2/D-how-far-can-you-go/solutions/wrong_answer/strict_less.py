# Bug: requires the total to be strictly less than b.
from bisect import bisect_left


def solve(n, a, q, l, b):
    P = [0] * (n + 1)
    for i in range(n):
        P[i + 1] = P[i] + a[i]
    return [bisect_left(P, P[l[j] - 1] + b[j]) - 1 - (l[j] - 1) for j in range(q)]
