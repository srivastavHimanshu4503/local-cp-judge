# Correct but O(n*q): walk element by element for every query.
def solve(n, a, q, l, b):
    res = []
    for j in range(q):
        i = l[j] - 1
        total = 0
        while i < n and total + a[i] <= b[j]:
            total += a[i]
            i += 1
        res.append(i - (l[j] - 1))
    return res
