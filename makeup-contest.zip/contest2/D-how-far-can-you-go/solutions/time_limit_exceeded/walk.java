    // Correct but O(n*q): walk element by element for every query.
    static int[] solve(int n, int[] a, int q, int[] l, long[] b) {
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int i = l[j] - 1;
            long total = 0;
            while (i < n && total + a[i] <= b[j]) { total += a[i]; i++; }
            res[j] = i - (l[j] - 1);
        }
        return res;
    }
