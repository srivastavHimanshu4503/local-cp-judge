    // l[j], b[j] describe query j (positions are 1-based)
    // return an array of q answers
    static int[] solve(int n, int[] a, int q, int[] l, long[] b) {
        return new int[q];
    }
