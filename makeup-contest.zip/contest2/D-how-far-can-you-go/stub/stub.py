def solve(n, a, q, l, b):
    # l[j], b[j] describe query j (positions are 1-based)
    # return a list of q answers
    return [0] * q
