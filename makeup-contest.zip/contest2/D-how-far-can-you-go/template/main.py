import sys

# ---------------- your code starts here ----------------
def solve(n, a, q, l, b):
    # l[j], b[j] describe query j (positions are 1-based)
    # return a list of q answers
    return [0] * q
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    l = [int(x) for x in data[2 + n:2 + n + 2 * q:2]]
    b = [int(x) for x in data[3 + n:3 + n + 2 * q:2]]
    res = solve(n, a, q, l, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
