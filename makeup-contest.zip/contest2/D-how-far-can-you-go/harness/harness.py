import sys

# ---------------- your code starts here ----------------
{{STUDENT_CODE}}
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    l = [int(x) for x in data[2 + n:2 + n + 2 * q:2]]
    b = [int(x) for x in data[3 + n:3 + n + 2 * q:2]]
    res = solve(n, a, q, l, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
