import sys

# ---------------- your code starts here ----------------
# Correct but O(n*q): walk element by element for every query.
def solve(n, a, q, l, b):
    res = []
    for j in range(q):
        i = l[j] - 1
        total = 0
        while i < n and total + a[i] <= b[j]:
            total += a[i]
            i += 1
        res.append(i - (l[j] - 1))
    return res
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    l = [int(x) for x in data[2 + n:2 + n + 2 * q:2]]
    b = [int(x) for x in data[3 + n:3 + n + 2 * q:2]]
    res = solve(n, a, q, l, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
