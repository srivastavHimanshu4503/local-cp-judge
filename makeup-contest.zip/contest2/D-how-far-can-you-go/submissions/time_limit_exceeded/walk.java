import java.io.*;
import java.util.*;

class Main {
    // ---------------- your code starts here ----------------
    // Correct but O(n*q): walk element by element for every query.
    static int[] solve(int n, int[] a, int q, int[] l, long[] b) {
        int[] res = new int[q];
        for (int j = 0; j < q; j++) {
            int i = l[j] - 1;
            long total = 0;
            while (i < n && total + a[i] <= b[j]) { total += a[i]; i++; }
            res[j] = i - (l[j] - 1);
        }
        return res;
    }
    // ----------------- your code ends here -----------------

    public static void main(String[] args) throws IOException {
        FastReader in = new FastReader(System.in);
        int n = in.nextInt();
        int q = in.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = in.nextInt();
        int[] l = new int[q];
        long[] b = new long[q];
        for (int j = 0; j < q; j++) {
            l[j] = in.nextInt();
            b[j] = in.nextLong();
        }
        int[] res = solve(n, a, q, l, b);
        StringBuilder sb = new StringBuilder();
        for (int x : res) sb.append(x).append('\n');
        System.out.print(sb);
    }

    static class FastReader {
        private final DataInputStream in;
        private final byte[] buf = new byte[1 << 16];
        private int len = 0, ptr = 0;

        FastReader(InputStream is) { in = new DataInputStream(is); }

        private int read() throws IOException {
            if (ptr == len) { len = in.read(buf, 0, buf.length); ptr = 0; if (len <= 0) return -1; }
            return buf[ptr++];
        }

        String next() throws IOException {
            int c = read();
            while (c == ' ' || c == '\n' || c == '\r' || c == '\t') c = read();
            StringBuilder sb = new StringBuilder();
            while (c != -1 && c != ' ' && c != '\n' && c != '\r' && c != '\t') { sb.append((char) c); c = read(); }
            return sb.toString();
        }

        long nextLong() throws IOException {
            int c = read();
            while (c != '-' && (c < '0' || c > '9')) c = read();
            boolean neg = false;
            if (c == '-') { neg = true; c = read(); }
            long r = 0;
            while (c >= '0' && c <= '9') { r = r * 10 + (c - '0'); c = read(); }
            return neg ? -r : r;
        }

        int nextInt() throws IOException { return (int) nextLong(); }
    }
}
