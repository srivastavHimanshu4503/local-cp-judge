import sys

# ---------------- your code starts here ----------------
from bisect import bisect_right


def solve(n, a, q, l, b):
    P = [0] * (n + 1)
    for i in range(n):
        P[i + 1] = P[i] + a[i]
    res = []
    for j in range(q):
        start = l[j] - 1
        r = bisect_right(P, P[start] + b[j]) - 1  # largest r with P[r] <= P[start] + b
        res.append(r - start)
    return res
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    l = [int(x) for x in data[2 + n:2 + n + 2 * q:2]]
    b = [int(x) for x in data[3 + n:3 + n + 2 * q:2]]
    res = solve(n, a, q, l, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
