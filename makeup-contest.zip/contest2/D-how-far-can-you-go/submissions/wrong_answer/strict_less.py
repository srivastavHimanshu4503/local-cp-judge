import sys

# ---------------- your code starts here ----------------
# Bug: requires the total to be strictly less than b.
from bisect import bisect_left


def solve(n, a, q, l, b):
    P = [0] * (n + 1)
    for i in range(n):
        P[i + 1] = P[i] + a[i]
    return [bisect_left(P, P[l[j] - 1] + b[j]) - 1 - (l[j] - 1) for j in range(q)]
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    l = [int(x) for x in data[2 + n:2 + n + 2 * q:2]]
    b = [int(x) for x in data[3 + n:3 + n + 2 * q:2]]
    res = solve(n, a, q, l, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
