import sys

# ---------------- your code starts here ----------------
# Bug: searches for P[r] <= b, forgetting the elements before l.
from bisect import bisect_right


def solve(n, a, q, l, b):
    P = [0] * (n + 1)
    for i in range(n):
        P[i + 1] = P[i] + a[i]
    return [max(0, bisect_right(P, b[j]) - 1 - (l[j] - 1)) for j in range(q)]
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, q = int(data[0]), int(data[1])
    a = [int(x) for x in data[2:2 + n]]
    l = [int(x) for x in data[2 + n:2 + n + 2 * q:2]]
    b = [int(x) for x in data[3 + n:3 + n + 2 * q:2]]
    res = solve(n, a, q, l, b)
    sys.stdout.write("\n".join(map(str, res)) + "\n")


main()
