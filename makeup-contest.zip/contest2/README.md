# Contest package: four problems, 2 hours

| | Problem | Topic | Python function | Java method | Time limit (Java / Python) | Secret tests |
|---|---|---|---|---|---|---|
| A | Make Them Distinct | sorting + greedy | `solve(n, a)` | `long solve(int n, int[] a)` | 2 s / 6 s | 21 |
| B | Longest Run of Ones | sliding window (two pointers) | `solve(n, k, s)` | `int solve(int n, int k, String s)` | 2 s / 6 s | 25 |
| C | Flooding the Grid | graphs: BFS on a grid | `solve(n, m, grid)` | `int solve(int n, int m, String[] grid)` | 2 s / 6 s | 23 |
| D | How Far Can You Go? | binary search on prefix sums | `solve(n, a, q, l, b)` | `int[] solve(int n, int[] a, int q, int[] l, long[] b)` | 2 s / 6 s | 19 |

Each problem also has 3 sample tests (the statement examples). The memory limit is 1024 MB for every problem.

## Importing into DOMjudge

1. Import the four zips from `dist/domjudge/` (Jury → Problems → Import). Each zip holds `problem.yaml`, `domjudge-problem.ini` (short name, name, time limit, colour), `problem.pdf`, all sample and secret tests, and the jury submissions.
2. The Python limits assume DOMjudge's **time factor for Python 3 is 3**, the same as the last contest.
3. After import, DOMjudge judges the jury submissions. Each should get the verdict of its folder: `accepted`, `wrong_answer` or `time_limit_exceeded`.
4. D's zip is the largest, at about 24 MB. If the web import rejects it, raise PHP's `upload_max_filesize` / `post_max_size`, or import through the API.

## What is in each problem folder

| Path | What it is |
|---|---|
| `statement/problem.md` | Statement source with exact input/output format and copy-pasteable samples. `problem.html` and `problem.pdf` are rendered from it. |
| `harness/` | The I/O code (`harness.py`, `Harness.java`). The student's function goes at the `{{STUDENT_CODE}}` marker. |
| `stub/` | Only the function the student starts from. |
| `template/` | Harness + stub as one runnable file (`main.py`, `Main.java`). |
| `solutions/` | Function-only jury solutions in `accepted`, `wrong_answer` and `time_limit_exceeded`. |
| `submissions/` | The same solutions assembled with the harness into full programs. DOMjudge imports these as jury submissions. |
| `generator/` | `gen.py` (deterministic test generator), `validate.py` (strict input checker), `brute.py` (independent slow checker for small tests). |
| `data/sample`, `data/secret` | The tests: `.in` input, `.ans` expected output, `.desc` one-line description. |
| `TESTS.md` | Catalog of every test: what it targets and its expected output. |
| `verification-report.txt` | Result of judging every jury submission against every test. |

`statements/contest-problems.pdf` is the printable booklet: a one-page rules sheet followed by all four problems. Single-problem PDFs are next to it.

## Rebuilding

```
python3 tools/build.py        # regenerate tests, validate, cross-check, judge all jury submissions
python3 tools/package.py      # render statements, write metadata and TESTS.md, build dist/domjudge/*.zip
```

The generators use fixed seeds, so the tests come out byte-for-byte identical every time.

## Checks that were run

- Every input passes the problem's strict validator.
- Every expected output was produced by the Python reference and agrees with an independently written brute-force checker on every test small enough for it (11–15 tests per problem).
- The examples in each statement match `data/sample` byte for byte.
- Every jury submission gets its expected verdict (see each `verification-report.txt`). Slowest accepted runs: A 0.27 s, B 0.24 s, C 1.96 s (typical student-style Python BFS with tuples), D 0.64 s.
- Each Java slow solution was also run on every secret test with no early stop. It took over 2 s on 8 tests (A), 6 (B), 10 (C) and 8 (D), so a faster judge server will still reject it.

## Design notes worth knowing before the contest

- **A:** Example 2 shows that the final values don't have to be consecutive. A Java `int` total fails the all-equal tests, where the answer is about 2 × 10¹⁰. Bumping duplicates one at a time with a set takes about 2 × 10¹⁰ steps and times out.
- **B:** Moving the left end of the window by only one step when it has too many `0`s, instead of shrinking until valid, is **not** a bug here: the window never gets shorter than the best answer so far, so this well-known variant is also correct. Real bugs (resetting the window, off-by-one length, counting `1`s without checking they are consecutive) all fail Example 1. Extending from every start is O(n²) and times out.
- **C:** Exactly one `W`, so this is plain single-source BFS. A 1000 × 1000 snake maze has a path of 500 499 cells, which defeats simulating minute by minute. Diagonal spreading fails Example 1, and not checking for unreachable land fails Example 2.
- **D:** Forgetting the starting offset (searching for P[r] ≤ b instead of P[r] ≤ P[l−1] + b) fails Example 2. Requiring the total to be strictly less than b fails Example 1. `int` prefix sums in Java fail the hidden tests. Walking element by element for each query is O(n·q) and times out.
