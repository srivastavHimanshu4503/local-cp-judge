---
title: "Problem B — Longest Run of Ones"
---

**Time limit:** 2 seconds (Java), 6 seconds (Python) · **Memory limit:** 1024 MB

You are given a string **s** of length **n** made of the characters `0` and `1`, and a number **k**. You may change **at most k** of the `0`s into `1`s.

Find the length of the longest block of consecutive `1`s you can get.

## Your task

Implement the function below. The input reading and output printing are already done for you.

```java
// Java
// return the length of the longest block of consecutive 1s
static int solve(int n, int k, String s)
```

```python
# Python
# return the length of the longest block of consecutive 1s
def solve(n, k, s):
```

## Input

- The first line has two integers **n** and **k**, separated by a space.
- The second line has the string **s**: exactly n characters, each `0` or `1`, with no spaces.

## Output

Print one integer: the length of the longest block of consecutive `1`s.

## Constraints

- 1 ≤ n ≤ 200 000
- 0 ≤ k ≤ n

## Example 1

Input:

```
10 2
1101100111
```

Output:

```
7
```

**Explanation:** The positions are numbered 1 to 10:

| Position | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| s | 1 | 1 | 0 | 1 | 1 | 0 | 0 | 1 | 1 | 1 |

Change the `0`s at positions 6 and 7. Positions 4 to 10 then become all `1`s, which is a block of length **7**. Other choices are worse. For example, changing positions 3 and 6 gives the block 1–6, of length 6, because position 7 is still `0`.

## Example 2

Input:

```
6 0
111011
```

Output:

```
3
```

**Explanation:** With k = 0, nothing can be changed. The longest existing block is `111` at positions 1–3, which has length **3**.

## Example 3

Input:

```
5 3
00000
```

Output:

```
3
```

**Explanation:** Any 3 consecutive `0`s can be changed, for example positions 1–3. That gives a block of length **3**. The other two `0`s stay, because only 3 changes are allowed.
