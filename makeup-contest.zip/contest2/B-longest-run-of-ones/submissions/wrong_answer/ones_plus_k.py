import sys

# ---------------- your code starts here ----------------
# Bug: ignores contiguity; counts all 1s and adds k.
def solve(n, k, s):
    return min(n, s.count('1') + k)
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    s = data[2].decode()
    sys.stdout.write(f"{solve(n, k, s)}\n")


main()
