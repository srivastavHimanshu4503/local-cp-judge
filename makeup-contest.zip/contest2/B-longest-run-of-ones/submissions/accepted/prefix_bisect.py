import sys

# ---------------- your code starts here ----------------
# Prefix counts of zeros + binary search for the furthest right end from each start.
from bisect import bisect_right


def solve(n, k, s):
    z = [0] * (n + 1)
    for i, c in enumerate(s):
        z[i + 1] = z[i] + (c == '0')
    best = 0
    for i in range(n):
        r = bisect_right(z, z[i] + k) - 1  # largest r with z[r] - z[i] <= k
        best = max(best, r - i)
    return best
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    s = data[2].decode()
    sys.stdout.write(f"{solve(n, k, s)}\n")


main()
