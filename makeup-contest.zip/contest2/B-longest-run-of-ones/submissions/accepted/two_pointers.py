import sys

# ---------------- your code starts here ----------------
def solve(n, k, s):
    left = 0
    zeros = 0
    best = 0
    for right in range(n):
        if s[right] == '0':
            zeros += 1
        while zeros > k:
            if s[left] == '0':
                zeros -= 1
            left += 1
        best = max(best, right - left + 1)
    return best
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    s = data[2].decode()
    sys.stdout.write(f"{solve(n, k, s)}\n")


main()
