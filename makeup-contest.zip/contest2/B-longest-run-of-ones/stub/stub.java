    // return the length of the longest block of consecutive 1s
    static int solve(int n, int k, String s) {
        return 0;
    }
