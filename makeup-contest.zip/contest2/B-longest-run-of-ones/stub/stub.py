def solve(n, k, s):
    # return the length of the longest block of consecutive 1s
    return 0
