import sys

# ---------------- your code starts here ----------------
def solve(n, k, s):
    # return the length of the longest block of consecutive 1s
    return 0
# ----------------- your code ends here -----------------


def main():
    data = sys.stdin.buffer.read().split()
    n, k = int(data[0]), int(data[1])
    s = data[2].decode()
    sys.stdout.write(f"{solve(n, k, s)}\n")


main()
