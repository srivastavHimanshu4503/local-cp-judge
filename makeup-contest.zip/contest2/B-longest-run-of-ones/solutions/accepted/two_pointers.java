    static int solve(int n, int k, String s) {
        int left = 0, zeros = 0, best = 0;
        for (int right = 0; right < n; right++) {
            if (s.charAt(right) == '0') zeros++;
            while (zeros > k) {
                if (s.charAt(left) == '0') zeros--;
                left++;
            }
            best = Math.max(best, right - left + 1);
        }
        return best;
    }
