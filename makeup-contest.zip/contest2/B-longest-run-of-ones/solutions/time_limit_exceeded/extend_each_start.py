# Correct but O(n^2): from every start, extend right until a (k+1)-th 0.
def solve(n, k, s):
    best = 0
    for i in range(n):
        zeros = 0
        j = i
        while j < n:
            if s[j] == '0':
                zeros += 1
                if zeros > k:
                    break
            j += 1
        best = max(best, j - i)
    return best
