    // Correct but O(n^2): from every start, extend right until a (k+1)-th 0.
    static int solve(int n, int k, String s) {
        char[] c = s.toCharArray();
        int best = 0;
        for (int i = 0; i < n; i++) {
            int zeros = 0, j = i;
            while (j < n) {
                if (c[j] == '0' && ++zeros > k) break;
                j++;
            }
            best = Math.max(best, j - i);
        }
        return best;
    }
