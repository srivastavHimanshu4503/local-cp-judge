# Bug: window length computed as right - left.
def solve(n, k, s):
    left = zeros = best = 0
    for right in range(n):
        if s[right] == '0':
            zeros += 1
        while zeros > k:
            if s[left] == '0':
                zeros -= 1
            left += 1
        best = max(best, right - left)
    return best
