    // Bug: when there are too many 0s, throws the whole window away and restarts after it.
    static int solve(int n, int k, String s) {
        int left = 0, zeros = 0, best = 0;
        for (int right = 0; right < n; right++) {
            if (s.charAt(right) == '0') zeros++;
            if (zeros > k) {
                left = right + 1;
                zeros = 0;
            }
            best = Math.max(best, right - left + 1);
        }
        return best;
    }
