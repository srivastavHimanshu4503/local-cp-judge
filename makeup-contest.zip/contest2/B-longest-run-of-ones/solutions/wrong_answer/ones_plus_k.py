# Bug: ignores contiguity; counts all 1s and adds k.
def solve(n, k, s):
    return min(n, s.count('1') + k)
