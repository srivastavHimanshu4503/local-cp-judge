"""Independent checker for small tests: checks every substring directly. Usage: python3 brute.py < test.in"""
import sys

data = sys.stdin.read().split()
n, k, s = int(data[0]), int(data[1]), data[2]
assert n <= 200, "too big for brute"
best = 0
for i in range(n):
    for j in range(i, n):
        if s[i:j + 1].count("0") <= k:
            best = max(best, j - i + 1)
print(best)
