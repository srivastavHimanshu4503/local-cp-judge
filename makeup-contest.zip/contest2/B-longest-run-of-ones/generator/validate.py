"""Strict input validator for Problem B. Usage: python3 validate.py < test.in"""
import re
import sys

data = sys.stdin.read()
m = re.fullmatch(r"(\d+) (\d+)\n([01]+)\n", data)
assert m, "bad format"
n, k, s = int(m.group(1)), int(m.group(2)), m.group(3)
assert 1 <= n <= 200_000, "n out of range"
assert 0 <= k <= n, "k out of range"
assert len(s) == n, "string length differs from n"
print("OK")
