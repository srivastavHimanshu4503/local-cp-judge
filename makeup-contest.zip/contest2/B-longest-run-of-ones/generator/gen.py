"""Deterministic test generator for Problem B (Longest Run of Ones). Usage: python3 gen.py <problem_dir>"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools"))
from gen_common import write_all  # noqa: E402

MAXN = 200_000

SAMPLES = [
    ("10 2\n1101100111\n", "Statement example 1: change positions 6 and 7, answer 7"),
    ("6 0\n111011\n", "Statement example 2: k = 0, longest existing block"),
    ("5 3\n00000\n", "Statement example 3: all zeros, answer k"),
]


def fmt(k, s):
    return f"{len(s)} {k}\n{s}\n"


def rand_str(rng, n, p_zero):
    return "".join("0" if rng.random() < p_zero else "1" for _ in range(n))


def secret_tests():
    rng = random.Random(20261025)
    t = []
    t.append((fmt(0, "0"), "n = 1, s = 0, k = 0: answer 0"))
    t.append((fmt(1, "0"), "n = 1, s = 0, k = 1: answer 1"))
    t.append((fmt(0, "1"), "n = 1, s = 1, k = 0: answer 1"))
    for i in range(6):
        n = rng.randint(2, 15)
        t.append((fmt(rng.randint(0, n), rand_str(rng, n, 0.5)), f"small random #{i + 1} (n = {n})"))
    t.append((fmt(0, "1" * MAXN), "max n, all 1s, k = 0: answer n"))
    t.append((fmt(0, "0" * MAXN), "max n, all 0s, k = 0: answer 0"))
    t.append((fmt(12345, "0" * MAXN), "max n, all 0s, k = 12345: answer 12345"))
    t.append((fmt(MAXN, rand_str(rng, MAXN, 0.5)), "max n random, k = n: answer n"))
    t.append((fmt(1000, "01" * (MAXN // 2)), "max n alternating 0101..., k = 1000: answer 2000 or 2001"))
    s = rand_str(rng, MAXN, 0.01)
    t.append((fmt(s.count("0") - 1, s), "max n, sparse 0s, k = (number of 0s) - 1: extending from every start is O(n^2)"))
    s = rand_str(rng, MAXN, 0.02)
    t.append((fmt(MAXN // 200, s), "max n, 2% zeros, k = 1000"))
    s = "1" * 5000 + rand_str(rng, MAXN - 5000, 0.5)
    t.append((fmt(3, s), "best block at the very start (5000 ones then random), k = 3"))
    s = rand_str(rng, MAXN - 5000, 0.5) + "1" * 5000
    t.append((fmt(3, s), "best block at the very end, k = 3"))
    s = "1" * 90_000 + "0" * 20_000 + "1" * 90_000
    t.append((fmt(19_999, s), "20000 zeros in the middle, k = 19999: one zero always remains, answer 109999"))
    t.append((fmt(20_000, s), "20000 zeros in the middle, k = 20000: answer n"))
    for p, k in ((0.1, 10), (0.5, 50), (0.9, 500), (0.3, 0)):
        t.append((fmt(k, rand_str(rng, MAXN, p)), f"max n random, {int(p * 100)}% zeros, k = {k}"))
    # blocks of ones separated by gaps of varying zero counts
    parts = []
    while sum(map(len, parts)) < MAXN:
        parts.append("1" * rng.randint(1, 300))
        parts.append("0" * rng.randint(1, 4))
    s = "".join(parts)[:MAXN]
    t.append((fmt(4, s), "max n, blocks of 1s split by 1..4 zeros, k = 4"))
    return t


if __name__ == "__main__":
    write_all(sys.argv[1], SAMPLES, secret_tests())
