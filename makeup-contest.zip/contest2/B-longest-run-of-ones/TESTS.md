# Problem B — Longest Run of Ones: test catalog

Every test has an `.in` (input), `.ans` (expected output) and `.desc` (what it targets).

## sample

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| sample/01 | n = 10, k = 2 | Statement example 1: change positions 6 and 7, answer 7 | `7` |
| sample/02 | n = 6, k = 0 | Statement example 2: k = 0, longest existing block | `3` |
| sample/03 | n = 5, k = 3 | Statement example 3: all zeros, answer k | `3` |

## secret

| Test | Size | What it targets | Expected output |
|---|---|---|---|
| secret/01 | n = 1, k = 0 | n = 1, s = 0, k = 0: answer 0 | `0` |
| secret/02 | n = 1, k = 1 | n = 1, s = 0, k = 1: answer 1 | `1` |
| secret/03 | n = 1, k = 0 | n = 1, s = 1, k = 0: answer 1 | `1` |
| secret/04 | n = 8, k = 6 | small random #1 (n = 8) | `8` |
| secret/05 | n = 13, k = 2 | small random #2 (n = 13) | `8` |
| secret/06 | n = 6, k = 3 | small random #3 (n = 6) | `5` |
| secret/07 | n = 6, k = 4 | small random #4 (n = 6) | `5` |
| secret/08 | n = 12, k = 1 | small random #5 (n = 12) | `4` |
| secret/09 | n = 4, k = 3 | small random #6 (n = 4) | `4` |
| secret/10 | n = 200000, k = 0 | max n, all 1s, k = 0: answer n | `200000` |
| secret/11 | n = 200000, k = 0 | max n, all 0s, k = 0: answer 0 | `0` |
| secret/12 | n = 200000, k = 12345 | max n, all 0s, k = 12345: answer 12345 | `12345` |
| secret/13 | n = 200000, k = 200000 | max n random, k = n: answer n | `200000` |
| secret/14 | n = 200000, k = 1000 | max n alternating 0101..., k = 1000: answer 2000 or 2001 | `2001` |
| secret/15 | n = 200000, k = 2023 | max n, sparse 0s, k = (number of 0s) - 1: extending from every start is O(n^2) | `199923` |
| secret/16 | n = 200000, k = 1000 | max n, 2% zeros, k = 1000 | `52986` |
| secret/17 | n = 200000, k = 3 | best block at the very start (5000 ones then random), k = 3 | `5013` |
| secret/18 | n = 200000, k = 3 | best block at the very end, k = 3 | `5017` |
| secret/19 | n = 200000, k = 19999 | 20000 zeros in the middle, k = 19999: one zero always remains, answer 109999 | `109999` |
| secret/20 | n = 200000, k = 20000 | 20000 zeros in the middle, k = 20000: answer n | `200000` |
| secret/21 | n = 200000, k = 10 | max n random, 10% zeros, k = 10 | `254` |
| secret/22 | n = 200000, k = 50 | max n random, 50% zeros, k = 50 | `144` |
| secret/23 | n = 200000, k = 500 | max n random, 90% zeros, k = 500 | `592` |
| secret/24 | n = 200000, k = 0 | max n random, 30% zeros, k = 0 | `34` |
| secret/25 | n = 200000, k = 4 | max n, blocks of 1s split by 1..4 zeros, k = 4 | `1039` |
