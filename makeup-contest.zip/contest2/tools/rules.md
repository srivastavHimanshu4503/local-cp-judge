---
title: "Contest rules"
---

**Duration:** 2 hours · **Problems:** A, B, C, D (roughly easiest to hardest) · **Languages:** Java, Python 3

## How to solve a problem

Each problem gives you a function to complete, called `solve`. The program that reads the input and prints the output is **already written for you**. Write only the body of `solve`, and do not print anything yourself.

You may add helper functions (Python) or helper `static` methods (Java) next to `solve`. You may also use anything from the standard library: in Java, `java.util.*` and `java.io.*` are already imported.

## Testing your code

Each problem has examples. Every example input is in a box you can copy and paste directly into your program. Your output must match the example output exactly. Extra spaces at the end of a line are ignored.

Passing the examples does **not** mean your solution is accepted. Every submission is also run on hidden tests, including the largest inputs the constraints allow.

## Time limits

| Problem | Java | Python |
|:---:|:---:|:---:|
| A | 2 s | 6 s |
| B | 2 s | 6 s |
| C | 2 s | 6 s |
| D | 2 s | 6 s |

The memory limit is 1024 MB for every problem.

## Verdicts

| Verdict | Meaning |
|---|---|
| CORRECT | Your program passed every test. |
| WRONG-ANSWER | Your program printed a wrong answer on some test. |
| TIMELIMIT | Your program was too slow on some test. Usually you need a faster algorithm, not a faster computer. |
| RUN-ERROR | Your program crashed, for example with an exception or an index out of range. |
| COMPILER-ERROR | Your Java code does not compile. |

## Scoring

Students are ranked by the number of problems solved, then by total time. Each rejected submission on a problem you later solve adds 20 penalty minutes.
